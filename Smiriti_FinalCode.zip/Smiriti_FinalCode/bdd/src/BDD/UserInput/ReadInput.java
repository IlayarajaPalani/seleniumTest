package BDD.UserInput;

import java.io.File;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import BDD.Objects.ClassObject;

public class ReadInput {
	public static void xmlReader(String xmlFilePath){
		try
		{
			File file = new File(xmlFilePath);										
			JAXBContext jaxbContext = JAXBContext.newInstance(SetXmlInput.class);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            SetXmlInput data = (SetXmlInput) jaxbUnmarshaller.unmarshal(file);
			System.out.println(data.className+" , "+ data.methodName+" , "+data.expectedValue+" , " +data.inputs);
			
			} catch (JAXBException e) {
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args){
		ReadInput r = new ReadInput();
		r.xmlReader("./input.xml");
		
	
	}

}