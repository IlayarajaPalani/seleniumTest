package BDD.UserInput;
import BDD.GetAllClasses.*;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInputStream;
import java.io.FileOutputStream;
import BDD.Driver.*;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.Border;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import BDD.Objects.ClassObject;
import BDD.Test.Objects.*;

public class GiveInputs {
	static SetXmlInput ip1 = new SetXmlInput();
	public static  boolean giveInput(String destinationFile)
			throws JAXBException, IOException {
		Integer[] inputInt = new Integer[1];
		inputInt[0] = new Integer(5);
		
		// TestCase t = new TestCase();
	    ip1.setClassName("BDD.Test.Objects.Car");
		ip1.setMethodName("getAppendedNumber");
		ip1.setExpectedValue(15);
	    ip1.setInputs(inputInt);
	 	Driver1 d1 = new Driver1();
		boolean b = false;
		try {
			b=d1.testMethod(ip1.className, ip1.methodName, ip1.expectedValue,
					false, ip1.inputs);
			if (b==true) {

				JAXBContext context = JAXBContext
						.newInstance(SetXmlInput.class);
				Marshaller ma;

				try {
					ma = context.createMarshaller();
					ma.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
							Boolean.TRUE);
//					ma.marshal(ip1, new FileOutputStream("./UnitTestRepository/TestCases/"+ ip1.className+ip1.methodName+".xml"));
					ma.marshal(ip1, new FileOutputStream(destinationFile));
					ma.marshal(ip1, System.out);

				} catch (JAXBException e) {
					e.printStackTrace();
				} catch (IOException e) {

					e.printStackTrace();
				}
			}

		} catch (ClassNotFoundException e) {
			// // TODO Auto-generated catch block
			e.printStackTrace();
		}
		return b;
		

	}

	public static void main(String[] args) {

		try {
			GiveInputs.giveInput("./UnitTestRepository/TestCases/"+ ip1.className+ip1.methodName+".xml");
			//System.out.println(GiveInputs.giveInput());

		} catch (JAXBException e) {

			e.printStackTrace();
		} catch (IOException e) {

			e.printStackTrace();
		}

	}
	}