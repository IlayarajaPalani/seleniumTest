package BDD.UserInput;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

	@XmlRootElement  
	public class SetXmlInput { 
		
	@XmlElement
	public String className;
	public void setClassName(String className) {
		this.className = className;
	}
	
	@XmlElement
	public String  methodName ;
	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}
	
	@XmlElement
	public Object  expectedValue ; 
    public void setExpectedValue(Object expectedValue) {
		this.expectedValue = expectedValue;
	}
    
	@XmlElement
	public Object[] inputs;
    public void setInputs(Object[] inputs) {
		this.inputs = inputs;
	}
	

	
	
	}  

	