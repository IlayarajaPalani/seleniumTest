package BDD.BinderFactory;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import BDD.Driver.Driver1;
import BDD.Objects.ClassObject;
import BDD.Objects.MethodObject;

public class ReadXMLBinder {
	
	public static ArrayList<Object> xmlReader(String xmlFilePath, ClassObject classO){
		ArrayList<Object>xmldetails= new ArrayList();
	
	
		try
		{
			File file = new File(xmlFilePath);										
			JAXBContext jaxbContext = JAXBContext.newInstance(classO.getClass());
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			ClassObject data = (ClassObject) jaxbUnmarshaller.unmarshal(file);
			System.out.println(data.className);
		    
			
			} catch (JAXBException e) {
			e.printStackTrace();
		}
			
		return xmldetails;
		
	}
	

}
