package BDD.BinderFactory;

import java.io.FileOutputStream;
import java.io.IOException;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import BDD.Objects.ClassObject;

public class JavaXmlBinder {
	public static String responseBinder(String resultFile, ClassObject classO) throws JAXBException, IOException
	{


		JAXBContext context = JAXBContext.newInstance(classO.getClass());

		Marshaller m = context.createMarshaller();
		m.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
		try {
			m.marshal(classO, new FileOutputStream(resultFile));
			//m.marshal(classO, System.out);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultFile;
	}


}
