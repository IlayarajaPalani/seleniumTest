package BDD.BinderFactory;

import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;

import javax.lang.model.element.Modifier;
import javax.xml.bind.JAXBException;

import BDD.Objects.ClassObject;
import BDD.Objects.FieldObject;
import BDD.Objects.MethodObject;

public class ClassFactory {
	
	public static ClassObject getClassObject(Object object)
	{
	
		return getClassObject(object, true);
		
	}
	
	public static ClassObject getClassObject(Object object, boolean flag)
	{
		Class c = (Class) object;
		ClassObject classO = new ClassObject();
	
		try{
		classO.packageName = c.getPackage().getName();
		}catch(Exception ex){}
		classO.className = c.getSimpleName();
		classO.myClass   = c;
		if(flag)
		{
			classO = updateFields(classO, c);
			classO = updateMethods(classO, c);
		}
		return classO;
		
	}
	
	private static ClassObject updateMethods(ClassObject classO, Class c) {
		for(Method method:c.getDeclaredMethods())
		{
			MethodObject methodObject = new MethodObject();
			methodObject.modifier = (int) method.getModifiers();
			methodObject.name = method.getName();
			methodObject.returnType = getClassObject(method.getReturnType(),false);
			ArrayList<ClassObject> parameters= new ArrayList<ClassObject>();
			
//			System.out.println("Update Method - Starts");
//			System.out.println("Name:" + methodObject.name);
//			System.out.println("modifier:" + methodObject.modifier);
//			System.out.println("returnType:" + methodObject.returnType);
			for(Class s:  method.getParameterTypes())
			{
				parameters.add(getClassObject(s,false));
			}
//			
//			System.out.println("Parameters:" + parameters);
//			System.out.println("Update Method - Ends");
//			System.out.println();
			methodObject.parameters = parameters;
			classO.methods.add(methodObject);
		}
		return classO;
	}

	private static ClassObject updateFields(ClassObject classO, Class c)
	{
//		Class c = (Class) object;
		
		for(Field field:c.getDeclaredFields())
		{
			FieldObject fieldObject = new FieldObject();
			fieldObject.modifier = (int) field.getModifiers();
			fieldObject.name = field.getName();
			fieldObject.classObject = getClassObject(field.getType(),false);
			classO.fields.add(fieldObject);
//			fieldObject.classObject
			
			
		}
		return classO;
	}

}
