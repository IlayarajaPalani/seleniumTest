package BDD.UI;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

import BDD.GetAllClasses.GetClasses;

public class createUI extends JFrame {

	JTabbedPane tabbedPane = new JTabbedPane();
	JPanel homeclasspanel = new JPanel();
	JPanel methodclassPanel = new JPanel();
	JPanel testCasePanel = new JPanel();
	JTextField classTxt = new JTextField();
	JButton nxtbtn = new JButton("Next");
	JButton loadTestCasesbtn = new JButton("TestCase");
	GetClasses gc = new GetClasses();

	public createUI() {
		setTitle("Unit Test Automation Framework");
		setSize(600, 600);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setBackground(Color.gray);
		JPanel homepanel = new JPanel();
		homepanel.setLayout(new BorderLayout());
		getContentPane().add(homepanel);
		homepanel.setLayout(new BoxLayout(homepanel, BoxLayout.Y_AXIS));

		// call methods to show pane
		CreateHome ch = new CreateHome(this);
		final CreateMethod cm = new CreateMethod(this);
		 final CreateTestCaseTree ct = new CreateTestCaseTree(this);
		ch.createHome(homeclasspanel);
		// switching tab on clicking next button
		nxtbtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				//tabbedPane.setSelectedIndex(1);
				cm.createMethod(methodclassPanel);
				tabbedPane.addTab("Method", methodclassPanel);
				
			}
		});
		homeclasspanel.add(nxtbtn);
		//cm.createMethod(methodclassPanel);
		loadTestCasesbtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				// TODO Auto-generated method stub
				//tabbedPane.setSelectedIndex(1);
			ct.createTestCaseTree(testCasePanel);
				tabbedPane.addTab("TestCase", testCasePanel);
				
				//tabbedPane.addTab("Method", methodclassPanel);
			}
		});
		
		homeclasspanel.add(loadTestCasesbtn);

		// add tabs to tabbedpane
		tabbedPane = new JTabbedPane();
		tabbedPane.addTab("Home", homeclasspanel);
		//tabbedPane.addTab("Method", methodclassPanel);
		homepanel.add(tabbedPane);

	}

	public static void main(String[] args) {
		createUI cu = new createUI();
		cu.setVisible(true);

	}

}
