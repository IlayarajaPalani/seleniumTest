package BDD.UI;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import BDD.BinderFactory.ClassFactory;
import BDD.Driver.storeClass;
import BDD.GetAllClasses.GetClasses;
import BDD.Objects.ClassObject;
import BDD.Objects.MethodObject;
import BDD.Test.Constants.BDDConstants;
import BDD.Test.Wrapper.JCustomCheckBox;
import BDD.Test.holder.ObjectHolder;

public class CreateHome {

	JFrame window          = null;
	JScrollPane classListPanel  = null;
	JPanel methodListPanel = new JPanel();
	JTextField classTxt = new JTextField();
	JButton btnBrowse   = new JButton("Browse");
	JButton processBtn  = new JButton("Process");
	GetClasses gc       = new GetClasses();
	JList classList         = null;
	JScrollPane scrollClass = null;
	List allclasses         = null;
	ObjectHolder objHolder  = ObjectHolder.getInstance();
	
	public CreateHome(JFrame frame) {
		this.window = frame;
	}

	public void createHome(final JPanel homeclasspanel) {
		classTxt.setBounds(10, 10, 414, 21);
		homeclasspanel.add(classTxt);
		classTxt.setColumns(50);
		homeclasspanel.add(btnBrowse);
		btnBrowse.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				JFileChooser fileChooser = new JFileChooser();
				fileChooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
				int rVal = fileChooser.showOpenDialog(null);
				if (rVal == JFileChooser.APPROVE_OPTION) {
					classTxt.setText(fileChooser.getSelectedFile().toString());
				}
			}
		});
		//btnBrowse.setBounds(430, 10, 50, 21);
		// click process button to list down all the classes

		processBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent arg0) {
				

				System.out.println(classTxt.getText());
				// Converting "\" to "/"
				StringBuilder myclasses = new StringBuilder(classTxt.getText());
				for (int p = 0; p < classTxt.getText().length(); p++) {
					char c = myclasses.charAt(p);
					int ascii = (int) c;
					if (ascii == 92) {
						myclasses.setCharAt(p, '/');
					}
				}
				System.out.println("Folder:" + myclasses);
				allclasses = gc.getAllClassObjects(myclasses.toString());
				// got classes as arraylist
				// now convert object array to string array
				Object[] classes = allclasses.toArray();
				String[] classAsString = new String[classes.length];
				for (int i = 0; i < classAsString.length; i++) {
					classAsString[i] = classes[i].toString();
				}
				classList = new JList(classAsString);
				classList.setBounds(10, 30, 80, 600);
				//classList.setBounds(5, 40, 100, 1000);
				classList.setBackground(Color.LIGHT_GRAY);
				classList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
				// show methods when list is selected
				classList.addListSelectionListener(new ListSelectionListener() {
					@Override
					public void valueChanged(ListSelectionEvent arg0) {
						// TODO Auto-generated method stub
						String selectedClass = (String) classList
								.getSelectedValue();
						methodListPanel.removeAll();
						for (Object element : allclasses) {
							if (element.toString().equals(selectedClass)) {
								final ClassObject obj = ClassFactory.getClassObject(element);
								//code to store this class structure if it is not in repository
								storeClass sc = new storeClass();
								sc.storeClassStructure(obj);
								//code to list down all the methods inside the class
								List<MethodObject> allMethods = obj.methods;
								//list down only those methods that return a value
//								
//						       
						       for (final MethodObject method : allMethods) {
									JCustomCheckBox methodbox = new JCustomCheckBox(
											method.name, method, obj);
									
									methodbox.addActionListener(new ActionListener(){

										@Override
										public void actionPerformed(ActionEvent event) {
											
											JCustomCheckBox cb = (JCustomCheckBox) event.getSource();
											if (cb.isSelected()) {
												Object selectedMap = objHolder.get(BDDConstants.SELECTEDMETHODS_OBJECTHOLDERKEY);
												if(selectedMap == null) {
													selectedMap = new HashMap<String, ClassObject>();
													Map selectedMapObj = (Map)selectedMap;
													selectedMapObj.put(method, obj);
												}
												else {
													Map selectedMapObj = (Map)selectedMap;
												    Object classObj = selectedMapObj.get(method);
												    if(classObj==null){
												    	selectedMapObj.put(method, obj);
												    }
												}
												objHolder.put("selectedMethods", selectedMap);
												
												System.out.println("Object holder: " + objHolder);
												System.out.println("selectedMap: " + ((Map)selectedMap).size());
											}
											else {
												Object selectedMap = objHolder.get("selectedMethods");
												if(selectedMap != null) {
													Map selectedMapObj = (Map)selectedMap;
													selectedMapObj.remove(method.name);
												}
												System.out.println("Object holder: " + objHolder);
												System.out.println("selectedMap: " + ((Map)selectedMap).size());
											}
										}
										
									});
									/**
									 * objHolder.put("selectedMethodObjects", new 
									 */
									
									List<JCheckBox> methodcheckboxes = new ArrayList<JCheckBox>();
									// System.out.println(method.name);
									methodcheckboxes.add(methodbox);
									methodListPanel.add(methodbox);
									methodListPanel.setSize(5, 40);
									methodListPanel.setBounds(100, 100, 20, 50);
									methodListPanel.setLocation(100, 100);
									//methodListPanel.setBackground(Color.LIGHT_GRAY);
									methodListPanel.repaint();
									methodListPanel.validate();
								}
								homeclasspanel.add(methodListPanel);
							}
						}
					}
				});

				if(classListPanel!=null) { classListPanel.removeAll();}
				classListPanel = new JScrollPane(classList,
						JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
						JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
				classListPanel.setBounds(100, 100, 50, 10);
				homeclasspanel.add(classListPanel);

				window.validate();
				window.repaint();
			}
		});
		homeclasspanel.add(processBtn);

	}

}
