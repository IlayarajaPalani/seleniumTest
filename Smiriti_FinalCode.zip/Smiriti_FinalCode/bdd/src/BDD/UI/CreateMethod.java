package BDD.UI;

import java.awt.Color;
import java.awt.Component;
import java.awt.ComponentOrientation;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import BDD.Driver.Driver;
import BDD.Driver.Driver1;
import BDD.Objects.ClassObject;
import BDD.Objects.MethodObject;
import BDD.Test.Constants.BDDConstants;
import BDD.Test.holder.ObjectHolder;
import BDD.Test.holder.TestCaseIndex;
import BDD.UserInput.GiveInputs;
import BDD.UserInput.SetXmlInput;

public class CreateMethod {
	JLabel input;
	JLabel expectedValue ;
	
	
	JButton processMethodsbtn = new JButton("Run");
	JButton nextTab = new JButton("TestCase");
	JLabel methodLabel;
	JLabel methodName;
    
	JLabel parameterType = new JLabel();
	JLabel expectedReturnType = new JLabel();
	Container methodPnlCont = new Container();
	
	ObjectHolder objHolder  = ObjectHolder.getInstance();
	JFrame window= null;
	ArrayList<MethodObject> listedMethods = new ArrayList<MethodObject>();
	ClassObject clsObj = null;
	
	Map <String, JTextField[]>inputParamFields = new HashMap<String, JTextField[]>();
	Map <String, JTextField>returnFields = new HashMap<String, JTextField>();
	//map to store final result for a particular method
	Map <String, String>resultStatus = new HashMap<String, String>();
	Map <String, Object>calResult = new HashMap<String, Object>();
	Object result =null;
	
	TestCaseIndex testCaseIndex = TestCaseIndex.getInstance();
	
    public CreateMethod(JFrame frame) {
		this.window = frame;
	}

	public void createMethod(JComponent methodclassPanel) {
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setHorizontalScrollBarPolicy(javax.swing.ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.setVerticalScrollBarPolicy(javax.swing.ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setPreferredSize(new java.awt.Dimension(700, 500));
		
		JPanel pane = new JPanel();
		pane.setLayout(new BoxLayout(pane, BoxLayout.Y_AXIS));
		pane.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		pane.setAlignmentX(JComponent.LEFT_ALIGNMENT);
		
		Object selectedMapObj = objHolder.get(BDDConstants.SELECTEDMETHODS_OBJECTHOLDERKEY);
		Map<MethodObject, ClassObject> selectedMap = null;
		if(selectedMapObj!=null) {
			selectedMap = (Map)selectedMapObj;
		}
		
		for(MethodObject method: selectedMap.keySet()){
			
			JPanel myMethodPanel = new JPanel(new FlowLayout());
			pane.setAlignmentX(JComponent.LEFT_ALIGNMENT);
			
			listedMethods.add(method);
			System.out.println(method.name);
			clsObj = selectedMap.get(method);
			System.out.println(clsObj.className);
			
			
			methodLabel = new JLabel();
			methodLabel.setText("METHOD:");
			myMethodPanel.add(methodLabel);
			methodName = new JLabel();
			methodName.setText(method.name);
			myMethodPanel.add(methodName);
			//add the parameters to this array
			
			
			//add textfield for all the parameters
			
			int paramIndex = 0;
			JTextField giveInput[] = new JTextField[method.parameters.size()];
			inputParamFields.put(method.name, giveInput);
			System.out.println("MethodNamee::" + method.name	);
			
			for(ClassObject parameter: method.parameters){
				input = new JLabel();
				input.setText("INPUT:("+parameter.className+")");
				myMethodPanel.add(input);

				giveInput[paramIndex] = new JTextField();
				giveInput[paramIndex].setBounds(5, 5, 100, 100);
				giveInput[paramIndex].setPreferredSize(new Dimension(80,20));
				myMethodPanel.add(giveInput[paramIndex]);
				paramIndex++;
			
			}
			//
			if(!method.returnType.className.equalsIgnoreCase("void")){
				expectedValue = new JLabel();
				expectedValue.setText("EXPECTED:("+method.returnType.className+")");
				myMethodPanel.add(expectedValue);
				JTextField expectedResult = null;
				expectedResult  = new JTextField();
				expectedResult.setBounds(5, 5, 100, 100);
				expectedResult.setPreferredSize(new Dimension(80,20));
				
				myMethodPanel.add(expectedResult);
				returnFields.put(method.name, expectedResult);
			}
			else {
				returnFields.put(method.name, null);
			}
			//
			pane.add(myMethodPanel);
			pane.setComponentOrientation(ComponentOrientation.LEFT_TO_RIGHT);
		}
		
		scrollPane.add(pane);
		scrollPane.getViewport().setView(pane);
		
		methodclassPanel.add(scrollPane);
		
		window.validate();
		window.repaint();
		
	
		processMethodsbtn.addActionListener(new ActionListener(){
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				//process engine for every method
				SetXmlInput ip1 = new SetXmlInput();
				for(MethodObject method: listedMethods){
					System.out.println(" ************************************ ");
					
					Object []inputVal = new Object[method.parameters.size()];
					//Typecast the datatype of parameters - Starts
					System.out.println(" Parameters: " + method.parameters.size() + " Name: " + method.name);
					JTextField giveInp[] = (JTextField[]) inputParamFields.get(method.name);
					for(int i=0;i<method.parameters.size();i++){
						
						Object tempParamObj = giveInp[i].getText();
						System.out.println(tempParamObj + ", ");
						
						ClassObject paramCO = method.parameters.get(i);
						
						String absoluteClassName = paramCO.packageName+"."+paramCO.className;
						if((paramCO.packageName==null || paramCO.packageName.trim().length()<1) && paramCO.className.indexOf(".")<0) {
							absoluteClassName = getWrapperClassName(paramCO.className);
						}
						System.out.println("Abs Class Name: " + absoluteClassName);
						try {
							
							tempParamObj = valueOf(Class.forName(absoluteClassName), tempParamObj.toString());
						} catch (ClassNotFoundException e1) {
							e1.printStackTrace();
						}
						System.out.println(" ::: " + absoluteClassName + " :: " + tempParamObj);
						inputVal[i] = tempParamObj;	
					}
					
					//Typecast the datatype of parameters - Ends
					
					ip1.setClassName(clsObj.packageName+"."+clsObj.className);
					ip1.setMethodName(method.name);
					
					// TypeCast the datatype of Return Type - Starts
					
					Object     tempReturnObj  = null;
					JTextField expectedResult = null;
					
					if(returnFields.size() >0 ) {
						Object expectedResultObj = returnFields.get(method.name);
						if(expectedResultObj!=null) {
							expectedResult = (JTextField) expectedResultObj;
							tempReturnObj = expectedResult.getText();
							System.out.println(tempReturnObj + ", ");
						}
					}
					
					ClassObject returnCO = method.returnType;
					if(!returnCO.className.equalsIgnoreCase("void")) {
						String absoluteClassName = returnCO.packageName+"."+returnCO.className;
						System.out.println("Abs Class Name: " + absoluteClassName);
						if ((returnCO.packageName==null || returnCO.packageName.trim().length()<1) && returnCO.className.indexOf(".")<0) {
							absoluteClassName = getWrapperClassName(returnCO.className);
						}
						try {
							tempReturnObj = valueOf(Class.forName(absoluteClassName), tempReturnObj.toString());
						} catch (ClassNotFoundException e1) {
							e1.printStackTrace();
						}
						
						System.out.println(" RETURN TYPE OBJECT: " + tempReturnObj.getClass().getName());
						// TypeCast the datatype of Return Type - Ends
					}
					ip1.setExpectedValue(tempReturnObj);
					//
					
					ip1.setInputs(inputVal);
					Driver d1 = new Driver();
					//System.out.println(ip1.expectedValue);
					//System.out.println(ip1.inputs[0].toString());
				
					try {
						System.out.println("RESULT:::: " + d1.testMethod(ip1.className, ip1.methodName, ip1.expectedValue,
									false, ip1.inputs));
					} catch (ClassNotFoundException e2) {
						// TODO Auto-generated catch block
						e2.printStackTrace();
					}catch(Exception e3){
						e3.printStackTrace();
					}
					//start
					boolean b = false;
					
					try {
						System.out.println(" " + ip1.className + ", " + ip1.methodName + ", " + ip1.expectedValue + ", " + ip1.inputs);
						b=d1.testMethod(ip1.className, ip1.methodName, ip1.expectedValue,
								false, ip1.inputs);
						result = d1.calculatedResult(ip1.className, ip1.methodName, ip1.expectedValue,
								false, ip1.inputs);
						calResult.put(ip1.methodName, result);
						
						if (b==true) {

							JAXBContext context = JAXBContext
									.newInstance(SetXmlInput.class);
							Marshaller ma;

							try {
								ma = context.createMarshaller();
								ma.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,
										Boolean.TRUE);
								//to be done : Modify to store multiple testcases for a unique method
								int nextIndex = testCaseIndex.getNextIndex(ip1.className,ip1.methodName);
								ma.marshal(ip1, new FileOutputStream("./UnitTestRepository/TestCases/"+ ip1.className+"."+ip1.methodName+"_"+nextIndex+".xml"));
								ma.marshal(ip1, System.out);
								testCaseIndex.updateIndex(ip1.className,ip1.methodName);
							} catch (JAXBException e1) {
								e1.printStackTrace();
							} catch (IOException e1) {

								e1.printStackTrace();
							}
						}

					} catch (ClassNotFoundException e1) {
						// // TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (JAXBException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					//end
					//store the results as map
					resultStatus.put(method.name, String.valueOf(b));
					System.out.println(" ????????????????????????????????????? ");
							
				}
				JFrame methodStatusFrame = new JFrame("Method Status");
				JScrollPane statusPane ;
				JTable resultStatusTable;
				//System.out.println("Methods Size  :"+listedMethods.size());
				int tableSize = listedMethods.size()+1;
				resultStatusTable = new JTable(tableSize, 5);
				//System.out.println("Status Table size :"+resultStatusTable.getRowCount());
				resultStatusTable.setValueAt("S.No.",0, 0);
				resultStatusTable.setValueAt("Method Name",0, 1);
				resultStatusTable.setValueAt("Actual Result",0, 2);
				resultStatusTable.setValueAt("Expected Result",0, 3);
				resultStatusTable.setValueAt("Status",0, 4);
				int j=1;
				for(MethodObject m: listedMethods){
					if(j==tableSize){
						break;
					}
					resultStatusTable.setValueAt(j,j, 0);
					resultStatusTable.setValueAt(m.name,j, 1);
					resultStatusTable.setValueAt(calResult.get(m.name),j, 2);
					resultStatusTable.setValueAt(ip1.expectedValue,j, 3);
					resultStatusTable.setValueAt(resultStatus.get(m.name), j, 4);
					
					j++;					
				}statusPane = new JScrollPane(resultStatusTable,
						JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
						JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
				statusPane.setBounds(100, 100, 50, 10);
				
				window.validate();
				window.repaint();
				//statusPane.add(resultStatusTable);
				 methodStatusFrame.add(statusPane);
				methodStatusFrame.setSize(400, 400);
				methodStatusFrame.setBackground(Color.GREEN);
				methodStatusFrame.setVisible(true);
			}
		}); 
		

		methodclassPanel.add(processMethodsbtn);
		
	}

	
	public static <T> T valueOf(Class<T> klazz, String arg) {
		T ret = null;
		
		// Incase of String input, String.valueOf(String) method is not available, 
		// and hence we are returning the string directly
		if(klazz.getName().equalsIgnoreCase("java.lang.String")) {
			return (T) arg;
		}
		
        
		Exception cause = null;
        try {
            ret = klazz.cast(
                klazz.getDeclaredMethod("valueOf", String.class)
                .invoke(null, arg)
            );
        } catch (NoSuchMethodException e) {
            cause = e;
        } catch (IllegalAccessException e) {
            cause = e;
        } catch (InvocationTargetException e) {
            cause = e;
        }
        if (cause == null) {
            return ret;
        } else {
            throw new IllegalArgumentException(cause);
        }
    }


	public String getWrapperClassName(String primitiveDataType) {

		if(primitiveDataType.equalsIgnoreCase("int")) {
			return "java.lang.Integer";
		}
		if(primitiveDataType.equalsIgnoreCase("boolean")) {
			return "java.lang.Boolean";
		}
		if(primitiveDataType.equalsIgnoreCase("byte")) {
			return "java.lang.Byte";
		}
		if(primitiveDataType.equalsIgnoreCase("float")) {
			return "java.lang.Float";
		}
		if(primitiveDataType.equalsIgnoreCase("double")) {
			return "java.lang.Double";
		}
		if(primitiveDataType.equalsIgnoreCase("long")) {
			return "java.lang.Long";
		}
		if(primitiveDataType.equalsIgnoreCase("short")) {
			return "java.lang.Short";
		}
		if(primitiveDataType.equalsIgnoreCase("char")) {
			return "java.lang.Character";
		}
		return primitiveDataType;
	}


}
