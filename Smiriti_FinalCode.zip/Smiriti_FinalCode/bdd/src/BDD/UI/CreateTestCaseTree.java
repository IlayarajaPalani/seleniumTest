package BDD.UI;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.swing.tree.TreeSelectionModel;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import BDD.Driver.Driver1;
import BDD.Driver.TestCaseValidator;
import BDD.Driver.findTestCase;
import BDD.Objects.ClassObject;
import BDD.Objects.MethodObject;
import BDD.Test.Constants.BDDConstants;
import BDD.Test.holder.ObjectHolder;
import BDD.UserInput.ReadInput;
import BDD.UserInput.SetXmlInput;


public class CreateTestCaseTree {
	ArrayList<MethodObject> selectedMethods = new ArrayList<MethodObject>();
	
	ArrayList<String>selectedFile = new ArrayList<String>();
	ClassObject clsObj = null;
	String className = null;
	JFrame window= null;
	JButton testBtn = new JButton("RUN");
    private JTree tree;
	DefaultMutableTreeNode root ;
	List<String> methodTestCases= new ArrayList<String>();
	ObjectHolder objHolder  = ObjectHolder.getInstance();
	Map<String, Collection<Object>> map = new HashMap<String, Collection<Object>>();
	public CreateTestCaseTree(JFrame frame) {
			this.window = frame;
		}
	public void createTestCaseTree(final JPanel testCasePanel){
		Object selectedMapObj = objHolder.get(BDDConstants.SELECTEDMETHODS_OBJECTHOLDERKEY);
		Map<MethodObject, ClassObject> selectedMap = null;
		if(selectedMapObj!=null) {
			selectedMap = (Map<MethodObject, ClassObject>)selectedMapObj;
		}
		 
		    for(MethodObject method: selectedMap.keySet()){
			selectedMethods.add(method);
			clsObj = selectedMap.get(method);
			//root.add(new DefaultMutableTreeNode(method.name)); 
			
			System.out.println(method.name);
		}
		//create the root node     
		root = new DefaultMutableTreeNode(clsObj.packageName); 
		DefaultMutableTreeNode classNode = new DefaultMutableTreeNode(clsObj.className);
		    		
		System.out.println(clsObj.className);
		for (MethodObject mo : selectedMap.keySet()){
			DefaultMutableTreeNode methodNode = new DefaultMutableTreeNode(mo.name);
			//create the child nodes  
			
			//create child for all methods(child =testcase file)
			//DefaultMutableTreeNode testCaseNode = new DefaultMutableTreeNode("TEST CASES");  
			findTestCase ft = new findTestCase();
			methodTestCases=ft.testCases(clsObj.packageName+"."+clsObj.className, mo.name);
			System.out.println(methodTestCases);
			for(String testCase: methodTestCases){
				DefaultMutableTreeNode testNode = new DefaultMutableTreeNode(testCase);
		        methodNode.add(testNode);		    
			}
			classNode.add(methodNode); 	
		}
		root.add(classNode); 
		//root = new DefaultMutableTreeNode(clsObj.className);
		tree = new JTree(root);
        tree.setShowsRootHandles(true);     
		tree.setRootVisible(false); 
		final CheckTreeManager chkTree = new CheckTreeManager(tree, true, false);
		//array having all the test case path
		//final TreePath checkedPaths[] = chkTree.getSelectionModel().getSelectionPaths(); 
	
			//System.out.println("Tree_Path:  " +checkedPaths);
		
	    JScrollPane scrol = new JScrollPane(tree);
	    scrol.setPreferredSize(new java.awt.Dimension(400, 500));
		testCasePanel.add(scrol);
		testBtn.setBounds(500, 500, 10, 5);
		testBtn.addActionListener(new ActionListener() {
			//@SuppressWarnings("unused")
			@Override
			public void actionPerformed(ActionEvent arg0) {
				
			   Enumeration checked = chkTree.getAllCheckedNodes(); 
			    // System.out.println("checked paths:"); 
			     while(checked.hasMoreElements()) {
			       String nodeFile = checked.nextElement().toString();
					//System.out.println(nodeFile);
					if(nodeFile.endsWith("xml")){
						System.out.println(nodeFile);
						selectedFile.add(nodeFile);
						String testcaseXML =nodeFile;
						 TestCaseValidator tv = new TestCaseValidator();
				    	  ArrayList<Object> testDetails = new ArrayList<Object>();
				    	  testDetails = tv.validate(testcaseXML);
				    	  //create a map to store all the test case report
				    	  //filename as key and arraylist as value
				    	  map.put(testcaseXML, testDetails);
					}
					
			     }
			    	// System.out.println(checked.nextElement());     
			    
			    JFrame testCaseStatusFrame = new JFrame("Test Case Report");
				JScrollPane statusPane;
				JTable testCaseStatusTable;
				
				int rowCount = selectedFile.size()+1;
			
				testCaseStatusTable = new JTable(rowCount, 11);
				
				testCaseStatusTable.setValueAt("S.No",0, 0);
				testCaseStatusTable.setValueAt("File Name",0, 1);
				testCaseStatusTable.setValueAt("Class Name",0, 2);
				testCaseStatusTable.setValueAt("Method Name",0, 3);
				testCaseStatusTable.setValueAt("Parameter Size",0, 4);
				testCaseStatusTable.setValueAt("Input Size",0, 5);
				testCaseStatusTable.setValueAt("Input",0, 6);
				testCaseStatusTable.setValueAt("Actual Result",0, 7);
				testCaseStatusTable.setValueAt("Expected Result",0, 8);
				testCaseStatusTable.setValueAt("Method Modified",0, 9);
				testCaseStatusTable.setValueAt("Status",0, 10);
				//System.out.println(selectedFile.size());
				int j=1;
				//System.out.println(selectedFile.toString());
				for(String t: selectedFile){
					
					String xmlName = t.toString();
					System.out.println("My Case:  "+t);
					 ArrayList<Object> mytestDetails = new ArrayList<Object>();
					 mytestDetails = (ArrayList<Object>) map.get(xmlName);
					testCaseStatusTable.setValueAt(j,j, 0);
					testCaseStatusTable.setValueAt(xmlName, j, 1);
					testCaseStatusTable.setValueAt(mytestDetails.get(0),j, 2);
					testCaseStatusTable.setValueAt(mytestDetails.get(1),j, 3);
					testCaseStatusTable.setValueAt(mytestDetails.get(2),j, 4);
					testCaseStatusTable.setValueAt(mytestDetails.get(3),j, 5);
					testCaseStatusTable.setValueAt(mytestDetails.get(4),j, 6);
					testCaseStatusTable.setValueAt(mytestDetails.get(5),j, 7);
					testCaseStatusTable.setValueAt(mytestDetails.get(6),j, 8);
					testCaseStatusTable.setValueAt(mytestDetails.get(7),j, 9);
					testCaseStatusTable.setValueAt(mytestDetails.get(8),j, 10);
					j++;					
				}

				//if(classListPanel!=null) { classListPanel.removeAll();}
				statusPane = new JScrollPane(testCaseStatusTable,
						JScrollPane.VERTICAL_SCROLLBAR_ALWAYS,
						JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
				statusPane.setBounds(100, 100, 50, 10);
				
				window.validate();
				window.repaint();
				//statusPane.add(testCaseStatusTable);
				
				testCaseStatusFrame.add(statusPane);
				testCaseStatusFrame.setSize(600, 600);
				testCaseStatusFrame.setBackground(Color.GREEN);
				testCaseStatusFrame.setVisible(true);
			
		
			}

				//System.out.println("Run button clicked");
			
		});
		
		testCasePanel.add(testBtn);
		
		}
	
	
}