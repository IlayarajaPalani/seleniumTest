package BDD.Test.Objects;


public class Car {
	
	public enum COLOR {
		
		GREEN,
		BLUE,
		RED;
	}
	
	public String number;
	
	public COLOR color;
	
	public String owner;
	
	
	public Car()
	{
		number = "10";
		owner  = "default";
	}
	
	public Car(String number, COLOR color, String owner)
	{
		this.number = number;
		this.color = color;
		this.owner = owner;
	}
	
	public String getNumber()
	{
		return number;
	}
	
	public String getAppendedNumber(Integer appendNum)
	{
		char result = 0;
		if(number!=null && number.trim().length()>0) {
			try {
				int tmp = (Integer.parseInt(number.trim()) + appendNum);
				result = (char) tmp;
				 number  = "" + tmp;
				
			} catch(NumberFormatException e) {
				e.printStackTrace();
			}
		}
		

		return number;
	}
	
	public COLOR getColor()
	{
		return color;
	}
	
	public String getOwner()
	{
		return owner;
	}
	
	public void setColor(COLOR color)
	{
		this.color = color;
	}
	
	public void setNumber(String number)
	{
		this.number = number;
	}
	
	public void setOwner(String owner)
	{
		this.owner = owner;
	}
	
	public double addTwonumbers(int x, Integer y,int z) {
		return (double) (x+y+z);
	}
//	public double addTwonumbers(int x, Integer y) {
//		return (double) (x+y);
//	}
	public int subtractTwonumbers(int x, Integer y) {
		return (int) (x-y);
	}
	public double mulTwonumbers(int x, Integer y) {
		return (double) (x*y);
	}
}
