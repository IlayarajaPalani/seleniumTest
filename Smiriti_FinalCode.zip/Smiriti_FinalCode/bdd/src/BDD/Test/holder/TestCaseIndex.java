package BDD.Test.holder;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class TestCaseIndex {
	
	static TestCaseIndex holder = null;
	
	String filename = "";
	int nextIndex = -1; 
	File propertyFile = null;
	
	private TestCaseIndex(String filename){
		this.filename = filename; 
		propertyFile = new File("./UnitTestRepository/TestCases/method.properties");
		if(!propertyFile.exists()) {
			try {
				FileOutputStream fileOut = new FileOutputStream(propertyFile);
				fileOut.close();

			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		
	}
	
	public static TestCaseIndex getInstance(){
		if(holder==null) {
			holder  = new TestCaseIndex("./UnitTestRepository/TestCases/");
		}
		return holder;
	}
	
	public int getNextIndex(String className, String methodName) {
		nextIndex = (getCurrentIndex(className, methodName) + 1);
		return nextIndex;
	}
	
	public int getCurrentIndex(String className, String methodName) {
		String key = className+"."+methodName;
		Properties properties = new Properties();
		String value = "0";
		try {
			FileInputStream fileIn = new FileInputStream(propertyFile);
			properties.load(fileIn);
			value = properties.getProperty(key);
			if(value == null) { value = "0"; }
			fileIn.close();
		}catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		int val = Integer.valueOf(value);
		return val;

	}
	
	public void updateIndex(String className, String methodName) {
		Properties properties = new Properties();
		try {
			FileInputStream fileIn = new FileInputStream(propertyFile);
			properties.load(fileIn);
			fileIn.close();
		}catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		String key = className+"."+methodName;
		properties.setProperty(key, ""+nextIndex);
		try {
			FileOutputStream fileOut = new FileOutputStream(propertyFile);
			properties.store(fileOut, "");
			fileOut.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	public static void main(String args[]) {
		TestCaseIndex tci = TestCaseIndex.getInstance();
		int nIndex = tci.getNextIndex("Car", "fileIndexCheck");
//		System.out.println("Next Index: " + nIndex);
		tci.updateIndex("Car", "fileIndexCheck");
//		System.out.println("Next Index: " + tci.getNextIndex("Car", "fileIndexCheck"));
	}
}
