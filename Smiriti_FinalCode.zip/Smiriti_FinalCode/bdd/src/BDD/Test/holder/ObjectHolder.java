package BDD.Test.holder;

import java.util.HashMap;
import java.util.Map;

public class ObjectHolder {
	
	static ObjectHolder holder = null;
	Map<String, Object> map = new HashMap<String, Object>();
	
	private ObjectHolder(){}
	
	public static ObjectHolder getInstance(){
		if(holder==null) {
			holder  = new ObjectHolder();
		}
		return holder;
	}

	public void put(String key, Object value) {
		map.put(key, value);
	}
	
	public Object get(String key) {
		return map.get(key);
	}
}
