package BDD.Test;

public class SampleJavaClass {
	
	public String publicVariable;
	
	private String privateVariable;
	
	String defaultVariable;
	
	protected String protectedVariable;
	
	public static String publicStaticVariable;
	
	private static String privateStaticVariable;
	
	public static final String publicStaticfinalVariable="";


}
