package BDD.Test.Wrapper;

import javax.swing.JCheckBox;

import BDD.Objects.ClassObject;
import BDD.Objects.MethodObject;

public class JCustomCheckBox extends JCheckBox{
	
	private MethodObject cbMethodObj = null;
	private ClassObject  cbClassObj  = null;
	
	public JCustomCheckBox(String name, MethodObject mo, ClassObject co ){
		super(name);
		this.cbMethodObj = mo;
		this.cbClassObj  = co;
	}
	public MethodObject getCbMethodObj() {
		return cbMethodObj;
	}
	public void setCbMethodObj(MethodObject cbMethodObj) {
		this.cbMethodObj = cbMethodObj;
	}
	public ClassObject getCbClassObj() {
		return cbClassObj;
	}
	public void setCbClassObj(ClassObject cbClassObj) {
		this.cbClassObj = cbClassObj;
	}
}
