package BDD.Test;

import static org.junit.Assert.*;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import javax.xml.bind.JAXBException;

import org.junit.Test;

import BDD.BinderFactory.ClassFactory;
import BDD.BinderFactory.JavaXmlBinder;
import BDD.BinderFactory.JavaXmlBinder;
import BDD.Objects.ClassObject;
import BDD.Test.Objects.Car;
import BDD.Test.Objects.Car.COLOR;

public class TestReflection {

	@Test
	public void test() throws SecurityException, NoSuchMethodException, IllegalArgumentException, InstantiationException, IllegalAccessException, InvocationTargetException, NoSuchFieldException {
		
		Class<?> c =null;
		try{
			c =Class.forName(Car.class.getName());	
		}
		catch (Exception e) {
		}


		Constructor constructor = c.getDeclaredConstructor();	
		Constructor<?>[] cons = c.getDeclaredConstructors();
		
		for(Constructor c1 : cons)
		{
			
			for(Class c2 : c1.getParameterTypes())
				System.out.println(c2.getName());
		}
		
		Object o = constructor.newInstance();
		Field f1 = o.getClass().getDeclaredField("color");
		f1.setAccessible(true);
		f1.set(o,COLOR.RED);

		Field f2 = o.getClass().getDeclaredField("owner");
		f2.setAccessible(true);
		f2.set(o,"Prasanth");
		
		Field f3 = o.getClass().getDeclaredField("number");
		f3.setAccessible(true);
		f3.set(o,"2811");
		
		Method m= c.getDeclaredMethod("getNumber", null);
		String s = (String) m.invoke(o, null);
		System.out.println(s);
		assertEquals("", s, "2811");
	}
	
	@Test
	public void test2()
	{
		
		Class<?> c =null;
		try{
			c =Class.forName(SampleJavaClass.class.getName());	
		}
		catch (Exception e) {
		}
		
		
		
		for( Field field : c.getDeclaredFields())
		{
			System.out.println(field.getName()+"  "+field.getModifiers() );
//			Modifier. = field.getModifiers();
		}
		
	}

	@Test
	public void test3()
	{
		
		Class<?> c =null;
		try{
			c =Class.forName(Car.class.getName());	
		}
		catch (Exception e) {
		}
		
		
		
		ClassObject classO = ClassFactory.getClassObject(c);
		
		try {
			JavaXmlBinder.responseBinder("./sample.xml", classO);
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
