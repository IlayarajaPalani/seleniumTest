package BDD.Test.Constants;

public class BDDConstants {

	public final static String SELECTEDMETHODS_OBJECTHOLDERKEY = "selectedMethods";
}
