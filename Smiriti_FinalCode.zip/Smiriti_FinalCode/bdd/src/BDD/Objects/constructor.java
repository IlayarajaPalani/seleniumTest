package BDD.Objects;

import java.lang.reflect.Modifier;

public class constructor {
	public Modifier modifier;
	public ClassObject[] parameters;
}
