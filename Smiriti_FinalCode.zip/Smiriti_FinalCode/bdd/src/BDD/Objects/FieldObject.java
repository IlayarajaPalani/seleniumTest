package BDD.Objects;

import javax.xml.bind.annotation.XmlElement;


public class FieldObject {
	
	public int modifier;
	public String name;
	public ClassObject classObject;

}
