package BDD.Objects;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementWrapper;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement (name="ClassObject") 
@XmlAccessorType(XmlAccessType.FIELD) 
public class ClassObject {
	
	public String packageName ="";
	
	public String className ="";
	
	@XmlElementWrapper(name="fields")
	@XmlElement(name="field")
	public List<FieldObject> fields = new ArrayList<FieldObject>();

	@XmlElementWrapper(name="constructors")
	@XmlElement(name="constructor")
	public List<constructor> constructors = new ArrayList<constructor>();

	@XmlElementWrapper(name="methods")
	@XmlElement(name="method")
	public List<MethodObject> methods = new ArrayList<MethodObject>();
	
	public Class myClass = null;
	
	
	public String toString() {
		StringBuffer str = new StringBuffer();
		str.append("\r\n");
		str.append("packageName:"+packageName);
		str.append(",className:"+className);
		str.append(",fields:"+fields);
		str.append(",constructors:"+constructors);
		str.append(",methods:"+methods);
		str.append(",myClass:"+myClass);
		str.append("\r\n");
		return str.toString();
		
	} 
}
