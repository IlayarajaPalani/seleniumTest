package BDD.Objects;

public enum ModifierObject {

	Public,
	Private,
	Protected,
	Static,
	Final,
	Synchronised
}
