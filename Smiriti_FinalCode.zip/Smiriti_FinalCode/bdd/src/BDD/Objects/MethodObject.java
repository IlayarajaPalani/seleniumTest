package BDD.Objects;

import java.util.ArrayList;

public class MethodObject {
	
	public int modifier;
	public String name;
	public ClassObject returnType;
	public ArrayList<ClassObject> parameters;
	
	public MethodObject()
	{
		
	}

	@Override
	public boolean equals(Object o) {
		MethodObject temp = (MethodObject)o;
		if(this.name.equalsIgnoreCase(temp.name)) {
			return true;
		}
		else {
			return false;
		}
	}

}
