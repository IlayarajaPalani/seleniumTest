package BDD.GetAllClasses;

import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class GetClasses {
	
	public GetClasses(){
		
	}
	
	public ArrayList getAllClasses(String packagename) {
		ArrayList classes = new ArrayList();

		File f = new File(Thread.currentThread().getContextClassLoader()
				.getResource(packagename.replace('.', '/')).getFile());
		if (f.exists()) {
			String[] files = f.list();
			for (int i = 0; i < files.length; i++) {
				if (files[i].endsWith(".class")) {

					try {
						classes
								.add(Class.forName(packagename
										+ '.'
										+ files[i].substring(0, files[i]
												.length() - 6)));
					} catch (ClassNotFoundException e) {

						e.printStackTrace();
					}
				}
			}
		} else {
			System.out.println("File does not exist");
		}
		return classes;

	}

	public ArrayList getAllClassesByFile(String absoluteFolderPath) {
		//String absoluteFolderPath = UIabsoluteFolderPath.replace('\', '/') ;
		ArrayList classes = new ArrayList();
		//int p = absoluteFolderPath.indexOf("src");
		//String packagename = absoluteFolderPath.substring(p + 4);
		System.out.println("Selected File Path: " + absoluteFolderPath);

		//File fp = new File(Thread.currentThread().getContextClassLoader().getResource(packagename).getFile());
		File f = new File(absoluteFolderPath);
		if (f.exists()) {
			String[] files = f.list();

			for (int i = 0; i < files.length; i++) {
				System.out.println("File: " +files[i]);

				/*
				 * if(files[i].endsWith(".class")) {
				 * 
				 * System.out.println("Class: " + files[i].substring(0,
				 * files[i].length()-6));
				 * 
				 * try { classes.add(Class.forName(packagename.replace('/',
				 * '.')+'.'+files[i].substring(0, files[i].length()-6))); }
				 * catch (ClassNotFoundException e) { // TODO Auto-generated
				 * catch block e.printStackTrace(); }
				 * 
				 * }
				 */
			}
		} else {
			System.out.println("File does not exist");
		}
		return classes;

	}

	
	
	
	public static void main(String[] args) {
		GetClasses gc = new GetClasses();
		//ArrayList p = null;
		//p = gc.getAllClassesByFile("D:\\SMRITI/WORKSPACE/bdd/src/BDD/BinderFactory");
		//System.out.println(p);
		List filesList = gc.getAllClassObjects("D:\\assets\\src");
		
		System.out.println(filesList);
		

	}
	
	public List getAllFiles(String parentDirectory) {
		
		// Not required as the input String incoming is already a File.,
		//Replacing backword slash to forward slash - Starts
//		StringBuffer sb = new StringBuffer();
//		for(int i=0;i<parentDirectory.length();i++){
//			if(parentDirectory.charAt(i) == 92) {
//				sb.append("/");
//			}
//			else {
//				sb.append(parentDirectory.charAt(i));
//			}
//		}
//		System.out.println("Replaced Folder Name:"+sb.toString());
//      parentDirectory = sb.toString();
		// Replacing backword slash to forward slash - Ends
		
		
		List<File> allFiles = new ArrayList<File>();
		Queue<File> dirs = new LinkedList<File>();
		dirs.add(new File(parentDirectory));
		while (!dirs.isEmpty()) {
		  for (File f : dirs.poll().listFiles()) {
		    if (f.isDirectory()) {
		      dirs.add(f);
		    } else if (f.isFile()) {
		      allFiles.add(f);
		    }
		  }
		}
		return allFiles;
	}
	
	
	public List getAllClassObjects(String absoluteFolderPath) {
		List<File> allFiles = getAllFiles(absoluteFolderPath);
		List packageNames = new ArrayList();
		for(int i=0;i<allFiles.size();i++) {
			String tmpStr = ((File)allFiles.get(i)).getAbsolutePath();
			tmpStr = tmpStr.substring(absoluteFolderPath.length()+1, tmpStr.length());
			tmpStr = tmpStr.replace("\\", ".");
			tmpStr = tmpStr.replaceAll(".class", "");

			// $ - Innerclasses present inside a class., 
			// Hence using the mainclass is enough to parse
			
			if(!(tmpStr.indexOf("$")>0)){
				 try { 
					 URL url = new File(absoluteFolderPath).toURL();
  				     URL[] urls = new URL[]{url};
					 ClassLoader cl = new URLClassLoader(urls);
					 Class st = cl.loadClass(tmpStr);
					 packageNames.add(st);
					 System.out.println("PackageName: " + st);
					 
				 }
				 catch (MalformedURLException em) {
					 em.printStackTrace();
				 }
				 catch (ClassNotFoundException e) {
					 e.printStackTrace();
				 }
			}
		}
		return packageNames;

	}
}
