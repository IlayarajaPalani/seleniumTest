package BDD.Driver;

import java.io.IOException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.xml.bind.JAXBException;

import BDD.BinderFactory.ClassFactory;
import BDD.BinderFactory.JavaXmlBinder;
import BDD.BinderFactory.ReadXMLBinder;
import BDD.Objects.ClassObject;
import BDD.Objects.MethodObject;
import BDD.Test.Objects.Car;

public class Driver{

	public ClassObject o = new ClassObject();

	public boolean testMethod(String className, String methodName, Object expectedValue,  boolean flag, Object...inputs) throws ClassNotFoundException{

		Class c = Class.forName(className);
		o = ClassFactory.getClassObject(c);
		boolean b = false;
		for ( MethodObject mo : o.methods)
		{
			if(mo.name.equalsIgnoreCase(methodName))
			{

				// Get the native Class type in the ClassObject, 
				// and create an array of Class type for arguments.
				ArrayList paramList = mo.parameters;
				Class classArgs[] = new Class[paramList.size()];
				for(int i=0;i<paramList.size();i++) {
					ClassObject tmpClsObject = (ClassObject) paramList.get(i);
					classArgs[i]=tmpClsObject.myClass;
				}

				Method method = null;
				try {
					method = c.getMethod(mo.name, classArgs);
				} catch (Exception e) {
					e.printStackTrace();
				} 
				//System.out.println("Method Name: " + method.getName());
				Object result = null;
				Object co = null;
				Object[] inpObj = inputs;
				ArrayList<Object> pList  = new ArrayList<Object>();
				if(inputs!=null) {
					pList = new ArrayList<Object>(Arrays.asList(inputs));
                    System.out.println(pList.toString());
         
				}
				try {
					co = c.newInstance();
				} catch (Exception e) {
					e.printStackTrace();
				}	

				try {
					if(mo.parameters.size()== inpObj.length){
						System.out.println("Executing Method Name  : " + method.getName());
						System.out.println("Executing Class Name   : " + co.getClass().getName());
						if(inpObj!=null) {
							for(int i=0;i<inpObj.length;i++) {
								System.out.println("Executing Inputs       : " + inpObj.length + " " + inpObj[i]);
							}
						}
						
						result = method.invoke(co,inpObj);
						System.out.println("Method Returns " + result);
					}
					
					else if(mo.parameters.size()>pList.size()){
						for(int i=pList.size();i < mo.parameters.size();i++){
							//adding null is giving error :(
							 pList.add(i, 0);
							
						}
						Object[]ip= pList.toArray(new Object[pList.size()]);
						for (int i =0;i<ip.length;i++){
						System.out.println(ip[i]);}
						result = method.invoke(co,ip);
						
						System.out.println("Method Returns :" + result);
					}


					else{
						return false;
					}
				} catch (Exception e) {
					e.printStackTrace();
					return false;
				}
//
				if(mo.returnType.className.equalsIgnoreCase("void")){
					return true;
				}
				else {
					try{
						if(String.valueOf(result).equals(String.valueOf(expectedValue))) { //a ="a" b="a"; b=c c="a"
							return true;
						}
						else 
						{
							return result.equals(expectedValue);
						}
					}
					catch (Exception e) {
						e.printStackTrace();
						return false;
					}
				}
			}}
		return b;
	}
	//not required,can be directly called
	public int parameterSize(String className, String methodName){
		Class c = null;
		int p =0;
		try {
			c = Class.forName(className);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		o = ClassFactory.getClassObject(c);
		boolean b = false;
		for ( MethodObject mo : o.methods)
		{
			if(mo.name.equalsIgnoreCase(methodName))
			{
            ArrayList paramList = mo.parameters;
            p=paramList.size();
			}
		}
		return p;
	}
	public String methodModStatus(String className, String methodName, Object expectedValue,  boolean flag, Object...inputs){
		Class c = null;
		try {
			c = Class.forName(className);
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		o = ClassFactory.getClassObject(c);
		String status = null;
		for ( MethodObject mo : o.methods)
		{
			if(mo.name.equalsIgnoreCase(methodName))
			{
				ArrayList paramList = mo.parameters;
				Class classArgs[] = new Class[paramList.size()];
				for(int i=0;i<paramList.size();i++) {
					ClassObject tmpClsObject = (ClassObject) paramList.get(i);
					classArgs[i]=tmpClsObject.myClass;
				}

				Method method = null;
				try {
					method = c.getMethod(mo.name, classArgs);
				} catch (Exception e) {
					e.printStackTrace();
				} 
			    Object result = null;
				Object co = null;
				Object[] inpObj = inputs;
				ArrayList<Object> pList  = new ArrayList<Object>();
				if(inputs!=null) {
					pList = new ArrayList<Object>(Arrays.asList(inputs));
                    System.out.println(pList.toString());
         
				}
				try {
					co = c.newInstance();
				} catch (Exception e) {
					e.printStackTrace();
				}	

				if(mo.parameters.size()== inpObj.length){
						status= "NO";
						}
						
					else if(mo.parameters.size()>pList.size()){
						status = "YES";
					}

					else{
						status = "YES";
					}
		}
			}
		
		return status;
		
	}
	public Object calculatedResult(String className, String methodName, Object expectedValue,  boolean flag, Object...inputs){
		Object result = null;
		Class c = null;
		try {
			c = Class.forName(className);
		} catch (ClassNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		o = ClassFactory.getClassObject(c);
		boolean b = false;
		for ( MethodObject mo : o.methods)
		{
			if(mo.name.equalsIgnoreCase(methodName))
			{

				ArrayList paramList = mo.parameters;
				Class classArgs[] = new Class[paramList.size()];
				for(int i=0;i<paramList.size();i++) {
					ClassObject tmpClsObject = (ClassObject) paramList.get(i);
					classArgs[i]=tmpClsObject.myClass;
				}

				Method method = null;
				try {
					method = c.getMethod(mo.name, classArgs);
				} catch (Exception e) {
					e.printStackTrace();
				} 
				
				Object co = null;
				Object[] inpObj = inputs;
				ArrayList<Object> pList  = new ArrayList<Object>();
				if(inputs!=null) {
					pList = new ArrayList<Object>(Arrays.asList(inputs));
                    System.out.println(pList.toString());
         
				}
				try {
					co = c.newInstance();
				} catch (Exception e) {
					e.printStackTrace();
				}	

				try {
					if(mo.parameters.size()== inpObj.length){
						result = method.invoke(co,inpObj);
						System.out.println("Method Returns " + result);
					}
					
					else if(mo.parameters.size()>pList.size()){
						for(int i=pList.size();i < mo.parameters.size();i++){
							//adding null is giving error :(
							 pList.add(i, 0);
							
						}
						Object[]ip= pList.toArray(new Object[pList.size()]);
						for (int i =0;i<ip.length;i++){
						System.out.println(ip[i]);}
						result = method.invoke(co,ip);
						
					}
				} catch (Exception e) {
					e.printStackTrace();
					return false;
				   }
				}
			
			}
		
		return result;
	}
	
}