package BDD.Driver;

import java.io.File;
import java.io.IOException;

import javax.xml.bind.JAXBException;

import BDD.BinderFactory.JavaXmlBinder;
import BDD.Objects.ClassObject;
//class to store the class structure if it is not in repository
public class storeClass {
	public void storeClassStructure(ClassObject classO){
		File directory = new File("./UnitTestRepository/ClassStructure/"); 
		File[] listOfFiles = directory.listFiles(); 
		for (File file : listOfFiles) { 
			String name = file.getName(); 
			if (!(name.substring( 0, name.length()-4).equals(classO.className))) {
				try {
					JavaXmlBinder.responseBinder("./UnitTestRepository/ClassStructure/"+classO.packageName+"."+classO.className+".xml", classO);
				} catch (JAXBException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}}
	}

}
