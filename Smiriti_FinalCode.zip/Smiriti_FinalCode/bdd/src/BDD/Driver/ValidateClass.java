package BDD.Driver;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import BDD.BinderFactory.JavaXmlBinder;
import BDD.Objects.ClassObject;
import BDD.Objects.MethodObject;
import BDD.UserInput.GiveInputs;
import BDD.UserInput.SetXmlInput;

public class ValidateClass {
     static Driver1 d1 = new Driver1();
     public void validateMyClass(ClassObject classO, String className, String methodName){
		//search xml repository for the classname.xml filepath
		File directory = new File("./UnitTestRepository/ClassStructure/"); 
		File[] listOfFiles = directory.listFiles(); 
		for (File file : listOfFiles) { 
			String name = file.getName(); 
			if (name.substring( 0, name.length()-4).equals(className)) {
				//if classname.xml exists then unmarshall and check for the given method
				File file1 = new File("./UnitTestRepository/ClassStructure/"+ name);	
				try {
					JAXBContext jaxbContext1 = JAXBContext.newInstance(classO.getClass());
					Unmarshaller jaxbUnmarshaller1 = jaxbContext1.createUnmarshaller();
					ClassObject data1 = (ClassObject) jaxbUnmarshaller1.unmarshal(file1);
					for(MethodObject m: data1.methods){
						
						if(m.name.equalsIgnoreCase(methodName)){
							try
							{   //load the test case xml from the repository
								File file2 = new File("./UnitTestRepository/TestCases/"+className+"."+methodName+ ".xml");										
								JAXBContext jaxbContext2 = JAXBContext.newInstance(SetXmlInput.class);
					            Unmarshaller jaxbUnmarshaller2 = jaxbContext2.createUnmarshaller();
					            SetXmlInput data2 = (SetXmlInput) jaxbUnmarshaller2.unmarshal(file2);
								//System.out.println(data2.className+" , "+ data2.methodName+" , "+data2.expectedValue+" , " +data2.inputs);
					            boolean b = false;
					            //execute the same test case and report whether true or false
								try {
									b=d1.testMethod(data2.className, data2.methodName, data2.expectedValue, false, data2.inputs);
									System.out.println(b);
								} catch (ClassNotFoundException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
								} catch (JAXBException e) {
								e.printStackTrace();
							}
								
						}else{
							try {
								GiveInputs.giveInput("./UnitTestRepository/TestCases/"+className+methodName+".xml");
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
						
					}
					
				} catch (JAXBException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
	            }
			else{
				try {
					JavaXmlBinder.responseBinder("./UnitTestRepository/ClassStructure/"+className+".xml", d1.o);
					GiveInputs.giveInput("./UnitTestRepository/TestCases/"+className+methodName+".xml");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
                } catch (JAXBException e) {
			        e.printStackTrace();
		         }
			}}
		


		}
     public static void main(String[] args){
 		 ValidateClass v = new ValidateClass();
 		 v.validateMyClass(d1.o,"BDD.Test.Objects.Car", "getAppendedNumber");
    	 //File f = new File("../classstrucure");
    	 //System.out.println("Path:"+f.getAbsolutePath());
 	}}
