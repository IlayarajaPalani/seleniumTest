package BDD.Driver;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class findTestCase {
List<String> myTestCases= new ArrayList<String>();
	public List<String> testCases(String className, String methodName){
		File directory = new File("./UnitTestRepository/TestCases/");
		System.out.println(" Path: " + directory.getAbsolutePath());
		File[] listOfFiles = directory.listFiles(); 
		for (File file : listOfFiles) { 
			String name = file.getName(); 
			//classname and method name as char sequence
			int indx = name.indexOf(className+"."+methodName);
			//System.out.println("Index: " + indx);
			if (indx>-1) {
				myTestCases.add(name);
			}
			
		}
		return myTestCases;
		}
//public static void main(String[] args){
//	findTestCase f = new findTestCase();
//	System.out.println(f.testCases("BDD.Test.Objects.Car", "getAppendedNumber"));
//}
}
