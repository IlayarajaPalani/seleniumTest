package BDD.Driver;

import java.awt.List;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import BDD.UserInput.SetXmlInput;


public class TestCaseValidator {
	
	public ArrayList<Object> validate(String xmlPath){
	ArrayList<Object> testCase = new ArrayList<Object>();
		try
		{
			File file = new File("./UnitTestRepository/TestCases/" +xmlPath);										
			JAXBContext jaxbContext = JAXBContext.newInstance(SetXmlInput.class);
            Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
            SetXmlInput data = (SetXmlInput) jaxbUnmarshaller.unmarshal(file);
			//System.out.println(data.className+" , "+ data.methodName+" , "+data.expectedValue+" , " +data.inputs);
            testCase.add(0, data.className);
            testCase.add(1, data.methodName);
            
            
            Driver d1 = new Driver();
			boolean b = false;
			String modStatus=null;
			int paramSize = 0;
			Object actualResult = null;
			ArrayList<Object> inpList  = new ArrayList<Object>();
			if(data.inputs!=null) {
				inpList = new ArrayList<Object>(Arrays.asList(data.inputs));
                }
			//System.out.println(data.inputs.length); 
			try {
				paramSize= d1.parameterSize(data.className, data.methodName);
				testCase.add(2, paramSize);
				testCase.add(3, data.inputs.length);
				testCase.add(4, inpList.toString());
				actualResult= d1.calculatedResult(data.className, data.methodName, data.expectedValue, false, data.inputs);
				testCase.add(5, actualResult);
				testCase.add(6, data.expectedValue);
				modStatus= d1.methodModStatus(data.className, data.methodName, data.expectedValue, false, data.inputs);
				testCase.add(7, modStatus);
				b= d1.testMethod(data.className, data.methodName, data.expectedValue, false, data.inputs);
				testCase.add(8,  Boolean.toString(b));
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			} catch (JAXBException e) {
			e.printStackTrace();
			
		}
		return testCase;
		
		
	}

}
