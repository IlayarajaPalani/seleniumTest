package amex.fs.sft;




/*Description:
 * project: NGP Automation.
 * author: Viren Tiwari
 * This program is to download a file from outbox containing 2582 files .
 * 2583 files will be uploaded to SFT server  then download a file and  verified at the /Outbox folder   . 
 */
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.Login;
import amex.fs.commons.Logoff;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.Upload;
import amex.fs.commons.WriteTestResult;



	public class G107LastUploadedFile_Inbox{
		int teststatus=0;
		public static org.slf4j.Logger logger = LoggerFactory.getLogger(G107LastUploadedFile_Inbox.class);
		List<String> uploadedfile = new ArrayList<String>();
		
		 
		  Map connectionmap, uplaodmap;
		  String servername;
		  String qcurl;
		  String qcuname;
		  String qcpwd;
		  String domain;
		  String project;
		  String TLpath;
		  String TSet;
		  String runIdFile;
		  List<String> lst;
		  WriteTestResult wtr,testlog;
		  String TID;
		  
		 String uploadedfilename;
		 int temp=0;
		 
		
		
		  /* Main method which takes the parameter from the testng.xml
			  * 
			  */
		public static void main(String[] args) throws IOException, InterruptedException
		{
			G107LastUploadedFile_Inbox fg = new G107LastUploadedFile_Inbox();
			
				fg.f( "G107LastUploadedFile_Inbox", "2582FileTestUser","amex123", "21", "FTP", "Testfile2582", "TESTFILE.txt", "/inbox","UD", "BINARY", "PASSIVE");
				
		}
		
		
		@Test
		/* Loading Properties for ALM and SFT details
		   * 
		   */
		@Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode"})

		public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, String remotedirectory,String Action, String filetype, String filetransfermode ) throws IOException, InterruptedException{

		logger.info("G107LastUploadedFile_Inbox Execution Started");

		logger.info("Loading Properties");
		/* properties file loaded successfully
		  */
		

		LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);

		servername=lp.readProperty("server");
		qcurl=lp.readProperty("almurl");
		qcuname=lp.readProperty("almuser");
		qcpwd=lp.readProperty("almpwd");
		domain=lp.readProperty("almdomain");
		project=lp.readProperty("almproject");
		TLpath=lp.readProperty("almTLPath");
		TSet=lp.readProperty("almTSet");
		//BasicConfigurator.configure();
		int intport=Integer.parseInt(port);

		uplaodmap = new HashMap();

		
		

		Login lg=new Login(logger); 
		/* Login to SFT server using SFTP protocol and checking the connection status
		   * 
		   */


		connectionmap= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD, protocol);
		if((boolean) connectionmap.get("loginstatus")){ //check weather login is successful

		logger.info(sftuser+" logged into "+servername+" successfully ");

		Upload up=new Upload(logger); //uploading the files into the server
		
		for(int i=1;i<=4;i++)
		{
         
		uplaodmap = up.uploadFile(connectionmap, basefilename, physicalfile, remotedirectory, filetype, filetransfermode);
	
		if((boolean) uplaodmap.get("uploadstatus"))

		{
         uploadedfile.add((String) uplaodmap.get("Filename")) ;
         System.out.println(i+"  files  are uploaded ");
        
         
         logger.info(i+"  files  are uploaded ");
         Thread.sleep(FrameworkConstants.SleepValue);
		}
		
		else{
			
			teststatus=0;
		
		logger.info("unable to upload file");
		
		break;
		
	}
		}
		
		
		 
		if(uploadedfile.size()==4)

		{
			System.out.println("list of uploaed file are"+uploadedfile);
			logger.info("list of uploaed file are"+uploadedfile);
			
			Thread.sleep(FrameworkConstants.SleepValue);
		
           FTPClient ftpclient =new FTPClient ();
           
           ftpclient = (FTPClient) connectionmap.get("connection");
           
           boolean dir = ftpclient.changeWorkingDirectory("/inbox");
           
           if(dir)
           {
        	   System.out.println("directory is changed to inbox");
   			logger.info("directory is changed to inbox");
        	   
			FTPFile[] files= ftpclient.listFiles();
			System.out.println(ftpclient.listFiles());
			
			for (FTPFile file : files)
			{ 
			
				
			uploadedfilename = uploadedfile.get(temp);
			
			if(file.getName().equals(uploadedfilename))
			{
				teststatus=1;
				logger.info(uploadedfilename+"is present in inbox directory");
				System.out.println(uploadedfilename+"is present in inbox directory");
				temp++;
			
			}

			else  if(!file.getName().equals(uploadedfilename)&&temp<(uploadedfile.size())){	
				teststatus=0;
			
			logger.info(uploadedfilename+"\t isnt present in inbox directory");
			System.out.println(uploadedfilename+"\t isnt present in inbox directory");
			logger.info("testcase failed");
			System.out.println("testcase failed");
			
			break;
			
 }
		
		
			}
			 if(temp==4)
			{   teststatus=1;
				logger.info("testcase passed");
				System.out.println("testcase passed");
			}
           }
           else
           {  teststatus=0;
			
			logger.info("unable to change the directory");
			System.out.println("unable to change the directory");
			logger.info("testcase failed");
			System.out.println("testcase failed");}
		}
		
		else{
            teststatus=0;
			
			logger.info(uploadedfile.size()+"\t only uploaded");
			System.out.println(uploadedfile.size()+"\t only uploaded");
			logger.info("testcase failed");
			System.out.println("testcase failed");
			
		}
			
     
	
		
	
		
		
		}
		
		else{
			teststatus=0; // if different
			
			System.out.println("unable to login");
			logger.info("unable to login");
			teststatus=0;
		}
		
		
	
		TestcaseLookup tl =new TestcaseLookup(logger);
		//Identifying the testcase to be updated in the ALM based on the group number
		 
		lst = tl.lookupTestcase(FrameworkConstants.TCLookup,"G107");
	
		  LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
		  runIdFile=(lp1.readProperty("RUNID"));
		  wtr=new WriteTestResult();
		  testlog=new WriteTestResult();
		  
		  switch(almupdate)
		  {
		  case "No":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G107,"+ lst.get(i)+","+uplaodmap.get("TID")+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G107,"+ lst.get(i)+","+uplaodmap.get("TID")+",Failed");
				  }
				  
			  }
			  break;
		  case "no":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G107,"+ lst.get(i)+","+uplaodmap.get("TID")+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G107,"+ lst.get(i)+","+uplaodmap.get("TID")+",Failed");
				  }
				  
			  }
			  break;
	/*	  case "yes":
			  updateALM();
			  break;
		  case "Yes":
			  updateALM();
			  break;*/
		  }

		
		//ALM upload completed 
		//*logging off from the SFT server
		
		 

		logger.info("G107LastUploadedFile_Inbox Execution completed");
		System.out.println("G107LastUploadedFile_Inbox Execution completed");

		Logoff loff=new Logoff(logger);
		loff.logofffromSFT(connectionmap);

		
		
		}
		public void updateALM()
		 {
			 /* ALMConnect alm = new ALMConnect();
			  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
			  if(qcstatus){
				  if(teststatus==1){
					  String strStatus="Passed";
					  String filePath=FrameworkConstants.RunLog;
					  String workdir=System.getProperty("user.dir");
			          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
			          System.out.println("workdir"+workdir);
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Passed");
						  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						  wtr.writeToFile(runIdFile,"G107,"+ lst.get(i)+","+uplaodmap.get("TID")+",Passed");
					  }
				  }else{
						  String strStatus="Failed";
						  String filePath=FrameworkConstants.RunLog;
						  String workdir=System.getProperty("user.dir");
				          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
				          System.out.println("workdir"+workdir);
						  for(int i=0;i<lst.size();i++)
						  {
							  logger.info("Updating"+lst.get(i)+"status as Failed");
							  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
							  wtr.writeToFile(runIdFile,"G107,"+ lst.get(i)+","+uplaodmap.get("TID")+",Failed");
						  }
					  }
					  
				  }else{
				  System.out.println("Unable to login to ALM");
				  }*/

		 
		 }
		
	}