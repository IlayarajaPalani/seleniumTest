

package amex.fs.sft;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


import amex.fs.commons.Download;
import amex.fs.commons.FileComparision;
import amex.fs.commons.FileSizeCheck;
import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.Login;
import amex.fs.commons.Logoff;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.Upload;
import amex.fs.commons.WriteTestResult;

public class G150FTPUploadinbox {

	/**This test case executes the test cases categorized as G150**/
	/** You can the details in the SFT Test cases Category Lookup
	 * @throws IOException **/
	
      int teststatus=0;
      String filename=null;
	  public static org.slf4j.Logger logger=LoggerFactory.getLogger(G150FTPUploadinbox.class);
	  String server=null;
	  String srcFilename=null;
	  String destFilename=null;
	  FileSizeCheck fsizecheck=null;

	  Download download=new Download(logger);
	  Login con=new Login(logger);
	  Map dwnld;
	  Map connectionmap, uplaodmap,connection;
	  String servername;
	  String qcurl;
	  String qcuname;
	  String qcpwd;
	  String domain;
	  String project;
	  String TLpath;
	  String TSet;
	  String runIdFile;
	  List<String> lst;
	  WriteTestResult wtr,testlog;
	  String TID;
	  
	  Map<String, Object> upld = new HashMap<String, Object>();
	  
	 public static void main(String args[]) throws IOException, InterruptedException{
	 
		 G150FTPUploadinbox G150=new G150FTPUploadinbox();
		 G150.f("G150FTPUploadinbox","G150FTPUploadinbox","amex123","21","FTP","G150FTPUploadinboxFile","TESTFILE.docx","/inbox","UDD","ASCII","PASSIVE");
		 
	 }

	  
	  @BeforeTest
	  public void setup() throws Exception
	  {
		  
		  
		//  f("tcname","MAILUSER","amex123","21","FTP","MAIL_FILE","TEST4.txt","/inbox","U","ASCII","PASSIVE");
	  	  
	  }
	  
	  @Test
	  @Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode"})
	  public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, String remotedirectory, String action, String filetype, String filetransfermode) throws IOException, InterruptedException {
	  
	  
	  logger.info("G150FTPUploadinbox Execution Started");
	  logger.info("Loading Properties");
	  LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);
	  servername=lp.readProperty("server");
	  qcurl=lp.readProperty("almurl");
	  qcuname=lp.readProperty("almuser");
	  qcpwd=lp.readProperty("almpwd");
	  domain=lp.readProperty("almdomain");
	  project=lp.readProperty("almproject");
	  TLpath=lp.readProperty("almTLPath");
	  TSet=lp.readProperty("almTSet");
	  
	 // System.out.println(TLpath);
	  
	  /*boolean almconnection= alm.connectALM(qcurl, qcuname, qcpwd, domain, project);
	  if(almconnection)
	  {
		//System.out.println("QC Connection is successful");
		logger.info("QC Connection is successful");
		exit(0);
	  }else
	  {
		  System.out.println("QC Connection Failed"); 
		  logger.info("QC Connection Failed");
		  //exit(0);
	  }*/
	  
	  
	  logger.info("Invoking Login Module ");
	    
	  int intport=Integer.parseInt(port);
	
	  connection= con.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD, protocol);
	  
	  
	 // System.out.println(connection.get("loginstatus"));
	 // System.out.println(connection.values());
	  if((boolean) connection.get("loginstatus"))
	  {
		  logger.info("Login Successful");
		  Upload upld=new Upload(logger);
		  uplaodmap=upld.uploadFile(connection, basefilename, physicalfile, remotedirectory, filetype, filetransfermode);
		  System.out.println(uplaodmap.toString());
		  	if((boolean) uplaodmap.get("uploadstatus"))
		  	{
		  		  
		  		  logger.info("File Upload Complete");
		  		  System.out.println(action);
		  		  switch(action)
		  		  {
		  		  	case "UD" :
		  		  				Thread.sleep(FrameworkConstants.SleepValue);
		  		  				 filename=(String) uplaodmap.get("Filename");
		  		  				 dwnld= download.downloadFile(connection, filename, FrameworkConstants.DownloadDirectory+""+filename, FrameworkConstants.RemoteOutbox, filetype, filetransfermode);
		  		  				 System.out.println("B1");
		  		  				if((boolean) dwnld.get("downloadstatus"))
		  		  				{
		  		  					logger.info(FrameworkConstants.DownloadDirectory+filename+" Downloaded Successfully");
		  		  					teststatus=1;
		  		  				}else
		  		  				{
		  		  					logger.info(FrameworkConstants.DownloadDirectory+filename+" Download Failed");
		  		  					teststatus=0;
		  		  				}
		  		  				
		  		  				/*file comparison*/
		  		  				srcFilename=(String) uplaodmap.get("Filename");
		  		  				destFilename=(String) dwnld.get("Filename");
		  		  		
		  		  				
		  		  				FileSizeCheck fsizecheck=new FileSizeCheck(logger); 
		  		  				if(!fsizecheck.fileSizeVerification(physicalfile, FrameworkConstants.DownloadDirectory+"/"+destFilename))
		  		  				{
		  		  					
		  		  					logger.info("File size Verification - Failed");
		  		  					teststatus=0;
		  		  					
		  		  				}
		  		  				else
		  		  				{
		  		  						FileComparision fcontentcheck=new FileComparision(logger);
		  		  						if(!fcontentcheck.contentVerification(physicalfile, FrameworkConstants.DownloadDirectory+"/"+destFilename))
		  		  						{
		  		  							logger.info("File Content Verification - Failed");
		  		  							teststatus=0;
		  		  						}
		  		  						else
		  		  						{
		  		  							logger.info("File Content Verification - Success");
		  		  							teststatus=1;
		  		  						}
		  		  				}
		  		  				
		  		  				break;
		  		  	
		  		  	case "UDD"  :
  		  						
		  		  				Thread.sleep(FrameworkConstants.SleepValue);
  		  						filename=(String) uplaodmap.get("Filename");
  		  						dwnld= download.downloadFile(connection, filename, FrameworkConstants.DownloadDirectory+""+filename, FrameworkConstants.RemoteOutbox, filetype, filetransfermode);
  		  						
  		  						if((boolean) dwnld.get("downloadstatus"))
		  						{
		  							logger.info(FrameworkConstants.DownloadDirectory+filename+" Downloaded Successfully from Outbox");
		  							teststatus=1;
		  						}else
		  						{
		  							logger.info(FrameworkConstants.DownloadDirectory+filename+" Download Failed from Outbox");
		  							teststatus=0;
		  						} 		
  		  					Thread.sleep(FrameworkConstants.SleepValue);
  		  						dwnld= download.downloadFile(connection, filename, FrameworkConstants.DownloadDirectory+""+filename, FrameworkConstants.RemoteSent, filetype, filetransfermode);
  		  						if((boolean) dwnld.get("downloadstatus"))
		  						{
		  							logger.info(FrameworkConstants.DownloadDirectory+filename+" Downloaded Successfully from Sent");
		  							teststatus=1;
		  						}else
		  						{
		  							logger.info(FrameworkConstants.DownloadDirectory+filename+" Download Failed from Sent");
		  							teststatus=0;
		  						} 
  		  						
  		  					   /*file comparison*/
		  		  				srcFilename=(String) uplaodmap.get("Filename");
		  		  				destFilename=(String) dwnld.get("Filename");
		  		  				
		  		  				
		  		  			FileSizeCheck fsizcheck =new FileSizeCheck(logger); 
		  		  				if(!fsizcheck.fileSizeVerification(physicalfile, FrameworkConstants.DownloadDirectory+"/"+destFilename))
		  		  				{
		  		  					
		  		  					logger.info("File size Verification - Failed");
		  		  					teststatus=0;
		  		  					
		  		  				}
		  		  				else
		  		  				{
		  		  						FileComparision fcontentcheck=new FileComparision(logger);
		  		  						if(!fcontentcheck.contentVerification(physicalfile, FrameworkConstants.DownloadDirectory+"/"+destFilename))
		  		  						{
		  		  							logger.info("File Content Verification - Failed");
		  		  							teststatus=0;
		  		  						}
		  		  						else
		  		  						{
		  		  							logger.info("File Content Verification - Success");
		  		  							teststatus=1;
		  		  						}
		  		  				}
		  		  				
  		  						
		  		  				break;
		  		  				
		  		  		default:
		  		  			 	teststatus=1;
		  		  				break;
		  		  
		  		  				
		  		  		
		  		  			
		  		  }
		  		  

			}
		  	else
		  	{
		  		  logger.info("File Upload Failed");
				  teststatus=0;
				  TID="Upload Failed";
		  	}
		  	 TID=(String) uplaodmap.get("TID");  
	  }
	  
	  else
	  {
		
		  teststatus=0;
		  logger.info("Login Failed");
		  TID="Login Failed";
	  }
	  
	  
	  
	  
	  TestcaseLookup tlookup=new TestcaseLookup(logger);
	  //String groupname = tcname.substring(0, 2);
	   lst = tlookup.lookupTestcase(FrameworkConstants.TCLookup, "G150");
	  
		  LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
		  runIdFile=(lp1.readProperty("RUNID"));
		  wtr=new WriteTestResult();
		  testlog=new WriteTestResult();
		  
		  switch(almupdate)
		  {
		  case "No":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G150,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G150,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "no":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G150,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G150,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "yes":
			  updateALM();
			  break;
		  case "Yes":
			  updateALM();
			  break;
		  }

		  if(teststatus==1)
		  {
			  Logoff loff=new Logoff(logger);
			  loff.logofffromSFT(connection);
		  }
      logger.info("G150FTPUploadinbox Execution Finished");
	  
	  }


	private void exit(int i) {
		// TODO Auto-generated method stub
		
	}
	
	public void updateALM()
	 {
		  /*ALMConnect alm = new ALMConnect();
		  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
		  if(qcstatus){
			  if(teststatus==1){
				  String strStatus="Passed";
				  String filePath=FrameworkConstants.RunLog;
				  String workdir=System.getProperty("user.dir");
		          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
		          System.out.println("workdir"+workdir);
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Passed");
					  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
					  wtr.writeToFile(runIdFile,"G150,"+ lst.get(i)+","+TID+",Passed");
				  }
			  }else{
					  String strStatus="Failed";
					  String filePath=FrameworkConstants.RunLog;
					  String workdir=System.getProperty("user.dir");
			          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
			          System.out.println("workdir"+workdir);
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Failed");
						  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						  wtr.writeToFile(runIdFile,"G150,"+ lst.get(i)+","+TID+",Failed");
					  }
				  }
				  
			  }else{
			  System.out.println("Unable to login to ALM");
			  }*/

	 
	 }
}

