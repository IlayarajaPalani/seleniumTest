package amex.fs.sft;


/*Description:
 * project: NGP Automation.
 * author: Viren Tiwari
 * This program is to test CD non secure plus node using CD protocol .
 * A file will be uploaded to SFT server and the file will be verified at the T&M   . 
 */
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.Login;
import amex.fs.commons.Logoff;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.Upload;
import amex.fs.commons.WriteTestResult;


	public class G124CDInbound_EventMissing{
		boolean teststatus=false;
		public static org.slf4j.Logger logger = LoggerFactory.getLogger(G124CDInbound_EventMissing.class);
		 String uploadedfilename = null;
		
		 
		 Map connectionmap,connectionmap1,uplaodmap;
		  String servername,TPurl,TPuser,TPpwd;
		  String qcurl;
		  String qcuname;
		  String qcpwd;
		  String domain;
		  String project;
		  String TLpath;
		  String TSet;
		  String runIdFile;
		  List<String> lst;
		  WriteTestResult wtr,testlog;
		  String TID;
		  
		 boolean TMVerification_status = false;	
		 
		 
		  /* Main method which takes the parameter from the testng.xml
			  * 
			  */
		public static void main(String[] args) throws Throwable
		{
			G124CDInbound_EventMissing fg = new G124CDInbound_EventMissing();
			
				fg.f( "G124CDInbound_EventMissing", "CD_Nonsecure_plusnode_IN","amex123", "21", "FTP", "CD_INBOUND", "TESTFILE.txt", "/inbox",null,"ASCII", "PASSIVE",null);
				
		}
		
		
		@Test
		/* Loading Properties for ALM and SFT details
		   * 
		   */
		@Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode","Basefile2"})

		public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, String remotedirectory,String Action, String filetype, String filetransfermode,String Basefile2 ) throws Throwable{

		logger.info("G124CDInbound_EventMissing Execution Started");

		logger.info("Loading Properties");
		/* properties file loaded successfully
		  */
		

		LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);

		servername=lp.readProperty("server");

		qcurl=lp.readProperty("almurl");
        qcuname=lp.readProperty("almuser");
		qcpwd=lp.readProperty("almpwd");
		domain=lp.readProperty("almdomain");
		project=lp.readProperty("almproject");
		TLpath=lp.readProperty("almTLPath");
		TSet=lp.readProperty("almTSet");
		TPurl=lp.readProperty("tpurl");
		TPuser=lp.readProperty("tpuser");
		TPpwd=lp.readProperty("tppwd");
		//BasicConfigurator.configure();

		int intport=Integer.parseInt(port);

		 uplaodmap = new HashMap();

		

		

		Login lg=new Login(logger); 
		/* Login to SFT server using SFTP protocol and checking the connection status
		   * 
		   */


		connectionmap= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD, protocol);
		if((boolean) connectionmap.get("loginstatus")){ //check weather login is successful

		logger.info(sftuser+" logged into "+servername+" successfully ");

		Upload up=new Upload(logger); //uploading the files into the server

		uplaodmap = up.uploadFile(connectionmap, basefilename, physicalfile, remotedirectory, filetype, filetransfermode);
		
		 uploadedfilename = (String) uplaodmap.get("Filename");
		 
		if((boolean) uplaodmap.get("uploadstatus"))
		{
			G124CDInbound_EventMissing fg = new G124CDInbound_EventMissing();
			 Thread.sleep(FrameworkConstants.SleepValue); 
			 
			teststatus= fg.trackingidverify(sftuser,TPurl,TPuser,TPpwd);
			System.out.println("testcase  is"+teststatus);
			logger.info("testcase is "+teststatus);
			teststatus=true;
			
		}
			
      else{teststatus=false; // if different
		
			logger.info("unable to upload file");
			TID="Upload Failed";
			
		}
		TID=(String) uplaodmap.get("TID");
		}
		
		else{
			teststatus=false; // if different
			
			System.out.println("unable to login");
			logger.info("unable to login");
			teststatus=false;
			TID="Login Failed";
		}
		
		
	
		TestcaseLookup tl =new TestcaseLookup(logger);
		// Identifying the testcase to be updated in the ALM based on the group number
		 
		 
		  lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G124");
		
		  LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
		  runIdFile=(lp1.readProperty("RUNID"));
		  wtr=new WriteTestResult();
		  testlog=new WriteTestResult();
		  
		  switch(almupdate)
		  {
		  case "No":
			  if(teststatus)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G124,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G124,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "no":
			  if(teststatus)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G124,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G124,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
	/*	  case "yes":
			  updateALM();
			  break;
		  case "Yes":
			  updateALM();
			  break;*/
		  }
		
		
		
		/*logging off from the SFT server
		 * 
		 */

		logger.info("G124CDInbound_EventMissing Execution completed");
		System.out.println("G124CDInbound_EventMissing Execution completed");
        if(teststatus){
		Logoff loff=new Logoff(logger);
		loff.logofffromSFT(connectionmap);
        }

		
		
		}
		
	
		 public boolean trackingidverify(String tid,String url,String id,String pass) throws Throwable
		    {
		           System.out.println("connecting to firefox");
		           FirefoxProfile profile1 = new FirefoxProfile();  
		           profile1.setPreference("network.proxy.type",4);
		           
		           
		           WebDriver wd= new FirefoxDriver(profile1);
		           
		           wd.manage().window().maximize();
		           
		     wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		     logger.info("login to TM");
		     System.out.println("connected to TM");
		     System.out.println("opening TM");
		     wd.get(url);
		     wd.findElement(By.id("textboxuid_AD")).click();
		     wd.findElement(By.id("textboxuid_AD")).clear();
		     wd.findElement(By.id("textboxuid_AD")).sendKeys(id);
		     wd.findElement(By.id("textboxpwd_AD")).click();
		     wd.findElement(By.id("textboxpwd_AD")).clear();
		     wd.findElement(By.id("textboxpwd_AD")).sendKeys(pass);
		     wd.findElement(By.id("Login")).click();
		     wd.findElement(By.id("NavigationButton2")).click();
		     logger.info("login successful");
		     System.out.println("login successful");
		     
		     if (!wd.findElement(By.id("NavigationButton2")).isSelected()) {
		    	 wd.findElement(By.id("NavigationButton2")).click();
		     }
		     Thread.sleep(FrameworkConstants.SleepValue); 
		     if (!wd.findElement(By.xpath("/html/body/table[3]/tbody/tr[1]/td[3]/form/table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/font/input[2]")).isSelected()) {
		         wd.findElement(By.xpath("/html/body/table[3]/tbody/tr[1]/td[3]/form/table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/font/input[2]")).click();
		     }
		     
		     if (!wd.findElement(By.xpath("//table[@id='Table6']/tbody/tr[3]/td/table/tbody/tr[2]/td[1]/p/font/select//option[2]")).isSelected()) {
		         wd.findElement(By.xpath("//table[@id='Table6']/tbody/tr[3]/td/table/tbody/tr[2]/td[1]/p/font/select//option[2]")).click();
		     }
		     wd.findElement(By.name("filterByValue")).click();
		     wd.findElement(By.name("filterByValue")).clear();
		     wd.findElement(By.name("filterByValue")).sendKeys(tid);
		   
		    
		     Thread.sleep(FrameworkConstants.SleepValue); 
		     
	     
		     wd.findElement(By.name("search")).click();
		     wd.findElement(By.id("Picture14")).click();
		    
		     Boolean temp= wd.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[3]/form/div[2]/layer/table/tbody/tr[3]/td[3]/a/p/font")).getText().contains("File Push to SFT");
		   
		  // Boolean temp= wd.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[3]/form/div[5]/layer/table[2]/tbody/tr[2]/td[1]/p/font")).getText().contains("File Push to SFT");
		
		
		   if(temp==true)
		   {
			   System.out.println("passed");
			   TMVerification_status =true;
			   logger.info("file is suspended due to configuration");
			  String temp1= wd.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[3]/form/div[5]/layer/table[2]/tbody/tr[2]/td[5]/p")).getText();
			
			  System.out.println(temp1);
			  logger.info(" Message: /t"+temp1 );
		   }
		   else{
			   System.out.println("failed");
			   TMVerification_status =false;
			   logger.info("test case is failed");
		   }
		     
		     
		   logger.info("logoff from TM");
		     wd.findElement(By.name("logoutTM")).click();
		     Thread.sleep(FrameworkConstants.SleepValue); 
		     wd.quit();
		     
		           
		           
		           if( TMVerification_status)
		           {
		                  System.out.println(" the delivery is completed");
		           }
		           else
		           {
		                  System.out.println("the delivery got failed");
		           }
		           
		           return TMVerification_status;
		           
		           
		    }
		 
		 public void updateALM()
		 {
/*			  ALMConnect alm = new ALMConnect();
			  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
			  if(qcstatus){
				  if(teststatus){
					  String strStatus="Passed";
					  String filePath=FrameworkConstants.RunLog;
					  String workdir=System.getProperty("user.dir");
			          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
			          System.out.println("workdir"+workdir);
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Passed");
						  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						  wtr.writeToFile(runIdFile,"G124,"+ lst.get(i)+","+TID+",Passed");
					  }
				  }else{
						  String strStatus="Failed";
						  String filePath=FrameworkConstants.RunLog;
						  String workdir=System.getProperty("user.dir");
				          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
				          System.out.println("workdir"+workdir);
						  for(int i=0;i<lst.size();i++)
						  {
							  logger.info("Updating"+lst.get(i)+"status as Failed");
							  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
							  wtr.writeToFile(runIdFile,"G124,"+ lst.get(i)+","+TID+",Failed");
						  }
					  }
					  
				  }else{
				  System.out.println("Unable to login to ALM");
				  }*/

		 
		 }	
	}