package amex.fs.sft;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import org.slf4j.LoggerFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


import amex.fs.commons.AsciiFileComparison;
import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LinuxBoxFileTransfer;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.WriteTestResult;


public class G330_LFTP_SFTP {

	int teststatus=0;
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G330_LFTP_SFTP.class);
	String servername;
	String qcurl;
	String qcuname;
	String qcpwd;
	String domain;
	String project;
	String TLpath;
	String TSet;
	String runIdFile;
	List<String> lst;
	WriteTestResult wtr,testlog;
	boolean contentVerificationvalue = false;
	String TID= "";
	String action = "";
	public static void main(String[] args) throws IOException, ParseException, InterruptedException{
		G330_LFTP_SFTP fg = new G330_LFTP_SFTP();
		fg.fileTransfer("G330_LFTP_SFTP", "KARTHIKUSER", "no", "", "ftp", "KARTHIKFILE", "KARTHIKFILE", "", "POD","ASCII", "Binary","");
	}

	@Test
	@Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTypeDown","FileTransferMode"})
	public void fileTransfer(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, 
			String remotedirectory,	String action, String filetypeup, String filetypedown,String filetransfermode) throws IOException, InterruptedException{
		logger.info("G330_LFTP_SFTP Execution Started");
		logger.info("Loading Properties");
		LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);
		servername=lp.readProperty("server");
		qcurl=lp.readProperty("almurl");
		qcuname=lp.readProperty("almuser");
		qcpwd=lp.readProperty("almpwd");
		domain=lp.readProperty("almdomain");
		project=lp.readProperty("almproject");
		TLpath=lp.readProperty("almTLPath");
		TSet=lp.readProperty("almTSet");
		String unixServerUrl=lp.readProperty("unixServerUrl");
		String unixId =lp.readProperty("unixId");
		String unixPwd =lp.readProperty("unixPwd");
		String unixHomeDir =lp.readProperty("unixHomeDir");
		String ftpServer = lp.readProperty("server");
		this.action = action!=null?action:"EMPTY";
		
		LinuxBoxFileTransfer lbft = null;
		try {
			lbft = new LinuxBoxFileTransfer();
			boolean bootStatus = lbft.bootLinuxBox(unixServerUrl, 446, unixId, null, unixPwd);
			if(!bootStatus) throw new Exception("Unable to Boot linux box");

			lbft.sendCommand("lftp");
			
			String output = lbft.sendCommand("open -u "+sftuser+","+FrameworkConstants.DefaultSFTPWD+" sftp://"+servername);
			
			if(output.indexOf(sftuser+"@"+servername) != -1 ){
				teststatus=1;
				TID = "Login successfull";
			}
			else{
				teststatus=0;
				TID = "Login failed";
			}
				 
			
			lbft.sendCommand("bye");
				  

		} catch (Exception e) {
			TID = e.getMessage()!=null?e.getMessage():"Null Pointer Exception";
			e.printStackTrace();
			logger.info(e.getMessage());
		}
		finally{
			if(lbft != null){
				lbft.destroy();
			}
		}


		try{
			
			TestcaseLookup tl =new TestcaseLookup(logger);
			lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G330");
			//System.out.println(lst);
			LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
			runIdFile=(lp1.readProperty("RUNID"));
			wtr=new WriteTestResult();
			//testlog=new WriteTestResult();
			boolean loggedResult = false;
			switch(almupdate)
			{
			case "No":
				if(teststatus==1)
				{
					for(int i=0;i<lst.size();i++)
					{
						if(lst.get(i) != null && lst.get(i).indexOf(action) != -1) {
							loggedResult = true;
							logger.info("Updating"+lst.get(i)+"status as Passed");
							wtr.writeToFile(runIdFile,"G330,"+ lst.get(i)+","+TID+",Passed");
							System.out.println("Updating"+lst.get(i)+"status as Passed");
						}
					}
				}else
				{
					for(int i=0;i<lst.size();i++)
					{
						if(lst.get(i) != null && lst.get(i).indexOf(action) != -1) {
							loggedResult = true;
							logger.info("Updating"+lst.get(i)+"status as Failed");
							wtr.writeToFile(runIdFile,"G330,"+ lst.get(i)+","+TID+",Failed");
							System.out.println("Updating"+lst.get(i)+"status as Failed");
						}
					}

				}
				break;
			case "no":
				if(teststatus==1)
				{
					for(int i=0;i<lst.size();i++)
					{
						if(lst.get(i) != null && lst.get(i).indexOf(action) != -1) {
							loggedResult = true;
							logger.info("Updating"+lst.get(i)+"status as Passed");
							wtr.writeToFile(runIdFile,"G330,"+ lst.get(i)+","+TID+",Passed");
						}
					}
				}else
				{
					for(int i=0;i<lst.size();i++)
					{
						if(lst.get(i) != null && lst.get(i).indexOf(action) != -1) {
							loggedResult = true;
							logger.info("Updating"+lst.get(i)+"status as Failed");
							wtr.writeToFile(runIdFile,"G330,"+ lst.get(i)+","+TID+",Failed");
						}
					}

				}
				break;
			case "yes":
				updateALM();
				loggedResult = true;
				break;
			case "Yes":
				updateALM();
				loggedResult = true;
				break;
			}
			if(!loggedResult){
				System.out.println("Unable to update status for G330");
				logger.info("Unable to update status for G330");
			}
			logger.info("G330_LFTP_SFTP Execution completed");
		}
		catch(Exception e){
			logger.info("G330_LFTP_SFTP Execution failed");
			e.printStackTrace();
		}
		
	}

	/*Updating ALM*/
	public void updateALM()
	{
		/*ALMConnect alm = new ALMConnect();
		boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
		boolean loggedResult = false;
		if(qcstatus){
			if(teststatus==1){
				String strStatus="Passed";
				String filePath=FrameworkConstants.RunLog;
				String workdir=System.getProperty("user.dir");
				String fileName=workdir+"\\"+FrameworkConstants.RunLog;
				System.out.println("workdir"+workdir);
				for(int i=0;i<lst.size();i++)
				{
					if(lst.get(i) != null && lst.get(i).indexOf(action) != -1) {
						loggedResult = true;
						logger.info("Updating"+lst.get(i)+"status as Passed");
					alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						wtr.writeToFile(runIdFile,"G330,"+ lst.get(i)+","+TID+",Passed");
					}
				}
			}else{
				String strStatus="Failed";
				String filePath=FrameworkConstants.RunLog;
				String workdir=System.getProperty("user.dir");
				String fileName=workdir+"\\"+FrameworkConstants.RunLog;
				System.out.println("workdir"+workdir);
				for(int i=0;i<lst.size();i++)
				{
					if(lst.get(i) != null && lst.get(i).indexOf(action) != -1) {
						loggedResult = true;
						logger.info("Updating"+lst.get(i)+"status as Failed");
					alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						wtr.writeToFile(runIdFile,"G330,"+ lst.get(i)+","+TID+",Failed");
					}
				}
			}
			if(!loggedResult){
				System.out.println("Unable to update status for G330");
				logger.info("Unable to update status for G330");
			}

		}else{
			System.out.println("Unable to login to ALM");
			logger.info("Unable to login to ALM");
		}*/


	}
}
