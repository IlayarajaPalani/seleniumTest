/*Description:
 * This program is to test sentinal DOW.
 * A file will be uploaded to SFT server and the file will be verified at the outbox folder for the sentinal DOW. 
 */

package amex.fs.sft;

import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.LoggerFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import amex.fs.commons.FileComparision;
import amex.fs.commons.FileSizeCheck;
import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.SFTP_Module;
import amex.fs.commons.Sentinels;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.WriteTestResult;

public class G85SFTPDow
 {
	int teststatus=0;
	  Map connectionmap, uplaodmap;
	  String servername;
	  String qcurl;
	  String qcuname;
	  String qcpwd;
	  String domain;
	  String project;
	  String TLpath;
	  String TSet;
	  String runIdFile;
	  List<String> lst;
	  WriteTestResult wtr,testlog;
	  String TID;
	
	
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G85SFTPDow.class);
	 String uploadedfilename = null;
	 Sentinels sent = new Sentinels();
	 public static void main(String[] args) throws IOException, ParseException, InterruptedException{
		 G85SFTPDow fg = new G85SFTPDow();
		
		 fg.f("G85SFTPDow", "REMOTEDELUSER", "amex123", "22", "SFTP", "DOW", "TESTFILE.txt", "/inbox", "UD", "ASCII", "PASSIVE",null);
	
	 }
	
	 /* Main method which takes the parameter from the testng.xml
	  * 
	  */ 
	 
	 @Test
	 @Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode","Basefile2"})
	 public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, String remotedirectory, String action, String filetype, String filetransfermode,String basefilename2) throws IOException, InterruptedException, ParseException{
		  logger.info("G85SFTPDow Execution Started");
		  logger.info("Loading Properties");
		  LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);
		  servername=lp.readProperty("server");
		  qcurl=lp.readProperty("almurl");
		  qcuname=lp.readProperty("almuser");
		  qcpwd=lp.readProperty("almpwd");
		  domain=lp.readProperty("almdomain");
		  project=lp.readProperty("almproject");
		  TLpath=lp.readProperty("almTLPath");
		  TSet=lp.readProperty("almTSet");
		//BasicConfigurator.configure();
		  int intport=Integer.parseInt(port);
		  
		  logger.info("servername : "+servername);
		  logger.info("almurl : "+qcurl);
		  logger.info("qcuname :"+qcuname);
		  logger.info("qcpwd :"+qcpwd);
		  logger.info("domain : "+domain);
		  logger.info("project : "+project);
		  logger.info("TLpath : "+TLpath );
		  logger.info("TSet : "+TSet);
		  logger.info("intport : "+intport);
		  
		  logger.info("Properties file loaded successfully");
		 
		 /* properties file loaded successfully
		  * 
		  */
		  
		  Map dwnld = new HashMap();
		  boolean constatus= false;
		  boolean sizestatus = false;
		  /* Login to SFT server using SFTP and checking the connection status
		   * 
		   */
		 
		  SFTP_Module lg=new SFTP_Module(logger);
		  connectionmap= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD,null,FrameworkConstants.AcceptHostKey);
		  if((boolean) connectionmap.get("result")){
			  logger.info(sftuser+" logged into "+servername+" successfully ");
			  
			  
			  /* Uploading the file to SFT  once the above connection is successfull
				 * 
				 */
			  
		
			  
			  uplaodmap = lg.uploadFile(connectionmap, physicalfile, basefilename, remotedirectory);
			  if((boolean) uplaodmap.get("Status")){
				  String sentvalue = sent.sentinelCheck("DOW");
				  uploadedfilename = basefilename+"#"+sentvalue;
				  System.out.println("File with sentinel:"+uploadedfilename);
				  logger.info(sftuser+" uploaded "+uploadedfilename+" successfully ");
				 
				  /*Downloading file from user outbox or sent based on parameter action from tesng.xml
					UD --> download the file from outbox directory
					UDD --> download the file sent directory
					*/  
				  
				  switch(action)
				  {
				  case "UD" :
					  Thread.sleep(5000);
					 
		  				dwnld= lg.downloadFile(connectionmap, uploadedfilename, FrameworkConstants.DownloadDirectory+""+uploadedfilename, FrameworkConstants.RemoteOutbox);
		  				if((boolean) dwnld.get("Status"))
		  				{
		  					logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Downloaded Successfully");
		  					System.out.println(FrameworkConstants.DownloadDirectory+uploadedfilename+" Downloaded Successfully");
		  				}else
		  				{
		  					logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Download Failed");
		  					System.out.println(FrameworkConstants.DownloadDirectory+uploadedfilename+" Download Failed");
		  				}
		  				break;
		  	
				  case "UDD"  :
					  Thread.sleep(5000);
					  dwnld= lg.downloadFile(connectionmap, uploadedfilename, FrameworkConstants.DownloadDirectory+""+uploadedfilename, FrameworkConstants.RemoteOutbox);
 						
 						if((boolean) dwnld.get("Status"))
						{
							logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Downloaded Successfully from Outbox");
							Thread.sleep(5000);
							dwnld= lg.downloadFile(connectionmap, uploadedfilename, FrameworkConstants.DownloadDirectory+""+uploadedfilename, FrameworkConstants.RemoteOutbox);
	 						if((boolean) dwnld.get("Status"))
							{
								logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Downloaded Successfully from Sent");
							}else
							{
								logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Download Failed from Sent");
							} 
						}else
						{
							logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Download Failed from Outbox");
						} 
 						break;
		  				
		  		default:
		  			 	teststatus=0;
		  				break;
			  }
				  
				  /* validation comparing the downloaded file from the outbox with the uploaded physical file for filesize and file content
					 * 
					 */  
				  
				FileComparision fc = new FileComparision(logger);
				constatus = fc.contentVerification(physicalfile, FrameworkConstants.DownloadDirectory+"/"+uploadedfilename);
				logger.info("File comparision status:"+constatus);
				FileSizeCheck fs = new FileSizeCheck(logger);
				sizestatus = fs.fileSizeVerification(physicalfile, FrameworkConstants.DownloadDirectory+"/"+uploadedfilename);
				logger.info("File size verification status:"+sizestatus);
				if(constatus&&sizestatus){
					teststatus=1;
					System.out.println("comparission status is pass");
					logger.info("comparission status is pass");
					}else{
						teststatus=0;
						System.out.println("comparission status is fail");
						logger.info("comparission status is fail");
						 }
					 }
			  else{
				  teststatus=0;
				  logger.info(sftuser+" failed to upload "+basefilename);
				  TID="Upload Failed";
			  }
			  TID=(String)uplaodmap.get("TID");
		  }else{
			  logger.info(sftuser+" unable to login to "+servername);
			  teststatus=0;
			  TID="Login Failed";
		  }
		  
		  /* identifying the test case to be updated in the ALM based on the group number
		   * 
		   */
		  
		  System.out.println("the QC upload is started");
		   logger.info("the QC upload is started");
			  
			  TestcaseLookup tl =new TestcaseLookup(logger);
			  
			  lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G85");
			  LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
			  runIdFile=(lp1.readProperty("RUNID"));
			  wtr=new WriteTestResult();
			  testlog=new WriteTestResult();
			  
			  switch(almupdate)
			  {
			  case "No":
				  if(teststatus==1)
				  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Passed");
					  wtr.writeToFile(runIdFile,"G85,"+ lst.get(i)+","+TID+",Passed");
				  }
				  }else
				  {
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Failed");
						  wtr.writeToFile(runIdFile,"G85,"+ lst.get(i)+","+TID+",Failed");
					  }
					  
				  }
				  break;
			  case "no":
				  if(teststatus==1)
				  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Passed");
					  wtr.writeToFile(runIdFile,"G85,"+ lst.get(i)+","+TID+",Passed");
				  }
				  }else
				  {
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Failed");
						  wtr.writeToFile(runIdFile,"G85,"+ lst.get(i)+","+TID+",Failed");
					  }
					  
				  }
				  break;
			  /*case "yes":
				  updateALM();
				  break;
			  case "Yes":
				  updateALM();
				  break;*/
			  }

			
			//ALM upload completed 
			  /*logging off from the SFT server
			   * 
			   */
		
		
		  logger.info("G85SFTPDow Execution completed");
		  if(teststatus==1)
		  {
		  lg.logofffromSFT(connectionmap);
		  }
		  logger.info("logging off from the SFT server");
	 }
	 
	 public void updateALM()
	 {
		  /*ALMConnect alm = new ALMConnect();
		  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
		  if(qcstatus){
			  if(teststatus==1){
				  String strStatus="Passed";
				  String filePath=FrameworkConstants.RunLog;
				  String workdir=System.getProperty("user.dir");
		          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
		          System.out.println("workdir"+workdir);
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Passed");
					  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
					  wtr.writeToFile(runIdFile,"G85,"+ lst.get(i)+","+TID+",Passed");
				  }
			  }else{
					  String strStatus="Failed";
					  String filePath=FrameworkConstants.RunLog;
					  String workdir=System.getProperty("user.dir");
			          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
			          System.out.println("workdir"+workdir);
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Failed");
						  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						  wtr.writeToFile(runIdFile,"G85,"+ lst.get(i)+","+TID+",Failed");
					  }
				  }
				  
			  }else{
			  System.out.println("Unable to login to ALM");
			  }*/

	 
	 }	 
	 
 }


