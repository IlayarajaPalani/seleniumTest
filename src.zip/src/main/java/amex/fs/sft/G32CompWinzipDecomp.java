package amex.fs.sft;


	
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipOutputStream;

import org.slf4j.LoggerFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import amex.fs.commons.CreateZip;
import amex.fs.commons.Download;
import amex.fs.commons.FileComparision;
import amex.fs.commons.FileSizeCheck;
import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.Login;
import amex.fs.commons.Logoff;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.Upload;
import amex.fs.commons.WriteTestResult;

	public class G32CompWinzipDecomp {
		int teststatus=0;
		public static org.slf4j.Logger logger = LoggerFactory.getLogger(G32CompWinzipDecomp.class);
		 String uploadedfilename = null;
		 String decompressedfile = null;
		 //File  filename=null;
		 static File  filename=null;
		  Map connectionmap, uplaodmap;
		  String servername;
		  String qcurl;
		  String qcuname;
		  String qcpwd;
		  String domain;
		  String project;
		  String TLpath;
		  String TSet;
		  String runIdFile;
		  List<String> lst;
		  WriteTestResult wtr,testlog;
		  String TID;
		  CreateZip zipfileobj=new CreateZip();
		  

		public static void main(String[] args)
		{
			G32CompWinzipDecomp fg = new G32CompWinzipDecomp();
			try {
				fg.f("G32CompWinzipDecomp", "G32CompWinzipDecomp", "amex123", "21", "FTP", "G32CompWinzipDecompFile", "C:\\Users\\PJ5026032\\Desktop\\TESTING\\Automation test data\\Auto_Test_data_Sel\\Testfile.txt", "/inbox", "UD", "BINARY", "PASSIVE", "NULL");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		//Decompression starts here
		 @Test
		 @Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode","Basefile2"})
		 public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, String remotedirectory, String action, String filetype, String filetransfermode,String basefile2) throws IOException, InterruptedException{
			  logger.info("G32CompWinzipDecomp Execution Started");
			  logger.info("Loading Properties");
			  LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);
			  servername=lp.readProperty("server");
			  qcurl=lp.readProperty("almurl");
			  qcuname=lp.readProperty("almuser");
			  qcpwd=lp.readProperty("almpwd");
			  domain=lp.readProperty("almdomain");
			  project=lp.readProperty("almproject");
			  TLpath=lp.readProperty("almTLPath");
			  TSet=lp.readProperty("almTSet");
		//BasicConfigurator.configure();
			  int intport=Integer.parseInt(port);
			  Map dwnld = new HashMap();
			  Map dwnld1 = new HashMap();
			  boolean constatus= false;
			  boolean sizestatus = false;
			  
			
			  //To create zip file
			  

			 
			
			  String zfile1=FrameworkConstants.DownloadDirectory+"New.zip";
			  String zipfile= physicalfile;
			  
			  //String zipfile= physicalfile;
			  filename=new File(zipfile);
			  System.out.println(filename.getName());
			  FileOutputStream fout = new FileOutputStream(zfile1);
			  ZipOutputStream zos = new ZipOutputStream(fout);
			  
			//  ZipOutputStream zos=null;
			  try
			  {
				  zipfileobj.addToZipFile(zipfile, zos);
				  zipfileobj.closeZipFile();
			  }catch(Exception e)
			  {
				  System.out.print(e);
			  }
			  logger.info("File got ziped successfully ");
			 
		 
			  
			  
			  
			  
			  logger.info("Uploading ziped file ... ");
			  Login lg=new Login(logger);
			  connectionmap= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD, protocol);
			  if((boolean) connectionmap.get("loginstatus")){
				  logger.info(sftuser+" logged into "+servername+" successfully ");
				  Upload up=new Upload(logger);
				  uplaodmap = up.uploadFile(connectionmap, basefilename, zfile1, remotedirectory, filetype, filetransfermode);
				  
				  //Map uplaodmap = up.uploadFile(connectionmap, basefilename, zipfile, remotedirectory, filetype, filetransfermode);
				  if((boolean) uplaodmap.get("uploadstatus")){
					  uploadedfilename = (String) uplaodmap.get("Filename");
					  logger.info(sftuser+" uploaded "+uploadedfilename+" successfully ");
					  System.out.println("Winzip file uploaded for decompression ");
					  Download downloadmap = new Download(logger);
					  System.out.println(" download of deompressed file start");
					  switch(action)
					  {
					  case "UD" :
						  Thread.sleep(FrameworkConstants.SleepValue);
			  				dwnld= downloadmap.downloadFile(connectionmap, uploadedfilename, FrameworkConstants.DownloadDirectory+""+uploadedfilename, FrameworkConstants.RemoteOutbox, filetype, filetransfermode);
			  				if((boolean) dwnld.get("downloadstatus"))
			  				{
			  					logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Downloaded Successfully");
			  					System.out.println("the download is successful");
			  				}else
			  				{
			  					logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Download Failed");
			  					System.out.println("the download failed");
			  				}
			  				break;
			  	
					  case "UDD"  :
						  Thread.sleep(FrameworkConstants.SleepValue);
	 						dwnld= downloadmap.downloadFile(connectionmap, uploadedfilename, FrameworkConstants.DownloadDirectory+""+uploadedfilename, FrameworkConstants.RemoteOutbox, filetype, filetransfermode);
	 						
	 						if((boolean) dwnld.get("downloadstatus"))
							{
								logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Downloaded Successfully from Outbox");
								Thread.sleep(FrameworkConstants.SleepValue);
		 						dwnld= downloadmap.downloadFile(connectionmap, uploadedfilename, FrameworkConstants.DownloadDirectory+""+uploadedfilename, FrameworkConstants.RemoteSent, filetype, filetransfermode);
		 						if((boolean) dwnld.get("downloadstatus"))
								{
									logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Downloaded Successfully from Sent");
								}else
								{
									logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Download Failed from Sent");
								} 
							}else
							{
								logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Download Failed from Outbox");
							} 
	 						break;
			  				
			  		default:
			  			 	teststatus=0;
			  				break;
				  }
				  
					  //String fName1 = "./downloads/"+uploadedfilename;
				  String fn1= FrameworkConstants.DownloadDirectory+uploadedfilename;
					
					//Decompression ends here
					 
					//Comparison of files:
						  System.out.println("the file comparission is starting:");
						  
						  FileComparision fc = new FileComparision(logger);
							constatus = fc.contentVerification(physicalfile, fn1);
							logger.info("File comparison status:"+constatus);
							FileSizeCheck fs = new FileSizeCheck(logger);
							sizestatus = fs.fileSizeVerification(physicalfile, fn1);
							logger.info("File size verification status:"+sizestatus);
							if(constatus&&sizestatus){
								teststatus=1; //if file same 
								
								System.out.println("the file before upload and file after decompression are same");
								}else{
									teststatus=0; // if different
									System.out.println("the file before upload and file after decompression are different");
									 }
							
							System.out.println("the comparision status is: "+teststatus);
						  
						  
						  
						  
						  
					  
					  }
				  else{
					  teststatus=0;
					  logger.info(sftuser+" failed to upload "+basefilename);
					  TID="Upload Failed";
							  
						 }
				  
				  TID=(String)uplaodmap.get("TID");
				  }
			  
		 else{
				  logger.info(sftuser+" unable to login to "+servername);
				  teststatus=0;
				  TID="Login Failed";
			  }
		 
	
			  
			  
		 System.out.println("connecting to alm url ");
			  
			  TestcaseLookup tl =new TestcaseLookup(logger);
			  //String groupname = tcname.substring(0, 2);
			  lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G32");
			  System.out.println("1st :"+lst.size());
			  
			  LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
			  runIdFile=(lp1.readProperty("RUNID"));
			  wtr=new WriteTestResult();
			  testlog=new WriteTestResult();
			  
			  switch(almupdate)
			  {
			  case "No":
				  if(teststatus==1)
				  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Passed");
					  wtr.writeToFile(runIdFile,"G32,"+ lst.get(i)+","+TID+",Passed");
				  }
				  }else
				  {
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Failed");
						  wtr.writeToFile(runIdFile,"G32,"+ lst.get(i)+","+TID+",Failed");
					  }
					  
				  }
				  break;
			  case "no":
				  if(teststatus==1)
				  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Passed");
					  wtr.writeToFile(runIdFile,"G32,"+ lst.get(i)+","+TID+",Passed");
				  }
				  }else
				  {
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Failed");
						  wtr.writeToFile(runIdFile,"G32,"+ lst.get(i)+","+TID+",Failed");
					  }
					  
				  }
				  break;
			  /*case "yes":
				  updateALM();
				  break;
			  case "Yes":
				  updateALM();
				  break;*/
			  }

			  
			  if(teststatus==1)
			  {
			   Logoff loff=new Logoff(logger);
			   loff.logofffromSFT(connectionmap);
			  }
			  logger.info("G32CompWinzipDecomp Execution completed");
			  
			  
		 
	}
			  
		 public void updateALM()
		 {
			  /*ALMConnect alm = new ALMConnect();
			  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
			  if(qcstatus){
				  if(teststatus==1){
					  String strStatus="Passed";
					  String filePath=FrameworkConstants.RunLog;
					  String workdir=System.getProperty("user.dir");
			          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
			          System.out.println("workdir"+workdir);
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Passed");
						  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						  wtr.writeToFile(runIdFile,"G32,"+ lst.get(i)+","+TID+",Passed");
					  }
				  }else{
						  String strStatus="Failed";
						  String filePath=FrameworkConstants.RunLog;
						  String workdir=System.getProperty("user.dir");
				          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
				          System.out.println("workdir"+workdir);
						  for(int i=0;i<lst.size();i++)
						  {
							  logger.info("Updating"+lst.get(i)+"status as Failed");
							  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
							  wtr.writeToFile(runIdFile,"G32,"+ lst.get(i)+","+TID+",Failed");
						  }
					  }
					  
				  }else{
				  System.out.println("Unable to login to ALM");
				  }*/

		 
		 }	
	 
	}


