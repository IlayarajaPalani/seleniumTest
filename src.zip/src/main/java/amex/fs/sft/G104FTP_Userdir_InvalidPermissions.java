package amex.fs.sft;

/*Description:
 * project: NGP Automation.
 * author: Viren Tiwari
 * This program is to validate User directory is showing invalid permissions .
 * user login to sft and check User directory permissions   . 
 */

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.Login;
import amex.fs.commons.Logoff;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.WriteTestResult;




	public class G104FTP_Userdir_InvalidPermissions{
		int teststatus=0;
		public static org.slf4j.Logger logger = LoggerFactory.getLogger(G104FTP_Userdir_InvalidPermissions.class);
		 String uploadedfilename = null;
		 FTPClient ftpclient = null;
		 String filename;
		 String dirname;
		  Map connectionmap, uplaodmap;
		  String servername;
		  String qcurl;
		  String qcuname;
		  String qcpwd;
		  String domain;
		  String project;
		  String TLpath;
		  String TSet;
		  String runIdFile;
		  List<String> lst;
		  WriteTestResult wtr,testlog;
		  String TID="No File Uploaded";
		  
		  String username;
		  boolean constatus= false;
		  boolean sizestatus = false;
		  /* Main method which takes the parameter from the testng.xml
			  * 
			  */
		public static void main(String[] args) throws IOException, InterruptedException
		{
			G104FTP_Userdir_InvalidPermissions fg = new G104FTP_Userdir_InvalidPermissions();
			
				fg.f( "G104FTP_Userdir_InvalidPermissions", "G104FTP_Userdir_InvalidPermissions","amex123", "21", "FTP", null, null, null,null, null, null);
				
		}
		
		
		@Test
		/* Loading Properties for ALM and SFT details
		   * 
		   */
		@Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode"})

		public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, String remotedirectory,String Action, String filetype, String filetransfermode ) throws IOException, InterruptedException{
			try {

		logger.info("G104FTP_Userdir_InvalidPermissions Execution Started");

		logger.info("Loading Properties");
		/* properties file loaded successfully
		  */
		

		LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);

		servername=lp.readProperty("server");
		qcurl=lp.readProperty("almurl");
		qcuname=lp.readProperty("almuser");
		qcpwd=lp.readProperty("almpwd");
		domain=lp.readProperty("almdomain");
		project=lp.readProperty("almproject");
		TLpath=lp.readProperty("almTLPath");
		TSet=lp.readProperty("almTSet");
		  //BasicConfigurator.configure();
		int intport=Integer.parseInt(port);

		
		

		

		Login lg=new Login(logger); 
		/* Login to SFT server using SFTP protocol and checking the connection status
		   * 
		   */


		connectionmap= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD, protocol);
		if((boolean) connectionmap.get("loginstatus")){ //check weather login is successful

		logger.info(sftuser+" logged into "+servername+" successfully ");
		
			ftpclient = (FTPClient) connectionmap.get("connection");
			if (ftpclient!= null){
		
		 FTPFile[] directories = ftpclient.listDirectories("/");  //listing down the directory
		 
		 for(FTPFile dir1 : directories) 
		 {
		     username =dir1.getUser(); //getting the directory user
		    dirname=dir1.getName();
		    
		   System.out.println(dirname);
		   
		  if(!username.equals(sftuser))

		  {
			  teststatus=0;
			  logger.info("Directory is not associated with the user name");
			  System.out.println(username+"\t don't have this directory : "+ dirname+"\t permission");
			    logger.info(username+"\t don't have this directory :"+dirname+"\t permission");
			  System.out.println("test case is failed");
			  logger.info("test case failed");
			  break;
		  }
		  else{
			  teststatus=1;
			  logger.info("Directory is associated with the user name");
			  System.out.println(username+"\t have this directory  :"+ dirname+"\t permission");
			    logger.info(username+"\t have this directory  :"+ dirname+"\t permission");
		  }
		    
		 }
			if(teststatus==1)
			{
				 System.out.println("test case is pass");
				    logger.info("test case is pass");
			}
			}
			else{
				teststatus=0;
				System.out.println("FTPClient: \t unable to get the connection:");
				logger.info("FTPClient: \t unable to get the connection:");
				TID="Login Failed";
				
			}
		}
	
		
		
		   
		
		else{
			teststatus=0; // if different
			
			System.out.println("unable to login");
			logger.info("unable to login");
			teststatus=0;
			TID="Login Failed";
		}
		
		
	
		TestcaseLookup tl =new TestcaseLookup(logger);
		//Identifying the testcase to be updated in the ALM based on the group number
		 
		lst = tl.lookupTestcase(FrameworkConstants.TCLookup,"G104");
		
		  LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
		  runIdFile=(lp1.readProperty("RUNID"));
		  wtr=new WriteTestResult();
		  testlog=new WriteTestResult();
		  
		  switch(almupdate)
		  {
		  case "No":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G104,"+ lst.get(i)+","+uplaodmap.get("TID")+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G104,"+ lst.get(i)+","+uplaodmap.get("TID")+",Failed");
				  }
				  
			  }
			  break;
		  case "no":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G104,"+ lst.get(i)+","+uplaodmap.get("TID")+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G104,"+ lst.get(i)+","+uplaodmap.get("TID")+",Failed");
				  }
				  
			  }
			  break;
	
		  }

		
		//ALM upload completed 
		//*logging off from the SFT server
		
		 

		logger.info("G104FTP_Userdir_InvalidPermissions Execution completed");
		System.out.println("G104FTP_Userdir_InvalidPermissions Execution completed");

		Logoff loff=new Logoff(logger);
		loff.logofffromSFT(connectionmap);
			}
			 catch(NullPointerException e1)
		        {   e1.printStackTrace();
		        	logger.info("unable to proceed:\t"+e1);
		        	
		        	
		        }
				catch (Throwable e3) {
					
					e3.printStackTrace();
		        	logger.info("unable to proceed:\t"+e3);
		        	

				}
		
		}
		
		public void updateALM()
		 {
			 /* ALMConnect alm = new ALMConnect();
			  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
			  if(qcstatus){
				  if(teststatus==1){
					  String strStatus="Passed";
					  String filePath=FrameworkConstants.RunLog;
					  String workdir=System.getProperty("user.dir");
			          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
			          System.out.println("workdir"+workdir);
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Passed");
						  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						  wtr.writeToFile(runIdFile,"G104,"+ lst.get(i)+","+uplaodmap.get("TID")+",Passed");
					  }
				  }else{
						  String strStatus="Failed";
						  String filePath=FrameworkConstants.RunLog;
						  String workdir=System.getProperty("user.dir");
				          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
				          System.out.println("workdir"+workdir);
						  for(int i=0;i<lst.size();i++)
						  {
							  logger.info("Updating"+lst.get(i)+"status as Failed");
							  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
							  wtr.writeToFile(runIdFile,"G104,"+ lst.get(i)+","+uplaodmap.get("TID")+",Failed");
						  }
					  }
					  
				  }else{
				  System.out.println("Unable to login to ALM");
				  }

		 */
		 }
}