
package amex.fs.sft;

import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.LoggerFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import amex.fs.commons.FileComparision;
import amex.fs.commons.FileSizeCheck;
import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.SFTP_Module;
import amex.fs.commons.Sentinels;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.WriteTestResult;

public class G86SFTPDate
 {
	int teststatus=0;
	
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G86SFTPDate.class);
	 String uploadedfilename = null;
	  Map connectionmap, uplaodmap;
	  String servername;
	  String qcurl;
	  String qcuname;
	  String qcpwd;
	  String domain;
	  String project;
	  String TLpath;
	  String TSet;
	  String runIdFile;
	  List<String> lst;
	  WriteTestResult wtr,testlog;
	  String TID;
	 
	 Sentinels sent = new Sentinels();
	 public static void main(String[] args) throws IOException, ParseException, InterruptedException{
		 G86SFTPDate fg = new G86SFTPDate();
		 //String PvtKey,String acceptHostKey
		 fg.f("G86SFTPDate", "G86SFTPDATE", "amex123", "22", "SFTP", "G86SFTPDATEFile", "TESTFILE.txt", "/inbox", "UD", "ASCII", "PASSIVE",null);
		// fg.closeConnections();
	 }
	
	 @Test
	 @Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode","Basefile2"})
	 public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, String remotedirectory, String action, String filetype, String filetransfermode,String basefilename2) throws IOException, InterruptedException, ParseException{
		  logger.info("G86SFTPDate Execution Started");
		  logger.info("Loading Properties");
		  LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);
		  servername=lp.readProperty("server");
		  qcurl=lp.readProperty("almurl");
		  qcuname=lp.readProperty("almuser");
		  qcpwd=lp.readProperty("almpwd");
		  domain=lp.readProperty("almdomain");
		  project=lp.readProperty("almproject");
		  TLpath=lp.readProperty("almTLPath");
		  TSet=lp.readProperty("almTSet");
		//BasicConfigurator.configure();
		  int intport=Integer.parseInt(port);
		  Map dwnld = new HashMap();
		  boolean constatus= false;
		  boolean sizestatus = false;
		  SFTP_Module lg=new SFTP_Module(logger);
		  
		  connectionmap= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD,null,FrameworkConstants.AcceptHostKey);
		  if((boolean) connectionmap.get("result")){
			  logger.info(sftuser+" logged into "+servername+" successfully ");
			  //SFTP_Module_new up=new SFTP_Module_new(logger);
			  
			  uplaodmap = lg.uploadFile(connectionmap, physicalfile, basefilename, remotedirectory);
			  if((boolean) uplaodmap.get("Status")){
				  String sentvalue = sent.sentinelCheck("DATE");
				  uploadedfilename = basefilename+"#"+sentvalue;
				  System.out.println("File with sentinel:"+uploadedfilename);
				  logger.info(sftuser+" uploaded "+uploadedfilename+" successfully ");
				  //SFTP_Module_new downloadmap = new SFTP_Module_new(logger);
				  switch(action)
				  {
				  case "UD" :
					  Thread.sleep(FrameworkConstants.SleepValue);
					 
		  				dwnld= lg.downloadFile(connectionmap, uploadedfilename, FrameworkConstants.DownloadDirectory+""+uploadedfilename, FrameworkConstants.RemoteOutbox);
		  				if((boolean) dwnld.get("Status"))
		  				{
		  					logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Downloaded Successfully");
		  				}else
		  				{
		  					logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Download Failed");
		  				}
		  				break;
		  	
				  case "UDD"  :
					  Thread.sleep(FrameworkConstants.SleepValue);
					  dwnld= lg.downloadFile(connectionmap, uploadedfilename, FrameworkConstants.DownloadDirectory+""+uploadedfilename, FrameworkConstants.RemoteOutbox);
 						
 						if((boolean) dwnld.get("Status"))
						{
							logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Downloaded Successfully from Outbox");
							Thread.sleep(FrameworkConstants.SleepValue);
							dwnld= lg.downloadFile(connectionmap, uploadedfilename, FrameworkConstants.DownloadDirectory+""+uploadedfilename, FrameworkConstants.RemoteOutbox);
	 						if((boolean) dwnld.get("Status"))
							{
								logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Downloaded Successfully from Sent");
							}else
							{
								logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Download Failed from Sent");
							} 
						}else
						{
							logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Download Failed from Outbox");
						} 
 						break;
		  				
		  		default:
		  			 	teststatus=0;
		  				break;
			  }
				FileComparision fc = new FileComparision(logger);
				constatus = fc.contentVerification(physicalfile, FrameworkConstants.DownloadDirectory+"/"+uploadedfilename);
				logger.info("File comparision status:"+constatus);
				System.out.println("File comparision status:"+constatus);
				FileSizeCheck fs = new FileSizeCheck(logger);
				sizestatus = fs.fileSizeVerification(physicalfile, FrameworkConstants.DownloadDirectory+"/"+uploadedfilename);
				logger.info("File size verification status:"+sizestatus);
				System.out.println("File size verification status:"+sizestatus);
				if(constatus&&sizestatus){
					teststatus=1;
					}else{
						teststatus=0;
						 }
					 }
			  else{
				  teststatus=0;
				  logger.info(sftuser+" failed to upload "+basefilename);
				  TID="Upload Failed";
			  }
			  TID=(String)uplaodmap.get("TID");
			}else{
			  logger.info(sftuser+" unable to login to "+servername);
			  teststatus=0;
			  TID="Login Failed";
		  }
		  TestcaseLookup tl =new TestcaseLookup(logger);
		  //String groupname = tcname.substring(0, 2);
		   lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G86");
			  LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
			  runIdFile=(lp1.readProperty("RUNID"));
			  wtr=new WriteTestResult();
			  testlog=new WriteTestResult();
			  
			  switch(almupdate)
			  {
			  case "No":
				  if(teststatus==1)
				  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Passed");
					  wtr.writeToFile(runIdFile,"G86,"+ lst.get(i)+","+TID+",Passed");
				  }
				  }else
				  {
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Failed");
						  wtr.writeToFile(runIdFile,"G86,"+ lst.get(i)+","+TID+",Failed");
					  }
					  
				  }
				  break;
			  case "no":
				  if(teststatus==1)
				  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Passed");
					  wtr.writeToFile(runIdFile,"G86,"+ lst.get(i)+","+TID+",Passed");
				  }
				  }else
				  {
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Failed");
						  wtr.writeToFile(runIdFile,"G86,"+ lst.get(i)+","+TID+",Failed");
					  }
					  
				  }
				  break;
			  /*case "yes":
				  updateALM();
				  break;
			  case "Yes":
				  updateALM();
				  break;*/
			  }

		  		
		  logger.info("G86SFTPDate Execution completed");
		  
		  lg.logofffromSFT(connectionmap);
	 }
	
	 public void updateALM()
	 {
		  /*ALMConnect alm = new ALMConnect();
		  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
		  if(qcstatus){
			  if(teststatus==1){
				  String strStatus="Passed";
				  String filePath=FrameworkConstants.RunLog;
				  String workdir=System.getProperty("user.dir");
		          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
		          System.out.println("workdir"+workdir);
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Passed");
					  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
					  wtr.writeToFile(runIdFile,"G86,"+ lst.get(i)+","+TID+",Passed");
				  }
			  }else{
					  String strStatus="Failed";
					  String filePath=FrameworkConstants.RunLog;
					  String workdir=System.getProperty("user.dir");
			          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
			          System.out.println("workdir"+workdir);
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Failed");
						  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						  wtr.writeToFile(runIdFile,"G86,"+ lst.get(i)+","+TID+",Failed");
					  }
				  }
				  
			  }else{
			  System.out.println("Unable to login to ALM");
			  }*/

	 
	 }	 
	 
 }


