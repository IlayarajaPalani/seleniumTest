package amex.fs.sft;




/*Description:
 * project: NGP Automation.
 * author: Viren Tiwari
 * This program is to test Web contains Multilingual testing .
 * this script verifying the content of web app  . 
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.sun.corba.se.impl.orbutil.threadpool.TimeoutException;
import com.thoughtworks.selenium.webdriven.commands.GetText;

import amex.fs.commons.Download;
import amex.fs.commons.FileComparision;
import amex.fs.commons.FileSizeCheck;
import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.Login;
import amex.fs.commons.Logoff;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.Upload;
import amex.fs.commons.WriteTestResult;



	public class G87Multilingual_Testing{
		boolean teststatus=false;
		public static org.slf4j.Logger logger = LoggerFactory.getLogger(G87Multilingual_Testing.class);
		 
		
		 String element1;
		 String element2;
		  Map connectionmap, uplaodmap;
		  String servername;
		  String qcurl;
		  String qcuname;
		  String qcpwd;
		  String domain;
		  String project;
		  String TLpath;
		  String TSet;
		  String runIdFile;
		  List<String> lst;
		  WriteTestResult wtr,testlog;
		  String TID;
		 
		
		
		 
		 
		  /* Main method which takes the parameter from the testng.xml
			  * 
			  */
		public static void main(String[] args) throws Throwable
		{
			G87Multilingual_Testing fg = new G87Multilingual_Testing();
			
				fg.f( "G87Multilingual_Testing", "G87Multilingual_Testing","amex123", "443", "HTTPS", null, null, null,null,null, null,null);
				
		}
		
		
		@Test
		/* Loading Properties for ALM and SFT details
		   * 
		   */
		@Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode","Basefile2"})

		public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, String remotedirectory,String Action, String filetype, String filetransfermode,String Basefile2 ) throws Throwable{

		logger.info("G87Multilingual_Testing Execution Started");

		logger.info("Loading Properties");
		/* properties file loaded successfully
		  */
		

		LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);

		servername=lp.readProperty("server");
		qcurl=lp.readProperty("almurl");
		qcuname=lp.readProperty("almuser");
		qcpwd=lp.readProperty("almpwd");
		domain=lp.readProperty("almdomain");
		project=lp.readProperty("almproject");
		TLpath=lp.readProperty("almTLPath");
		TSet=lp.readProperty("almTSet");

		int intport=Integer.parseInt(port);

		

	        Thread.sleep(FrameworkConstants.SleepValue); 
	        G87Multilingual_Testing fg = new G87Multilingual_Testing();
			teststatus= fg.trackingidverify(servername,sftuser,FrameworkConstants.DefaultSFTPWD);
			System.out.println("testcase  is"+teststatus);
			logger.info("testcase is "+teststatus);
			
			
		
			
      
	
	
		TestcaseLookup tl =new TestcaseLookup(logger);
		// Identifying the testcase to be updated in the ALM based on the group number
		 
		 
		  lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G87");
		
		  LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
		  runIdFile=(lp1.readProperty("RUNID"));
		  wtr=new WriteTestResult();
		  testlog=new WriteTestResult();
		  
		  switch(almupdate)
		  {
		  case "No":
			  if(teststatus)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G87,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G87,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "no":
			  if(teststatus)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G87,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G87,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "yes":
			  updateALM();
			  break;
		  case "Yes":
			  updateALM();
			  break;
		  }
		
		/*logging off from the SFT server
		 * 
		 */

		logger.info("G87Multilingual_Testing Execution completed");
		System.out.println("G87Multilingual_Testing Execution completed");

		}

		
		
		
		
	
		 public boolean trackingidverify(String url,String id,String pass) throws TimeoutException
		    {
			 
		        try{   System.out.println("connecting to firefox");
		           FirefoxProfile profile1 = new FirefoxProfile();  
		           profile1.setPreference("network.proxy.type",4);
		           
		           
		           WebDriver wd= new FirefoxDriver(profile1);
		           
		           wd.manage().window().maximize();
		           
		     wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		     logger.info("login to TM");
		     System.out.println("connected to TM");
		     System.out.println("opening TM");
		     wd.get("https://"+url);
		     
		  System.out.println("verify the content for English Language");
		  logger.info("verify the content for English Language");
		  
		   wd.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div/div[2]/div/div[5]/div/div[2]/div")).click();
		 
		   wd.findElement(By.xpath("/html/body/div[2]/div[2]/div/div[2]/table/tbody/tr[1]/td/span")).click();
		   Thread.sleep(FrameworkConstants.SleepValue); 
		  // element1 =wd.findElement(By.xpath("/html/body/div[2]/div[2]/div/div[2]/table/tbody/tr[1]/td/span")).getText();
		 
		   element1="English";
		 
		  
		   Thread.sleep(FrameworkConstants.SleepValue); 
		  for(int i=1;i<=3;i++)
		  {
			  Thread.sleep(FrameworkConstants.SleepValue); 
		 element2=wd.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div/div[1]/div/div/div[3]/div")).getText();
		if(element1.equals("English")&&element2.equals("Secure File Transfer")||element1.equals("espa�ol (Spanish)")&&element2.equals("Transferencia Segura de Archivos")||element1.equals("fran�ais (French)")&&element2.equals("Transfert de fichier s�curis�"))
		{teststatus=true;
		
		 System.out.println(element1+ "is having" +element2);
		 logger.info(element1+"is having"+element2);
		}
		else{teststatus=false;
		break;}
		 Thread.sleep(FrameworkConstants.SleepValue);  
		 element2 =wd.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div/div[2]/div/div[1]/div")).getText();
		 if(element1.equals("English")&&element2.equals("Login")||element1.equals("espa�ol (Spanish)")&&element2.equals("Su cuenta")||element1.equals("fran�ais (French)")&&element2.equals("Identification"))
		 {teststatus=true;
		 System.out.println(element1+"is having"+element2);
		 logger.info(element1+"is having"+element2);
			}
			else{teststatus=false;
			break;}
		 Thread.sleep(FrameworkConstants.SleepValue);  
		 element2 =wd.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div/div[2]/div/div[3]/div/div/span[1]")).getText();
		 if(element1.equals("English")&&element2.equals("Username:")||element1.equals("espa�ol (Spanish)")&&element2.equals("Nombre de usuario:")||element1.equals("fran�ais (French)")&&element2.equals("Nom utilisateur:"))
		 {teststatus=true;
		 System.out.println(element1+"is having"+element2);
		 logger.info(element1+"is having"+element2);
			}
			else{teststatus=false;
			break;}
			
		 element2 =wd.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div/div[2]/div/div[4]/div/div/span[1]")).getText();
		 if(element1.equals("English")&&element2.equals("Password:")||element1.equals("espa�ol (Spanish)")&&element2.equals("Contrase�a:")||element1.equals("fran�ais (French)")&&element2.equals("Mot de passe:"))
		 {teststatus=true;
		 System.out.println(element1+"is having"+element2);
		 logger.info(element1+"is having"+element2);
			}
			else{teststatus=false;
			break;}
		 Thread.sleep(FrameworkConstants.SleepValue);  
		 element2 =wd.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div/div[2]/div/div[5]/div/div[1]/span")).getText();
		 if(element1.equals("English")&&element2.equals("Language:")||element1.equals("espa�ol (Spanish)")&&element2.equals("Idioma:")||element1.equals("fran�ais (French)")&&element2.equals("Langue:"))
		 {teststatus=true;
		 System.out.println(element1+"is having"+element2);
		 logger.info(element1+"is having"+element2);
			}
			else{teststatus=false;
			break;}
		 element2 =wd.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div/div[2]/div/div[9]/button")).getText();
		 if(element1.equals("English")&&element2.equals("Log In")||element1.equals("espa�ol (Spanish)")&&element2.equals("Inicie Sesi�n")||element1.equals("fran�ais (French)")&&element2.equals("Se connecter"))
		 {teststatus=true;
		 System.out.println(element1+"is having"+element2);
		 logger.info(element1+"is having"+element2);
			}
			else{teststatus=false;
			break;}
		 Thread.sleep(FrameworkConstants.SleepValue);  
		 if(teststatus==true)
		 {wd.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div/div[2]/div/div[3]/div/input")).clear();
		 wd.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div/div[2]/div/div[3]/div/input")).sendKeys(id);
		 Thread.sleep(FrameworkConstants.SleepValue);  
		 wd.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div/div[2]/div/div[4]/div/input")).clear();
		 wd.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div/div[2]/div/div[4]/div/input")).sendKeys(pass);
		 
		 Thread.sleep(FrameworkConstants.SleepValue); 
		 if (!wd.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div/div[2]/div/div[9]/button")).isSelected()) 
		 {
			 wd.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div/div[2]/div/div[9]/button")).click();
		 }
		 Thread.sleep(FrameworkConstants.SleepValue);  
		 element2 =wd.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div/div[2]/div/div/div[2]/div/div/div[1]/div/div[3]/button")).getText();
		 if(element1.equals("English")&&element2.equals("Upload File")||element1.equals("espa�ol (Spanish)")&&element2.equals("Subir Archivo")||element1.equals("fran�ais (French)")&&element2.equals("Envoyer fichier"))
		 {teststatus=true;
		 System.out.println(element1+"is having"+element2);
		 logger.info(element1+"is having"+element2);
			}
			else{teststatus=false;
			break;}
		
		 
		 element2 =wd.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div/div[2]/div/div/div[2]/div/div/div[1]/div/div[5]/button")).getText();
		 if(element1.equals("English")&&element2.equals("Set ASCII")||element1.equals("espa�ol (Spanish)")&&element2.equals("Seleccionar ASCII")||element1.equals("fran�ais (French)")&&element2.equals("Caract�res ASCII"))
		 {teststatus=true;
		 System.out.println(element1+"is having"+element2);
		 logger.info(element1+"is having"+element2);
			}
			else{teststatus=false;
			break;}
		 Thread.sleep(FrameworkConstants.SleepValue);  
		 element2 =wd.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div/div[2]/div/div/div[3]/div/div[1]/div[1]/div/table/tbody/tr/td[1]/div[3]")).getText();
		 if(element1.equals("English")&&element2.equals("TYPE")||element1.equals("espa�ol (Spanish)")&&element2.equals("TIPO")||element1.equals("fran�ais (French)")&&element2.equals("TYPE"))
		 {teststatus=true;
		 System.out.println(element1+"is having"+element2);
		 logger.info(element1+"is having"+element2);
			}
			else{teststatus=false;
			break;}
		 Thread.sleep(FrameworkConstants.SleepValue);  
		 element2 =wd.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div/div[2]/div/div/div[3]/div/div[1]/div[1]/div/table/tbody/tr/td[2]/div[3]")).getText();
		 if(element1.equals("English")&&element2.equals("NAME")||element1.equals("espa�ol (Spanish)")&&element2.equals("NOMBRES")||element1.equals("fran�ais (French)")&&element2.equals("NOM"))
		 {teststatus=true;
		 System.out.println(element1+"is having"+element2);
		 logger.info(element1+"is having"+element2);
			}
			else{teststatus=false;
			break;}
		 Thread.sleep(FrameworkConstants.SleepValue);  
		 element2 =wd.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div/div[2]/div/div/div[3]/div/div[1]/div[1]/div/table/tbody/tr/td[3]/div[3]")).getText();
		 
		 if(element1.equals("English")&&element2.equals("SIZE [B]")||element1.equals("espa�ol (Spanish)")&&element2.equals("TAMA�O [B]")||element1.equals("fran�ais (French)")&&element2.equals("TAILLE [B]"))
		 {teststatus=true;
		 System.out.println(element1+"is having"+element2);
		 logger.info(element1+"is having"+element2);
			}
			else{teststatus=false;
			break;}
		 
		 Thread.sleep(FrameworkConstants.SleepValue);  
		 element2 =wd.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div/div[2]/div/div/div[3]/div/div[1]/div[1]/div/table/tbody/tr/td[4]/div[3]")).getText();
		 if(element1.equals("English")&&element2.equals("DATE")||element1.equals("espa�ol (Spanish)")&&element2.equals("FECHA")||element1.equals("fran�ais (French)")&&element2.equals("DATE"))
		 {teststatus=true;
		 System.out.println(element1+"is having"+element2);
		 logger.info(element1+"is having"+element2);
			}
			else{teststatus=false;
			break;}
		 Thread.sleep(FrameworkConstants.SleepValue);  
		 Thread.sleep(FrameworkConstants.SleepValue);  
		 if(teststatus==true)
		 {
			
			 System.out.println("test case passed");
			wd.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div/div[1]/div/div[2]/div/div/div/div/span/span")).click();
			wd.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div/div[2]/div/div[2]/div/div[3]/div/span/span")).click();
			
			 
			 if(i==1)
			 { 
				  System.out.println("verify the content for Spanish Language");
				  logger.info("verify the content for Spanish Language");
				 wd.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div/div[2]/div/div[5]/div/div[2]/div")).click();
				 wd.findElement(By.xpath("/html/body/div[2]/div[2]/div/div[2]/table/tbody/tr[2]/td/span")).click();
			   //element1 =wd.findElement(By.xpath("/html/body/div[2]/div[2]/div/div[2]/table/tbody/tr[2]/td/span")).getText();
				 element1="espa�ol (Spanish)";
				 Thread.sleep(FrameworkConstants.SleepValue); 
			 }
			 else if (i==2)
			 {   System.out.println("verify the content for French Language");
			    logger.info("verify the content for French Language");
				wd.findElement(By.xpath("/html/body/div[1]/div/div[2]/div/div/div/div/div[2]/div/div[5]/div/div[2]/div")).click();
			   wd.findElement(By.xpath("/html/body/div[2]/div[2]/div/div[2]/table/tbody/tr[3]/td/span")).click();
			   //element1 =wd.findElement(By.xpath("/html/body/div[2]/div[2]/div/div[2]/table/tbody/tr[3]/td/span")).getText();
			   
			   element1="fran�ais (French)";
			   Thread.sleep(FrameworkConstants.SleepValue); 
			   }
			 else{
			 Thread.sleep(FrameworkConstants.SleepValue); 
			
			wd.close();
		 }
			 }
		 else{
			 System.out.println("test case is failed");
			 logger.info("test case is falied");
			 wd.close();
		 }
		 }
		 else{
			 System.out.println("test case is failed");
			 logger.info("test case is falied");
			 wd.close();
		 }
		  }
		        }
		        
			
		        catch(NullPointerException e1)
		        {   e1.printStackTrace();
		        	logger.info("unable to proceed"+e1);
		        	teststatus=false;
		        	
		        }
		        catch(NoSuchElementException e2)
		        {   
		        	e2.printStackTrace();
		        	logger.info("unable to proceed"+e2);
		        	teststatus=false;
		        } catch (Throwable e3) {
					
					e3.printStackTrace();
		        	logger.info("unable to proceed"+e3);
		        	teststatus=false;

				}
		
		           
		        
			
					return teststatus;
				  
		           
		          
		    }
	
		 public void updateALM()
		 {
			 /* ALMConnect alm = new ALMConnect();
			  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
			  if(qcstatus){
				  if(teststatus){
					  String strStatus="Passed";
					  String filePath=FrameworkConstants.RunLog;
					  String workdir=System.getProperty("user.dir");
			          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
			          System.out.println("workdir"+workdir);
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Passed");
						  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						  wtr.writeToFile(runIdFile,"G87,"+ lst.get(i)+","+TID+",Passed");
					  }
				  }else{
						  String strStatus="Failed";
						  String filePath=FrameworkConstants.RunLog;
						  String workdir=System.getProperty("user.dir");
				          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
				          System.out.println("workdir"+workdir);
						  for(int i=0;i<lst.size();i++)
						  {
							  logger.info("Updating"+lst.get(i)+"status as Failed");
							  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
							  wtr.writeToFile(runIdFile,"G87,"+ lst.get(i)+","+TID+",Failed");
						  }
					  }
					  
				  }else{
				  System.out.println("Unable to login to ALM");
				  }
*/
		 
		 }		 
		 
		 
	}