package amex.fs.sft;

import java.io.IOException;
import java.util.List;

import org.slf4j.LoggerFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import amex.fs.commons.CreateRetrievalXML;
import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.MQClient;
import amex.fs.commons.TMValidation;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.WriteTestResult;

public class G600RETFTPActiveMode {

	/******Retrieval with ftp protocol active mode******/
	boolean mqpush=false;
	WriteTestResult wtr,testlog;
	String runIdFile;
	String tempTID;
	List<String> lst;
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G600RETFTPActiveMode.class);
	CreateRetrievalXML retxml;
	
	 @Test
	 @Parameters({"TestCaseName","XmitID","UserID","BaseFileName","RemoteFilePath","RemoteFileName","FileFlowSteps","XMLFileName"})
	 public void f(String tcname,String xmitid,String userid,String basefilename,String remotefilepath,String remotefilename,String fileflowsteps, String xmlfilename) throws Throwable{
	try {
		retxml=new CreateRetrievalXML(false);
		tempTID=retxml.createXML("./test-data/ExecutionSheet_RETRIEVAL.xls", "G600RETXML.xml",remotefilepath,remotefilename);
		System.out.println("TID generated "+tempTID);
		System.out.println(xmlfilename);
		MQClient mqc = new MQClient();
		mqpush=mqc.push(FrameworkConstants.RETRIEVAL_QMANAGER, FrameworkConstants.RETRIEVAL_QMANAGERNAME, FrameworkConstants.RETRIEVAL_HOSTNAME, FrameworkConstants.RETRIEVAL_PORT, FrameworkConstants.RETRIEVAL_CHANNEL, xmlfilename);
		System.out.println(mqpush);

	} catch (Exception e) {
		e.printStackTrace();
		mqpush=false;
	}
	
	TestcaseLookup tl =new TestcaseLookup(logger);
	  //String groupname = tcname.substring(0, 2);
	 lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G600");
	 System.out.println(lst.size());
	 LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
	 runIdFile=(lp1.readProperty("RUNID"));
	 wtr=new WriteTestResult();
	 testlog=new WriteTestResult();
	 
	 
	if(mqpush)
	{	
		 	
		TMValidation tmver=new TMValidation();
		if(tmver.TNMverify(FrameworkConstants.TMTrackingID, tempTID, fileflowsteps))
		{
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G600,"+ lst.get(i)+","+tempTID+",Passed");
			  }
			
		}else
		{
			 for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Failed");
				  wtr.writeToFile(runIdFile,"G600,"+ lst.get(i)+","+tempTID+",Failed");
			  }
		}
	}else
	{
		 for(int i=0;i<lst.size();i++)
		  {
			  logger.info("Updating"+lst.get(i)+"status as Failed");
			  wtr.writeToFile(runIdFile,"G600,"+ lst.get(i)+","+tempTID+",Failed");
		  }
	}
	
}
}