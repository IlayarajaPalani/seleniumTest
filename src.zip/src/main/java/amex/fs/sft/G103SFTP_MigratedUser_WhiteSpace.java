package amex.fs.sft;



/*Description:
 * project: NGP Automation.
 * author: Viren Tiwari
 * This program is to test weather or not a user is able to login to SFT if white space is in userid .
 * SFTP user is trying to login to SFT it must be failed to login.
 */


import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import amex.fs.commons.CompareExcel;
import amex.fs.commons.Download;
import amex.fs.commons.FileComparision;
import amex.fs.commons.FileSizeCheck;
import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.Login;
import amex.fs.commons.Logoff;
import amex.fs.commons.SFTP_Module;
import amex.fs.commons.Sentinels;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.Upload;
import amex.fs.commons.WriteTestResult;

 public class G103SFTP_MigratedUser_WhiteSpace
 {
	int teststatus=0;
	boolean teststatus1=false;
	boolean teststatus2=false;
	  Map connectionmap, uplaodmap;
	  String servername;
	  String qcurl;
	  String qcuname;
	  String qcpwd;
	  String domain;
	  String project;
	  String TLpath;
	  String TSet;
	  String runIdFile;
	  List<String> lst;
	  WriteTestResult wtr,testlog;
	  String TID;
	  
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G103SFTP_MigratedUser_WhiteSpace.class);
	 String uploadedfilename = null;
	 Sentinels sent = new Sentinels();
	 public static void main(String[] args) throws IOException, ParseException, InterruptedException{
		 G103SFTP_MigratedUser_WhiteSpace fg = new G103SFTP_MigratedUser_WhiteSpace();
		 //String PvtKey,String acceptHostKey
		 fg.f("G103SFTP_MigratedUser_WhiteSpace","'G103SFTP_MigratedUser_WhiteSpace", "no", "22", "SFTP", "G103SFTP_MigratedUser_WhiteSpaceFile", "TESTFILE.txt", "/inbox", "UD", "BINARY", "PASSIVE",null);
		// fg.closeConnections();
	 }
	 /* Main method which takes the parameter from the testng.xml
	  * 
	  */
	 @Test
	 @Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode","Basefile2"})
	 public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, String remotedirectory, String action, String filetype, String filetransfermode,String basefilename2) throws IOException, InterruptedException, ParseException{
		  logger.info("G103SFTP_MigratedUser_WhiteSpace Execution Started");
          logger.info("Loading Properties for ALM and SFT");
		  
		  /* Loading Properties for ALM and SFT details
		   * 
		   */
		  LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);
		  servername=lp.readProperty("server");
		  qcurl=lp.readProperty("almurl");
		  qcuname=lp.readProperty("almuser");
		  qcpwd=lp.readProperty("almpwd");
		  domain=lp.readProperty("almdomain");
		  project=lp.readProperty("almproject");
		  TLpath=lp.readProperty("almTLPath");
		  TSet=lp.readProperty("almTSet");
		  int intport=Integer.parseInt(port);
		  
		  logger.info("servername : "+servername);
		  logger.info("almurl : "+qcurl);
		  logger.info("qcuname :"+qcuname);
		  logger.info("domain : "+domain);
		  logger.info("project : "+project);
		  logger.info("TLpath : "+TLpath );
		  logger.info("TSet : "+TSet);
		  logger.info("intport : "+intport);
		  
		  logger.info("Properties file loaded successfully");
			 
			 /* properties file loaded successfully
			  * 
			  */
		  
		 
		  SFTP_Module lg=new SFTP_Module(logger);
		  /* Login to SFT server using SFTP protocol and checking the connection status
		   * 
		   */
		  //login to SFT without space at the user name end
		  System.out.println("login to SFT without space at the user name end");
		  logger.info("login to SFT without space at the user name end");
		  
		try
		{
		  connectionmap= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD,null,FrameworkConstants.AcceptHostKey);
		}
		catch ( NullPointerException npe) {
            npe.printStackTrace();
        	System.out.println("error");
  		  //unable to login to sft server due to white space at the end of the user ID
  		
  			  logger.info(sftuser+" unable to login to sft server "+servername+" ");
  			  System.out.println(sftuser+" unable to login to "+servername);
  			  logger.info("test case Failed");
  			  System.out.println("test case Failed");
  			  teststatus1=false;
  			  TID="Login Failed for Username without Whitespace ";
  			System.out.println("teststatus1  "+teststatus1);
  			
}
		TID=(String)connectionmap.get("TID");
		System.out.println("connectionmap.get "+connectionmap.get("result"));
		
		if((boolean)connectionmap.get("result"))
		{
			 logger.info(sftuser+" without  space user able to login to sft server "+servername);
 			  System.out.println(sftuser+" without space user  able to login to "+servername);
 			  logger.info("test case passed");
 			 System.out.println("test case passed");
 			 TID="Login Successful for Username without Whitespace"; 
 			 teststatus1=true;
 			 System.out.println("teststatus1  "+teststatus1);
 		   	
		}
		
		
		lg.logofffromSFT(connectionmap);
		
		//*********************************************************
		//Login with space at the user name end
		
		System.out.println("login to SFT with space at the user name end");
		  logger.info("login to SFT with space at the user name end");
		
		 //String sftuser1=sftuser+" ";
		  String sftuser1=" "+sftuser;
		
		  try
			{
			  connectionmap= lg.logintoSFT(servername, intport, sftuser1, FrameworkConstants.DefaultSFTPWD,null,FrameworkConstants.AcceptHostKey);
			}
			catch ( NullPointerException npe) {
	            npe.printStackTrace();
	        	System.out.println("error");
	  		  //unable to login to sft server due to white space at the end of the user ID
	  		
	  			  logger.info(sftuser1+" unable to login to sft server "+servername+" due to white space at the end of the user ID");
	  			  System.out.println(sftuser1+" unable to login to "+servername+" due to white space in the usr id");
	  			  logger.info("test case passed");
	  			  System.out.println("test case passed");
	  			  teststatus2=true;
	  			  TID="Login Failed for user with white space";
	  			
	}
			TID=(String)connectionmap.get("TID");
			System.out.println("connectionmap.get "+connectionmap.get("result"));
			
			if((boolean)connectionmap.get("result"))
			{
				 logger.info(sftuser1+" with space at the end is able to login to sft server "+servername);
	 			  System.out.println(sftuser1+" with space at the end is able to login to "+servername);
	 			  logger.info("test case failed");
	 			 System.out.println("test case failed");
	 			 TID="Login Successful for Username with Whitespace"; 
	 			teststatus2=false;
	 		   	
			}
			else
			{
				logger.info(sftuser1+" unable to login to sft server "+servername+" due to white space at the end of the user ID");
	  			  System.out.println(sftuser1+" unable to login to "+servername+" due to white space in the usr id");
	  			  logger.info("test case passed");
	  			  System.out.println("test case passed");
	  			  teststatus2=true;
	  			  TID="Login Failed for user with white space";
	  			System.out.println("test case status:"+teststatus2);
				
			}
			
			
			lg.logofffromSFT(connectionmap);
		
		
		
		//determine the status
			if((teststatus1) || (teststatus2))
			{
		
				teststatus=1;
				System.out.println("the final test status is : "+teststatus);
			    logger.info("the final test status is : "+teststatus);
			    System.out.println("The user without space is able to login and user with space is unable to login");
			    logger.info("The user without space is able to login and user with space is unable to login");
		
			}
			else
			{
				teststatus=0;
				System.out.println("the final test status is : "+teststatus);
			    logger.info("the final test status is : "+teststatus);
			    System.out.println("The user without space is uable to login and user with space is able to login");
			    logger.info("The user without space is unable to login and user with space is able to login");
			}
				
		
		
		
		
		  
		  /* Identifying the test case to be updated in the ALM based on the group number
		   * 
		   */
		 
		  System.out.println("The QC upload is started");
		   logger.info("The QC upload is started");
		  TestcaseLookup tl =new TestcaseLookup(logger);
		 
		  lst = tl.lookupTestcase(FrameworkConstants.TCLookup,"G103");
			
		  LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
		  runIdFile=(lp1.readProperty("RUNID"));
		  wtr=new WriteTestResult();
		  testlog=new WriteTestResult();
		  
		  switch(almupdate)
		  {
		  case "No":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G103,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G103,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "no":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G103,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G103,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "yes":
			  updateALM();
			  break;
		  case "Yes":
			  updateALM();
			  break;
		  }

		  //ALM upload completed 
		 
		  logger.info("G103SFTP_MigratedUser_WhiteSpace Execution completed");
		  System.out.println("G103SFTP_MigratedUser_WhiteSpace Execution completed");
		  
		  
		
 }

	 public void updateALM()
	 {
		  /*ALMConnect alm = new ALMConnect();
		  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
		  if(qcstatus){
			  if(teststatus==1){
				  String strStatus="Passed";
				  String filePath=FrameworkConstants.RunLog;
				  String workdir=System.getProperty("user.dir");
		          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
		          System.out.println("workdir"+workdir);
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Passed");
					  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
					  wtr.writeToFile(runIdFile,"G103,"+ lst.get(i)+","+TID+",Passed");
				  }
			  }else{
					  String strStatus="Failed";
					  String filePath=FrameworkConstants.RunLog;
					  String workdir=System.getProperty("user.dir");
			          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
			          System.out.println("workdir"+workdir);
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Failed");
						  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						  wtr.writeToFile(runIdFile,"G103,"+ lst.get(i)+","+TID+",Failed");
					  }
				  }
				  
			  }else{
			  System.out.println("Unable to login to ALM");
			  }*/

	 
	 }	 
	 
 }

