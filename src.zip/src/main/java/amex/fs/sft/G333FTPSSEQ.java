package amex.fs.sft;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import amex.fs.commons.Download;
import amex.fs.commons.FileComparision;
import amex.fs.commons.FileSizeCheck;
import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.Login;
import amex.fs.commons.Logoff;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.Upload;
import amex.fs.commons.PerformUnzip;
import amex.fs.commons.WriteTestResult;

public class G333FTPSSEQ{
	int teststatus=0;
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G333FTPSSEQ.class);
	 String uploadedfilename = null;
	 String decompressedfile = null;
	 String filetobedownloaded=null;
	 String uploadedfilename1=null;
	 Boolean downloadstatus = false;
	 String seqfile1=null;
	 String seqfile2=null;
	 int sentinalstatus=0;
	 File f=null;
     FTPFile[] files;
	 
	  Map connectionmap, uplaodmap;
	  String servername;
	  String qcurl;
	  String qcuname;
	  String qcpwd;
	  String domain;
	  String project;
	  String TLpath;
	  String TSet;
	  String runIdFile;
	  List<String> lst;
	  WriteTestResult wtr,testlog;
	  String TID;
	  
	public static void main(String[] args)
	{
		G333FTPSSEQ fg = new G333FTPSSEQ();
		try {
			fg.f("G333FTPSSEQ", "G333FTPSSEQ", "amex123", "21", "FTP", "G333FTPSSEQFILE", "TESTFILE.txt", "/inbox", "UD", "BINARY", "PASSIVE", "NULL");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	@Test
	 @Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode","Basefile2"})
	 public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, String remotedirectory, String action, String filetype, String filetransfermode,String basefile2) throws IOException, InterruptedException{
		  logger.info("G333FTPSSEQ Execution Started");
		  logger.info("Loading Properties");
		  LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);
		  servername=lp.readProperty("server");
		  qcurl=lp.readProperty("almurl");
		  qcuname=lp.readProperty("almuser");
		  qcpwd=lp.readProperty("almpwd");
		  domain=lp.readProperty("almdomain");
		  project=lp.readProperty("almproject");
		  TLpath=lp.readProperty("almTLPath");
		  TSet=lp.readProperty("almTSet");
		  int intport=Integer.parseInt(port);
		  Map dwnld = new HashMap();
		  Map dwnld1 = new HashMap();
		  boolean constatus= false;
		  boolean sizestatus = false;
		  boolean constatus1= false;
		  boolean sizestatus1 = false;
		  Login lg=new Login(logger);
		  connectionmap= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD, protocol);
		  if((boolean) connectionmap.get("loginstatus")){
			  logger.info(sftuser+" logged into "+servername+" successfully ");
			  Upload up=new Upload(logger);
			  uplaodmap = up.uploadFile(connectionmap, basefilename, physicalfile, remotedirectory, filetype, filetransfermode);
			  if((boolean) uplaodmap.get("uploadstatus")){
				  uploadedfilename = (String) uplaodmap.get("Filename");
				  logger.info(sftuser+" uploaded "+uploadedfilename+" successfully ");
				  System.out.println("first file uploaded for sequnce sentinal");
				  logger.info("first file uploaded for sequnce sentinal");
				  
				  
				  System.out.println("start uploading the second file ");
				  logger.info("start uploading the second file ");
				  Upload up1=new Upload(logger);
				  Map uplaodmap1 = up1.uploadFile(connectionmap, basefilename, physicalfile, remotedirectory, filetype, filetransfermode);
				  if((boolean) uplaodmap1.get("uploadstatus")){
					  uploadedfilename1 = (String) uplaodmap1.get("Filename");
					  logger.info(sftuser+" uploaded "+uploadedfilename1+" successfully ");
					  System.out.println("second file uploaded for sequnce sentinal");
					  
					 FTPClient ftpclient = (FTPClient)  connectionmap.get("connection");
					 ftpclient.changeWorkingDirectory(FrameworkConstants.RemoteOutbox);
					 System.out.println("the download directory is "+FrameworkConstants.RemoteOutbox);
					 logger.info("the download directory is "+FrameworkConstants.RemoteOutbox);
					 Download downloadmap = new Download(logger);
					 System.out.println(" download of  file start");
					 logger.info(" download of  file start");
					
					 Thread.sleep(FrameworkConstants.SleepValue);
					 String filename;
					 Long filesize;
					 
					 files= ftpclient.listFiles();
					 
					 List myTempList = null;
					 
					 //int i=0;
					 System.out.println("files.length"+files.length);
					 myTempList=new ArrayList();
					 for (FTPFile file : files)
                     {
						 
						 
                                    filename = file.getName();
                                     filesize = file.getSize();
                                   
                                     myTempList.add(filename);
                                     
                                     System.out.println(filesize);
                                     System.out.println(filename);
                                     //f = new File(FrameworkConstants.DownloadDirectory);
                     				//OutputStream out = new FileOutputStream(f);	
                                     //downloadstatus = ftpclient.retrieveFile(filename, out);
                                     //i++;
                     }
					 
					int len= myTempList.size();
					System.out.println(" the number of files are "+len);
					logger.info(" the number of files are "+len);
					seqfile1=(String) myTempList.get(0);
					seqfile2=(String) myTempList.get(1); 
					
					System.out.println("the first uploaded file is "+seqfile1);
				    System.out.println("the first uploaded file is "+seqfile2);
				    logger.info("the first uploaded file is "+seqfile1);
				    logger.info("the first uploaded file is "+seqfile2);
					
				    String filedown1[]=seqfile1.split("#");
					String s1=filedown1[1];
					int firstsent=Integer.parseInt(s1);
					
					String filedown2[]=seqfile2.split("#");
					String s2=filedown2[1];
					int secondtsent=Integer.parseInt(s2);
					System.out.println("firstsent "+firstsent);
					
					System.out.println("secondtsent "+secondtsent);
					logger.info("firstsentinal is "+firstsent);
					logger.info("secondtsentinal is "+secondtsent);
					
					if((firstsent==9999)&&(secondtsent==0000)){
						sentinalstatus=1;
						System.out.println("seq sentinal is success");
						logger.info("The sequence number sentinal is successful");
						
					}else{	
					if ((firstsent+1)==secondtsent)
					{
						sentinalstatus=1;
						logger.info("The sequence number sentinal is successful");
					}
					else{
						sentinalstatus=0;
						logger.info("The sequence number sentinal failed");
					}
						
							}
					
					
				    /*System.out.println(" download of compressed file start");
					  String filedown[]=uploadedfilename.split("#");
					  String file1=filedown[0];
					  String file2=filedown[1];
					  filetobedownloaded =file1+".zip"+"#"+file2;
					  System.out.println("the file to be downloaded is :"+filetobedownloaded);*/
				    
				    for(int i=0;i<len;i++)
				    {
				    filetobedownloaded=(String) myTempList.get(i);	
					 switch(action)
					  {
					  case "UD" :
						  Thread.sleep(FrameworkConstants.SleepValue);
						  Thread.sleep(10000);
			  				dwnld= downloadmap.downloadFile(connectionmap, filetobedownloaded, FrameworkConstants.DownloadDirectory+""+filetobedownloaded, FrameworkConstants.RemoteOutbox, filetype, filetransfermode);
			  				if((boolean) dwnld.get("downloadstatus"))
			  				{
			  					logger.info(FrameworkConstants.DownloadDirectory+filetobedownloaded+" Downloaded Successfully");
			  					System.out.println("the download is successful");
			  				}else
			  				{
			  					logger.info(FrameworkConstants.DownloadDirectory+filetobedownloaded+" Download Failed");
			  					System.out.println("the download failed");
			  				}
			  				break;
			  	
					  case "UDD"  :
						  Thread.sleep(FrameworkConstants.SleepValue);
	 						dwnld= downloadmap.downloadFile(connectionmap, uploadedfilename, FrameworkConstants.DownloadDirectory+""+uploadedfilename, FrameworkConstants.RemoteOutbox, filetype, filetransfermode);
	 						
	 						if((boolean) dwnld.get("downloadstatus"))
							{
								logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Downloaded Successfully from Outbox");
								Thread.sleep(FrameworkConstants.SleepValue);
		 						dwnld= downloadmap.downloadFile(connectionmap, uploadedfilename, FrameworkConstants.DownloadDirectory+""+uploadedfilename, FrameworkConstants.RemoteSent, filetype, filetransfermode);
		 						if((boolean) dwnld.get("downloadstatus"))
								{
									logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Downloaded Successfully from Sent");
								}else
								{
									logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Download Failed from Sent");
								} 
							}else
							{
								logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Download Failed from Outbox");
							} 
	 						break;
			  				
			  		default:
			  			 	teststatus=0;
			  				break;
				  }
					
					
			}
					
					
					
					
					
					
					
					
					
					
				  }
				  else{
					  teststatus=0;
					  logger.info(sftuser+" failed to upload "+basefilename+" second time.");  
					  
					  
				  
				  }
				  
				  
				  
				  
				
				
				
				
					  
					if(sentinalstatus==1)  
					{
				//Comparison of files:
					 System.out.println("the file comparission is starting:");
					  logger.info("the file comparission is started:");
					  FileComparision fc = new FileComparision(logger);
					  FileSizeCheck fs = new FileSizeCheck(logger);
					  
						constatus = fc.contentVerification(physicalfile, FrameworkConstants.DownloadDirectory+"/"+seqfile1);
						logger.info("File comparison status 1:"+constatus);
						
						sizestatus = fs.fileSizeVerification(physicalfile, FrameworkConstants.DownloadDirectory+"/"+seqfile1);
						logger.info("File size verification status 1:"+sizestatus);
						constatus1 = fc.contentVerification(physicalfile, FrameworkConstants.DownloadDirectory+"/"+seqfile2);
						logger.info("File comparison status 2:"+constatus1);
						
						sizestatus1 = fs.fileSizeVerification(physicalfile, FrameworkConstants.DownloadDirectory+"/"+seqfile2);
						logger.info("File size verification status 2:"+sizestatus1);
						if((constatus&&sizestatus)&&(constatus1&&sizestatus1)){
							teststatus=1; //if file same 
							
							System.out.println("the file before compression and file after decompression are same");
							}else{
								teststatus=0; // if different
								System.out.println("the file before compression and file after decompression are different");
								 }
						
						System.out.println("the comparision status is: "+teststatus);
						logger.info("the comparision status is: "+teststatus);
					}
					  
					  
				TID=(String)uplaodmap.get("TID");
						  
			  }
					 
			  else{
				  teststatus=0;
				  logger.info(sftuser+" failed to upload the file  "+basefilename+"first time. ");
				  TID="Upload Failed";
			  }
		  }else{
			  logger.info(sftuser+" unable to login to "+servername);
			  teststatus=0;
			  TID="Login Failed";
		  }
		  
		  
	 
		  
		  TestcaseLookup tl =new TestcaseLookup(logger);
		  //String groupname = tcname.substring(0, 2);
		  lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G333");
		  System.out.println("1st :"+lst.size());
		  LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
		  runIdFile=(lp1.readProperty("RUNID"));
		  wtr=new WriteTestResult();
		  testlog=new WriteTestResult();
		  
		  switch(almupdate)
		  {
		  case "No":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G333,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G333,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "no":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G333,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G333,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "yes":
			  updateALM();
			  break;
		  case "Yes":
			  updateALM();
			  break;
		  }

		  
		  Logoff loff=new Logoff(logger);
		   loff.logofffromSFT(connectionmap);
		  logger.info("G333FTPSSEQ Execution completed");
	 
	 }
	public void updateALM()
	 {
		 /* ALMConnect alm = new ALMConnect();
		  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
		  if(qcstatus){
			  if(teststatus==1){
				  String strStatus="Passed";
				  String filePath=FrameworkConstants.RunLog;
				  String workdir=System.getProperty("user.dir");
		          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
		          System.out.println("workdir"+workdir);
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Passed");
					  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
					  wtr.writeToFile(runIdFile,"G333,"+ lst.get(i)+","+TID+",Passed");
				  }
			  }else{
					  String strStatus="Failed";
					  String filePath=FrameworkConstants.RunLog;
					  String workdir=System.getProperty("user.dir");
			          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
			          System.out.println("workdir"+workdir);
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Failed");
						  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						  wtr.writeToFile(runIdFile,"G333,"+ lst.get(i)+","+TID+",Failed");
					  }
				  }
				  
			  }else{
			  System.out.println("Unable to login to ALM");
			  }
*/
	 
	 }	 
 
}


