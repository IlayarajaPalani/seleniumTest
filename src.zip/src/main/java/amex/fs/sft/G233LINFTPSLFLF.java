package amex.fs.sft;






	import java.io.IOException;
import java.text.ParseException;
import java.util.List;

import org.slf4j.LoggerFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import amex.fs.commons.AsciiFileComparison;
import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LinuxBoxFileTransfer;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.WriteTestResult;

	

	 /*Description : This module uploads the LF input file in Default  mode and downloads the file in BINARY mode using FTPS protocol from LINUX machine and verify the EOL of the�downloaded�file as LF  */  


	public class G233LINFTPSLFLF {

		
			int teststatus=0;
			public static org.slf4j.Logger logger = LoggerFactory.getLogger(G233LINFTPSLFLF.class);
			String servername;
			String qcurl;
			String qcuname;
			String qcpwd;
			String domain;
			String project;
			String TLpath;
			String TSet;
			String runIdFile;
			List<String> lst;
			WriteTestResult wtr,testlog;
			boolean contentVerificationvalue = false;
			String TID= "";
			String action = "";
			public static void main(String[] args) throws IOException, ParseException, InterruptedException{
				G233LINFTPSLFLF fg = new G233LINFTPSLFLF();
				fg.fileTransfer("G233LINFTPSLFLF", "KARTHIKUSER", "no", "", "FTPS", "KARTHIKFILE", "KARTHIKFILE", "", "POD", "BINARY","BINARY","");

			}

			@Test
			@Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTypeDown","FileTransferMode"})
			public void fileTransfer(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, 
					String remotedirectory,	String action, String filetypeup, String filetypedown,String filetransfermode) throws IOException, InterruptedException{
				logger.info("G233LINFTPSLFLF Execution Started");
				logger.info("Loading Properties");
				LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);
				servername=lp.readProperty("server");
				qcurl=lp.readProperty("almurl");
				qcuname=lp.readProperty("almuser");
				qcpwd=lp.readProperty("almpwd");
				domain=lp.readProperty("almdomain");
				project=lp.readProperty("almproject");
				TLpath=lp.readProperty("almTLPath");
				TSet=lp.readProperty("almTSet");
				//BasicConfigurator.configure();
				String unixServerUrl=lp.readProperty("unixServerUrl");
				String unixId =lp.readProperty("unixId");
				String unixPwd =lp.readProperty("unixPwd");
				String unixHomeDir =lp.readProperty("unixHomeDir");
				String ftpServer = lp.readProperty("server");
				this.action = action!=null?action:"EMPTY";
				LinuxBoxFileTransfer lbft = null;
				try {
					lbft = new LinuxBoxFileTransfer();
					boolean bootStatus = lbft.bootLinuxBox(unixServerUrl, 446, unixId, null, unixPwd);
					if(!bootStatus) throw new Exception("Unable to Boot linux box");

					boolean uploadStatus = lbft.uploadFromLocalToBox(unixHomeDir, physicalfile, basefilename, "777");
					if(!uploadStatus) throw new Exception("Unable to upload local file");

					lbft.sendCommand("cd "+unixHomeDir);
					
					if(! lbft.sendCommand("pwd").contains(unixHomeDir)){
						throw new Exception("Unable to switch: "+unixHomeDir);
					}
					
					lbft.sendCommand("ls");

					String inputFileName = basefilename;
					
					if(protocol.equalsIgnoreCase("ftps")){
						
						lbft.sendCommand("lftp");
						lbft.sendCommand("set ftp:ssl-force true");
						lbft.sendCommand("set ftp:ssl-protect-data true");
						
						if(lbft.sendCommand("connect "+ftpServer).contains("Name or service not known")) 
							throw new Exception("Unable to connect to "+ftpServer);
						
						lbft.sendCommand("login "+sftuser+" "+FrameworkConstants.DefaultSFTPWD);
						
						String uploadCommand = "";
						if(filetypeup != null && filetypeup.equalsIgnoreCase("ASCII")){
							uploadCommand = "put -a";
						}
						else if(filetypeup != null && filetypeup.equalsIgnoreCase("Binary")){
							uploadCommand = "put";
						}
						else{
							throw new Exception("Unsupported File upload mode:"+filetypeup);
						}
						
						if(! lbft.sendCommand(uploadCommand+" "+inputFileName).contains("transferred")) 
							throw new Exception("Unable to Transfer");
						
						String uploadDir = "/inbox";
						lbft.sendCommand("cd "+uploadDir);
						
						if(! lbft.sendCommand("pwd").contains(uploadDir)){
							throw new Exception("Unable to switch: "+uploadDir);
						}
						
						String output = lbft.sendCommand("ls -R");
						String outputFileName = lbft.getFileNamefromOutput(output, inputFileName);
						lbft.sendCommand("cd ..");
						
						String downloadDir = "/outbox";
						lbft.sendCommand("cd "+downloadDir);
						
						if(! lbft.sendCommand("pwd").contains(downloadDir)){
							throw new Exception("Unable to switch: "+downloadDir);
						}
						
						lbft.sendCommand("ls -R");
						
						String downloadCommand = "";
						if(filetypedown != null && filetypedown.equalsIgnoreCase("ASCII")){
							downloadCommand = "get -a";
						}
						else if(filetypedown != null && filetypedown.equalsIgnoreCase("Binary")){
							downloadCommand = "get";
						}
						else{
							throw new Exception("Unsupported File download mode:"+filetypedown);
						}
						
						if(! lbft.sendCommand(downloadCommand+" "+outputFileName).contains("transferred")) 
							throw new Exception("Unable to Transfer");
						
						lbft.sendCommand("bye");

						lbft.sendCommand("cd "+unixHomeDir);
						if(! lbft.sendCommand("pwd").contains(unixHomeDir)){
							throw new Exception("Unable to switch: "+unixHomeDir);
						}

						String inputFile = lbft.sendCommand("cat -v "+inputFileName);
						String inputFileEol = lbft.checkFileEolType(inputFile);
						System.out.println("inputFileEol:"+inputFileEol);

						String outputFile2 = lbft.sendCommand("cat -v "+outputFileName);
						String outputFileEol = lbft.checkFileEolType(outputFile2);
						System.out.println("outputFileEol:"+outputFileEol);
						
						lbft.downloadFromBoxToLocal(outputFileName, FrameworkConstants.DownloadDirectory+outputFileName);
						
						AsciiFileComparison fc =new AsciiFileComparison();
						  try{
							  logger.info("verifying the content of "+physicalfile+" against "+outputFileName);
							  contentVerificationvalue= fc.contentVerification(physicalfile, FrameworkConstants.UnixEOL,FrameworkConstants.DownloadDirectory+"/"+outputFileName, FrameworkConstants.UnixEOL);
							  if(contentVerificationvalue)
							  {
								  teststatus=1;
								  logger.info("The filetype verification status is true");
								  System.out.println("contentVerificationvalue is : "+contentVerificationvalue);
								  System.out.println("The filetype verification is true");
							  }
							  else
							  {
								  teststatus=0;
								  logger.info("The filetype verification status is false");
								  System.out.println("contentVerificationvalue is : "+contentVerificationvalue);
								  System.out.println("The filetype verification is false");
							  }
							  
							  if(outputFileName!=null && outputFileName.indexOf("#")!=-1
									  &&  outputFileName.split("#").length == 2){
								  TID = outputFileName.split("#")[1];
								  logger.info("TID:"+TID);
							  }
								  
						  }catch(Exception exc)
						  {
							  System.out.println("Exception in file type verification is: ");
							  exc.printStackTrace();
						  }
						 
							
					}
					else{
						throw new Exception("Unsupported Protocol");
					}

				} catch (Exception e) {
					TID = e.getMessage()!=null?e.getMessage():"Null Pointer Exception";
					e.printStackTrace();
					logger.info(e.getMessage());
				}
				finally{
					if(lbft != null){
						lbft.destroy();
					}
				}


				try{
					
					TestcaseLookup tl =new TestcaseLookup(logger);
					lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G233");
					//System.out.println(lst);
					LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
					runIdFile=(lp1.readProperty("RUNID"));
					wtr=new WriteTestResult();
					//testlog=new WriteTestResult();
					boolean loggedResult = false;
					switch(almupdate)
					{
					case "No":
						if(teststatus==1)
						{
							for(int i=0;i<lst.size();i++)
							{
								if(lst.get(i) != null && lst.get(i).indexOf(action) != -1) {
									loggedResult = true;
									logger.info("Updating"+lst.get(i)+"status as Passed");
									wtr.writeToFile(runIdFile,"G233,"+ lst.get(i)+","+TID+",Passed");
									System.out.println("Updating"+lst.get(i)+"status as Passed");
								}
							}
						}else
						{
							for(int i=0;i<lst.size();i++)
							{
								if(lst.get(i) != null && lst.get(i).indexOf(action) != -1) {
									loggedResult = true;
									logger.info("Updating"+lst.get(i)+"status as Failed");
									wtr.writeToFile(runIdFile,"G233,"+ lst.get(i)+","+TID+",Failed");
									System.out.println("Updating"+lst.get(i)+"status as Failed");
								}
							}

						}
						break;
					case "no":
						if(teststatus==1)
						{
							for(int i=0;i<lst.size();i++)
							{
								if(lst.get(i) != null && lst.get(i).indexOf(action) != -1) {
									loggedResult = true;
									logger.info("Updating"+lst.get(i)+"status as Passed");
									wtr.writeToFile(runIdFile,"G233,"+ lst.get(i)+","+TID+",Passed");
								}
							}
						}else
						{
							for(int i=0;i<lst.size();i++)
							{
								if(lst.get(i) != null && lst.get(i).indexOf(action) != -1) {
									loggedResult = true;
									logger.info("Updating"+lst.get(i)+"status as Failed");
									wtr.writeToFile(runIdFile,"G233,"+ lst.get(i)+","+TID+",Failed");
								}
							}

						}
						break;
		/*			case "yes":
						updateALM();
						loggedResult = true;
						break;
					case "Yes":
						updateALM();
						loggedResult = true;
						break;*/
					}
					if(!loggedResult){
						System.out.println("Unable to update status for G233");
						logger.info("Unable to update status for G233");
					}
					logger.info("G233LINFTPSLFLF Execution completed");
				}
				catch(Exception e){
					logger.info("G233LINFTPSLFLF Execution failed");
					e.printStackTrace();
				}
				
			}

			/*Updating ALM*/
			public void updateALM()
			{
				/*ALMConnect alm = new ALMConnect();
				boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
				boolean loggedResult = false;
				if(qcstatus){
					if(teststatus==1){
						String strStatus="Passed";
						String filePath=FrameworkConstants.RunLog;
						String workdir=System.getProperty("user.dir");
						String fileName=workdir+"\\"+FrameworkConstants.RunLog;
						System.out.println("workdir"+workdir);
						for(int i=0;i<lst.size();i++)
						{
							if(lst.get(i) != null && lst.get(i).indexOf(action) != -1) {
								loggedResult = true;
								logger.info("Updating"+lst.get(i)+"status as Passed");
							alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
								wtr.writeToFile(runIdFile,"G233,"+ lst.get(i)+","+TID+",Passed");
							}
						}
					}else{
						String strStatus="Failed";
						String filePath=FrameworkConstants.RunLog;
						String workdir=System.getProperty("user.dir");
						String fileName=workdir+"\\"+FrameworkConstants.RunLog;
						System.out.println("workdir"+workdir);
						for(int i=0;i<lst.size();i++)
						{
							if(lst.get(i) != null && lst.get(i).indexOf(action) != -1) {
								loggedResult = true;
								logger.info("Updating"+lst.get(i)+"status as Failed");
							alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
								wtr.writeToFile(runIdFile,"G233,"+ lst.get(i)+","+TID+",Failed");
							}
						}
					}
					if(!loggedResult){
						System.out.println("Unable to update status for G233");
						logger.info("Unable to update status for G233");
					}

				}else{
					System.out.println("Unable to login to ALM");
					logger.info("Unable to login to ALM");
				}
*/

			}
		}






