package amex.fs.sft;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.LoggerFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.Login;
import amex.fs.commons.Logoff;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.WriteTestResult;

public class G27UserLockOut {
	int teststatus=0;
	  Map connectionmap, uplaodmap;
	  String servername;
	  String qcurl;
	  String qcuname;
	  String qcpwd;
	  String domain;
	  String project;
	  String TLpath;
	  String TSet;
	  String runIdFile;
	  List<String> lst;
	  WriteTestResult wtr,testlog;
	  String TID;
	  
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G27UserLockOut.class);

	public static void main(String[] args) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		G27UserLockOut g = new G27UserLockOut();
		g.f("G27UserLockOut", "LOCK_USER", "amex", "21", "FTP");

	}
	
	@Test
	 @Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol"})
	 public void f(String tcname, String sftuser, String almupdate, String port, String protocol) throws IOException, InterruptedException{
		 logger.info("G27UserLockOut Execution Started");
		 logger.info("Loading Properties");
		  LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);
		  servername=lp.readProperty("server");
		  qcurl=lp.readProperty("almurl");
		  qcuname=lp.readProperty("almuser");
		  qcpwd=lp.readProperty("almpwd");
		  domain=lp.readProperty("almdomain");
		  project=lp.readProperty("almproject");
		  TLpath=lp.readProperty("almTLPath");
		  TSet=lp.readProperty("almTSet");
		  //BasicConfigurator.configure();
		  int intport=Integer.parseInt(port);
		  Map dwnld = new HashMap();

		  Login lg=new Login(logger);
		  connectionmap= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD, protocol);
		  if(connectionmap.get("Message").toString().contains("530 Authentication failed: User account is locked")){
			  System.out.println("User is already locked. Please unlock the user in TP application");
			  logger.info("User is already locked. Please unlock the user in TP application");
			  teststatus = 0;
			  TID="User Account Locked";
		  }else{
		  connectionmap= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD, protocol);
		  connectionmap= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD, protocol);
		  connectionmap= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD, protocol);
		  if(connectionmap.get("Message").toString().contains("530 Authentication failed: User account is locked")){
			  teststatus=1;
			  TID="User Account Locked";
		  }else{
			  teststatus=0;
			  TID="User Account Not Locked after 3 attempts";
		  }
		  }
		  TestcaseLookup tl =new TestcaseLookup(logger);
		  //String groupname = tcname.substring(0, 2);
		  lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G27");
		  
		  LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
		  runIdFile=(lp1.readProperty("RUNID"));
		  wtr=new WriteTestResult();
		  testlog=new WriteTestResult();
		  
		  switch(almupdate)
		  {
		  case "No":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G27,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G27,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "no":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G27,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G27,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
/*		  case "yes":
			  updateALM();
			  break;
		  case "Yes":
			  updateALM();
			  break;*/
		  }

		   if(teststatus==1)
		   {
		   Logoff loff=new Logoff(logger);
		   loff.logofffromSFT(connectionmap);
		   }
		  logger.info("G27UserLockOut Execution completed");
		  }
	public void updateALM()
	 {
/*		  ALMConnect alm = new ALMConnect();
		  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
		  if(qcstatus){
			  if(teststatus==1){
				  String strStatus="Passed";
				  String filePath=FrameworkConstants.RunLog;
				  String workdir=System.getProperty("user.dir");
		          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
		          System.out.println("workdir"+workdir);
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Passed");
					  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
					  wtr.writeToFile(runIdFile,"G27,"+ lst.get(i)+","+TID+",Passed");
				  }
			  }else{
					  String strStatus="Failed";
					  String filePath=FrameworkConstants.RunLog;
					  String workdir=System.getProperty("user.dir");
			          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
			          System.out.println("workdir"+workdir);
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Failed");
						  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						  wtr.writeToFile(runIdFile,"G27,"+ lst.get(i)+","+TID+",Failed");
					  }
				  }
				  
			  }else{
			  System.out.println("Unable to login to ALM");
			  }*/

	 
	 }
	
	}
	
