package amex.fs.sft;
/*Description:
 * project: NGP Automation.
 * author: Viren Tiwari
 * This program is to test Transfer link availability & Transfer link Clear up.
 */
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import amex.fs.commons.Download;
import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.Login;
import amex.fs.commons.Logoff;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.Upload;
import amex.fs.commons.WriteTestResult;
public class G34TransferLink {
int teststatus=0,temp=0;
public static org.slf4j.Logger logger = LoggerFactory.getLogger(G34TransferLink.class);
String uploadedfilename = null;
Map connectionmap, uplaodmap;
String servername;
String qcurl;
String qcuname;
String qcpwd;
String domain;
String project;
String TLpath;
String TSet;
String runIdFile;
List<String> lst;
WriteTestResult wtr,testlog;
String TID;

FTPClient ftpclient = null;
Logoff loff= null;
public static void main(String args[]) throws IOException, InterruptedException{
G34TransferLink tst = new G34TransferLink();
tst.f("G34TransferLink", "MAILUSER", "amex123", "21", "FTP", "MAIL_FILE", "TESTFILE.txt", "/inbox", "U", "ASCII", "PASSIVE",null);
}
@Test
@Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode","Basefile2"})
public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, String remotedirectory, String action, String filetype, String filetransfermode,String Basefile2) throws IOException, InterruptedException{
logger.info("G34TransferLink Execution Started");
logger.info("Loading Properties");
LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);
servername=lp.readProperty("server");
qcurl=lp.readProperty("almurl");
qcuname=lp.readProperty("almuser");
qcpwd=lp.readProperty("almpwd");
domain=lp.readProperty("almdomain");
project=lp.readProperty("almproject");
TLpath=lp.readProperty("almTLPath");
TSet=lp.readProperty("almTSet");
		//BasicConfigurator.configure();
int intport=Integer.parseInt(port);
uplaodmap = new HashMap();
Map dwnld = new HashMap();
FTPClient ftpClient = new FTPClient();
Login lg=new Login(logger); //login into the server
connectionmap= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD, protocol);
if((boolean) connectionmap.get("loginstatus")){ //check weather login is successful
logger.info(sftuser+" logged into "+servername+" successfully ");
Upload up=new Upload(logger); //uploading the files into the server
uplaodmap = up.uploadFile(connectionmap, basefilename, physicalfile, remotedirectory, filetype, filetransfermode);
if((boolean) uplaodmap.get("uploadstatus"))
{
//Add File transfer link clean logic here(Log off, login and file link check)
logger.info(sftuser+" uploaded "+uploadedfilename+" successfully "); //check weather the file is uploaded or not
uploadedfilename = (String) uplaodmap.get("Filename");//getting the uploaded file name
loff=new Logoff(logger);//logoff
loff.logofffromSFT(connectionmap);
System.out.println("logoff successfully");
Login lg1=new Login(logger); //login into the server
connectionmap= lg1.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD, protocol);
if((boolean) connectionmap.get("loginstatus")){ //check weather login is successful
ftpclient = (FTPClient) connectionmap.get("connection");
boolean success;
success=ftpclient.changeWorkingDirectory("/inbox");//changing the path
if(success==true){
 
FTPFile[] files= ftpclient.listFiles();// need to check whether list is null
if(files!=null){
for(FTPFile file : files) {
String details = file.getName();
if (details.equals(uploadedfilename)) {
teststatus=0;
logger.info(" TransferLink cleanup testcase:  Failed ");
System.out.println("filelink is  matching");
break;
}
}
logger.info(" TransferLink cleanup testcase:  Passed ");
teststatus=1;
System.out.println("filelink not found ");
System.err.println("for file clearup test case is passed");
success=ftpclient.changeWorkingDirectory("/outbox");//navigate to the outbox
if (success==true){
 Thread.sleep(FrameworkConstants.SleepValue);
FTPFile[] files1= ftpclient.listFiles();
for (FTPFile file1 : files1) {
String details = file1.getName();
 
if(details.equals(uploadedfilename))
{
 temp++;//
break;
}
}
System.out.println(temp);
if(temp==1)
{
Download downloadmap = new Download(logger);//create a download object.
dwnld= downloadmap.downloadFile(connectionmap, uploadedfilename, FrameworkConstants.DownloadDirectory+""+uploadedfilename, FrameworkConstants.RemoteOutbox, filetype, filetransfermode);
if((boolean) dwnld.get("downloadstatus"))
{
logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Downloaded Successfully");
Thread.sleep(FrameworkConstants.SleepValue);
FTPFile[] files2= ftpclient.listFiles();
for (FTPFile file2 : files2) {
String details = file2.getName();
if(details.equals(uploadedfilename))
{
teststatus=0;
logger.info(" TransferLink availability testcase:  failed ");
System.out.println("test case failed");//check weather downloaded link still there or not
break;
}
}
if(teststatus==1){
 success=ftpclient.changeWorkingDirectory("/sent");//navigate to send directory
 Thread.sleep(FrameworkConstants.SleepValue);
 if(success==true)
 {
 FTPFile[] files3= ftpclient.listFiles();
 for (FTPFile file3 : files3) {
 String details = file3.getName();
 

 if(details.equals(uploadedfilename))
 {
  temp++;//
 break;
 }
 }
 if (temp==2){
  dwnld= downloadmap.downloadFile(connectionmap, uploadedfilename, FrameworkConstants.DownloadDirectory+""+uploadedfilename, FrameworkConstants.RemoteOutbox, filetype, filetransfermode);
  if((boolean) dwnld.get("downloadstatus"))
  {
  logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Downloaded Successfully");
System.out.println("testcase  passed");
  teststatus=1;
  logger.info(" TransferLink availability testcase:  Passed ");
  }else{System.out.println("unable to download file");}
 }
 else{
  teststatus=0;
  System.out.println("testcase Failed");
  logger.info(" TransferLink availability testcase:  failed ");
 }
 }
 else
 {
 System.out.println("unable to navigate to sent dir");
 }
}
}
else{
 System.out.println("unable to download file");
}
}
}

else{
 System.out.println("unable to navigate to outbox dir");
 logger.info(" unable to navigate to outbox dir ");
 }
}
}
else{
 System.out.println("unable to navigate to inbox dir");
 logger.info(" unable to navigate to outbox dir ");
 TID="Unable to navigate to outbox dir";
}
}
else{
 logger.info(sftuser+" unable to login to "+servername);//login fail
 logger.info(" TransferLink availability testcase:  failed ");
 teststatus=0;
 TID="Login Failed";
}
}
else
{
logger.info(sftuser+" failed to upload "+basefilename);
TID="Upload Failed";
}
TID=(String)uplaodmap.get("TID");
}
else{
logger.info(sftuser+" unable to login to "+servername);//login fail
teststatus=0;
TID="Login Failed";
}
 
TestcaseLookup tl =new TestcaseLookup(logger);
/* Identifying the testcase to be updated in the ALM based on the group number
 * 
 */ 
lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G34");

LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
runIdFile=(lp1.readProperty("RUNID"));
wtr=new WriteTestResult();
testlog=new WriteTestResult();

switch(almupdate)
{
case "No":
	  if(teststatus==1)
	  {
	  for(int i=0;i<lst.size();i++)
	  {
		  logger.info("Updating"+lst.get(i)+"status as Passed");
		  wtr.writeToFile("G34,"+runIdFile, lst.get(i)+","+TID+",Passed");
	  }
	  }else
	  {
		  for(int i=0;i<lst.size();i++)
		  {
			  logger.info("Updating"+lst.get(i)+"status as Failed");
			  wtr.writeToFile("G34,"+runIdFile, lst.get(i)+","+TID+",Failed");
		  }
		  
	  }
	  break;
case "no":
	  if(teststatus==1)
	  {
	  for(int i=0;i<lst.size();i++)
	  {
		  logger.info("Updating"+lst.get(i)+"status as Passed");
		  wtr.writeToFile("G34,"+runIdFile, lst.get(i)+","+TID+",Passed");
	  }
	  }else
	  {
		  for(int i=0;i<lst.size();i++)
		  {
			  logger.info("Updating"+lst.get(i)+"status as Failed");
			  wtr.writeToFile("G34,"+runIdFile, lst.get(i)+","+TID+",Failed");
		  }
		  
	  }
	  break;
/*case "yes":
	  updateALM();
	  break;
case "Yes":
	  updateALM();
	  break;*/
}


//ALM upload completed 
/*logging off from the SFT server
 * 
 */
if(teststatus==1)
{
Logoff loff=new Logoff(logger);
loff.logofffromSFT(connectionmap);
}

logger.info("G34TransferLink Execution completed");
System.out.println("G34TransferLink Execution completed");

}

public void updateALM()
{
	  /*ALMConnect alm = new ALMConnect();
	  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
	  if(qcstatus){
		  if(teststatus==1){
			  String strStatus="Passed";
			  String filePath=FrameworkConstants.RunLog;
			  String workdir=System.getProperty("user.dir");
	          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
	          System.out.println("workdir"+workdir);
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
				  wtr.writeToFile("G34,"+runIdFile, lst.get(i)+","+TID+",Passed");
			  }
		  }else{
				  String strStatus="Failed";
				  String filePath=FrameworkConstants.RunLog;
				  String workdir=System.getProperty("user.dir");
		          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
		          System.out.println("workdir"+workdir);
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
					  wtr.writeToFile("G34,"+runIdFile, lst.get(i)+","+TID+",Failed");
				  }
			  }
			  
		  }else{
		  System.out.println("Unable to login to ALM");
		  }*/


}

}
