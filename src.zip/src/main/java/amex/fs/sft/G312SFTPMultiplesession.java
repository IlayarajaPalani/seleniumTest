

package amex.fs.sft;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import java.text.ParseException;

//import org.apache.commons.el.parser.ParseException;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPSClient;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


import amex.fs.commons.Download;
import amex.fs.commons.FileComparision;
import amex.fs.commons.FileSizeCheck;
import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.Login;
import amex.fs.commons.Logoff;
import amex.fs.commons.SFTP_Module;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.Upload;
import amex.fs.commons.WriteTestResult;

import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.HostKey;
import com.jcraft.jsch.HostKeyRepository;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Logger;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpATTRS;
import com.jcraft.jsch.SftpException;
import com.jcraft.jsch.UserInfo;

public class G312SFTPMultiplesession {
	
	int teststatus=0;
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G312SFTPMultiplesession.class);
	String uploadedfilenameSFTP = null;
	String uploadedfilenameSFTP1 = null;
	
	Map connectionmapSFTP,uplaodmapSFTP;
	Map connectionmapSFTP1;
	  ;
	  String servername;
	  String qcurl;
	  String qcuname;
	  String qcpwd;
	  String domain;
	  String project;
	  String TLpath;
	  String TSet;
	  String runIdFile;
	  List<String> lst;
	  WriteTestResult wtr,testlog;
	  String TID;
	  
	Logoff logoff = new Logoff(logger);
	 
	public static void main(String[] args)
	{
		G312SFTPMultiplesession fg = new G312SFTPMultiplesession();
		try {
			
			//fg.f("G312SFTPMultiplesession", "G31Multiple", "No", "21", "FTPS", "G31MultipleFile", "TESTFILE.txt", "/inbox","null", "BINARY", "PASSIVE", "null");
			fg.f("G312SFTPMultiplesession", "G8FTP1GBUser", "No", "22", "SFTP", "G8FTP1GBFile", "TESTFILE.txt", "/inbox","null", "BINARY", "PASSIVE", "null");			
			} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SftpException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	 @Test
	 @Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode", "Basefile2"})
	 public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, String remotedirectory, String action, String filetype, String filetransfermode,String basefilename2) throws IOException,InterruptedException, ParseException, SftpException{
		
		 logger.info("G312SFTPMultiplesession Execution Started");
		  logger.info("Loading Properties");
		  LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);
		  servername=lp.readProperty("server");
		  qcurl=lp.readProperty("almurl");
		  qcuname=lp.readProperty("almuser");
		  qcpwd=lp.readProperty("almpwd");
		  domain=lp.readProperty("almdomain");
		  project=lp.readProperty("almproject");
		  TLpath=lp.readProperty("almTLPath");
		  TSet=lp.readProperty("almTSet");
		  int intport=Integer.parseInt(port);
		  Map dwnld = new HashMap();
		  boolean constatus= false;
		  boolean sizestatus = false;
		  //Login lg=new Login(logger);
		  
		  SFTP_Module lg=new SFTP_Module(logger);
		  SFTP_Module lg1=new SFTP_Module(logger);
		  connectionmapSFTP= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD,null,FrameworkConstants.AcceptHostKey);
		  if((boolean) connectionmapSFTP.get("result")){
			  logger.info(sftuser+" logged into "+servername+" successfully ");
			  Upload up=new Upload(logger);
			  uplaodmapSFTP = lg.uploadFile(connectionmapSFTP, physicalfile, basefilename, remotedirectory);
			  
			  if((boolean) uplaodmapSFTP.get("Status") && protocol.equalsIgnoreCase("SFTP")){
				  uploadedfilenameSFTP = (String) uplaodmapSFTP.get("Filename");		  
				  logger.info(sftuser+" uploaded "+uploadedfilenameSFTP+" successfully ");
				  connectionmapSFTP1= lg1.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD,null,FrameworkConstants.AcceptHostKey);
			  if((boolean) connectionmapSFTP1.get("result")){
				  logger.info(sftuser+" logged into "+servername+" successfully ");
				  Map uplaodmapSFTP1 = lg1.uploadFile(connectionmapSFTP1, physicalfile, basefilename, remotedirectory);
					
			      if((boolean) uplaodmapSFTP1.get("Status")){
				  uploadedfilenameSFTP1 = (String) uplaodmapSFTP1.get("Filename");		  
				  logger.info(sftuser+" uploaded "+uploadedfilenameSFTP1+" successfully ");  
				  
				  System.out.println("File lISTING");
				  System.out.println("File 1--> "+uploadedfilenameSFTP);
				  System.out.println("File 2--> "+uploadedfilenameSFTP1);
					 
				  ChannelSftp channelSftp= null; 
				  channelSftp=(ChannelSftp) connectionmapSFTP1.get("channel");
				  String pwd=channelSftp.lpwd();
				  
				  System.out.println("Present working dir"+pwd);
				  Vector<ChannelSftp.LsEntry> list = channelSftp.ls("/inbox");
					if(!list.isEmpty())
					{
						for(ChannelSftp.LsEntry entry : list) 
						{
								if(".".equals(entry.getFilename())||"..".equals(entry.getFilename()))
								{
								}
								else
								{
									System.out.println("f-->"+entry.getFilename());
									if(( entry.getFilename()).equalsIgnoreCase(uploadedfilenameSFTP) || (entry.getFilename()).equalsIgnoreCase(uploadedfilenameSFTP1))
									  {
										  teststatus = 1;
									  }
									  else
										  teststatus = 0;
								}
				  
				  
				  if (teststatus == 1){
					  System.out.println("***PASS***");
				  }else
					  System.out.println("***FAIL***");
				 }
					}
			  else{
				  teststatus=0;
				  logger.info(sftuser+" failed to upload "+basefilename);
				  TID="Upload Failed";
			  	}
					String TID1 = (String) uplaodmapSFTP.get("TID");
					String TID2 = (String) uplaodmapSFTP1.get("TID");
					TID=TID1+"/"+TID2;
					
			  }else{
			  logger.info(sftuser+" unable to login to "+servername);
			  teststatus=0;
			  TID="Login Failed";
			  }
			}
			  
		  }else
		  {
			  logger.info(sftuser+" unable to login to "+servername);
			  teststatus=0;
			  TID="Login Failed";
		  }
		  }
	 


		  TestcaseLookup tl =new TestcaseLookup(logger);
		 
		  lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G312");
		  
		  LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
		  runIdFile=(lp1.readProperty("RUNID"));
		  wtr=new WriteTestResult();
		  testlog=new WriteTestResult();
		  
		  switch(almupdate)
		  {
		  case "No":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G313,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G313,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "no":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G313,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G313,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "yes":
			  updateALM();
			  break;
		  case "Yes":
			  updateALM();
			  break;
		  }

		  logger.info("G312SFTPMultiplesession Execution completed");
		  
		  System.out.println("G312SFTPMultiplesession Execution completed");
		  
		  if(teststatus==1 || teststatus==0)
		  {
		  lg.logofffromSFT(connectionmapSFTP);
		  lg1.logofffromSFT(connectionmapSFTP1);
		  logger.info("logging off from the SFT server");
		  System.out.println("logging off from the SFT server");
		  }
	
	 
}

		  

	 public void updateALM()
	 {
		  /*ALMConnect alm = new ALMConnect();
		  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
		  if(qcstatus){
			  if(teststatus==1){
				  String strStatus="Passed";
				  String filePath=FrameworkConstants.RunLog;
				  String workdir=System.getProperty("user.dir");
		          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
		          System.out.println("workdir"+workdir);
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Passed");
					  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
					  wtr.writeToFile(runIdFile,"G313,"+ lst.get(i)+","+TID+",Passed");
				  }
			  }else{
					  String strStatus="Failed";
					  String filePath=FrameworkConstants.RunLog;
					  String workdir=System.getProperty("user.dir");
			          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
			          System.out.println("workdir"+workdir);
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Failed");
						  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						  wtr.writeToFile(runIdFile,"G313,"+ lst.get(i)+","+TID+",Failed");
					  }
				  }
				  
			  }else{
			  System.out.println("Unable to login to ALM");
			  }
*/
	 
	 }	 

}



