
package amex.fs.sft;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import amex.fs.commons.Download;
import amex.fs.commons.FileComparision;
import amex.fs.commons.FileSizeCheck;
import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.Login;
import amex.fs.commons.Logoff;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.Upload;
import amex.fs.commons.WriteTestResult;


import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

public class G380_SuspendedDelAS2https {
	int teststatus=0;
	int TMStatus=0;
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G380_SuspendedDelAS2https.class);
	 String uploadedfilename = null;
	  Map connectionmap, uplaodmap;
	  String servername,remoteserver,unixServerUrl,G380User;
	  String qcurl;
	  String qcuname;
	  String qcpwd;
	  String domain;
	  String project;
	  String TLpath;
	  String TSet;
	  String runIdFile;
	  String id,pass,url;
	  List<String> lst;
	  WriteTestResult wtr,testlog;
	  String TID;
	  
	 Logoff loff = null;
	 public static void main(String args[]) throws IOException, InterruptedException{
		 G380_SuspendedDelAS2https tst = new G380_SuspendedDelAS2https();
		 tst.f("G380_SuspendedDelAS2https", "SUS_OUT_E2_USER", "no", "21", "FTP", "SUS_OUT_E2_FILE", "TESTFILE.txt", "/inbox", "DEL", "ASCII", "PASSIVE", "SUS_INB_CERT_FILE");
	 }
	
	 @Test
	 @Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode", "Basefile2"})
	 public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, String remotedirectory, String action, String filetype, String filetransfermode, String Basefile2) throws IOException, InterruptedException{
		  logger.info("G380_SuspendedDelAS2https Execution Started");
		  logger.info("Loading Properties");
		  LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);
		  servername=lp.readProperty("server");
		  unixServerUrl = lp.readProperty("unixServerUrl");
		  G380User = lp.readProperty("G380User");
		  qcurl=lp.readProperty("almurl");
		  qcuname=lp.readProperty("almuser");
		  qcpwd=lp.readProperty("almpwd");
		  domain=lp.readProperty("almdomain");
		  project=lp.readProperty("almproject");
		  TLpath=lp.readProperty("almTLPath");
		  TSet=lp.readProperty("almTSet");
		  
		  id=lp.readProperty("Certtpuser");
		  pass=lp.readProperty("Certtppwd");
		  url=lp.readProperty("Certtpurl");
		  
		  int intport=Integer.parseInt(port);
		  Map dwnld = new HashMap();
		  
		  Login lg=new Login(logger);
		 /* File f = new File("sysoutput.txt");
		  PrintStream out = new PrintStream(new FileOutputStream(f, true));
		  System.setOut(out);*/
		  connectionmap= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD, protocol);
		  if((boolean) connectionmap.get("loginstatus")){
			  logger.info(sftuser+" logged into "+servername+" successfully ");
			  Upload up=new Upload(logger);
			  uplaodmap = up.uploadFile(connectionmap, basefilename, physicalfile, remotedirectory, filetype, filetransfermode);
			  if((boolean) uplaodmap.get("uploadstatus")){
				  uploadedfilename = (String) uplaodmap.get("Filename");
				  logger.info(sftuser+" uploaded "+uploadedfilename+" successfully ");
				 
				  Thread.sleep(FrameworkConstants.SleepValue);
				  Thread.sleep(60000);
				  
				int tststus= CertTMVerification(G380User);
				  if(tststus==1)
				  {
					  teststatus=1;
				  }else
				  {
					  teststatus=0;
				  }
				  
				  
				  
				  loff=new Logoff(logger);
				  
				  loff.logofffromSFT(connectionmap);
				  
				 
			  }
			  else{
				  teststatus=0;
				  logger.info(sftuser+" failed to upload "+basefilename);
				  TID="Upload Failed";
			  }
			  TID=(String)uplaodmap.get("TID");
		  }else{
			  logger.info(sftuser+" unable to login to "+servername);
			  teststatus=0;
			  TID="Login Failed";
		  }
	
		  
		  
		  TestcaseLookup tl =new TestcaseLookup(logger);
		  //String groupname = tcname.substring(0, 2);
		  lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G380");
		  LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
		  runIdFile=(lp1.readProperty("RUNID"));
		  wtr=new WriteTestResult();
		  testlog=new WriteTestResult();
		  
		  switch(almupdate)
		  {
		  case "No":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G380,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G380,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "no":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G380,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G380,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "yes":
			  updateALM();
			  break;
		  case "Yes":
			  updateALM();
			  break;
		  }

		  
		  
				  logger.info("G380_SuspendedDelAS2https Execution completed");
	 }
	 
	 public void updateALM()
	 {
		  /*ALMConnect alm = new ALMConnect();
		  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
		  if(qcstatus){
			  if(teststatus==1){
				  String strStatus="Passed";
				  String filePath=FrameworkConstants.RunLog;
				  String workdir=System.getProperty("user.dir");
		          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
		          System.out.println("workdir"+workdir);
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Passed");
					  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
					  wtr.writeToFile(runIdFile,"G380,"+ lst.get(i)+","+TID+",Passed");
				  }
			  }else{
					  String strStatus="Failed";
					  String filePath=FrameworkConstants.RunLog;
					  String workdir=System.getProperty("user.dir");
			          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
			          System.out.println("workdir"+workdir);
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Failed");
						  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						  wtr.writeToFile(runIdFile,"G380,"+ lst.get(i)+","+TID+",Failed");
					  }
				  }
				  
			  }else{
			  System.out.println("Unable to login to ALM");
			  }
*/
	 
	 }
	 
	 //TM Check
	 public int CertTMVerification(String rmuser) throws InterruptedException
		{
			 System.out.println("connecting to firefox");
	         FirefoxProfile profile1 = new FirefoxProfile();  
	         profile1.setPreference("network.proxy.type",4);
	         
	         
	         WebDriver wd= new FirefoxDriver(profile1);
	         
	         wd.manage().window().maximize();
	         
	   wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	   logger.info("login to TM");
	   System.out.println("connected to TM");
	   System.out.println("opening TM");
	   wd.get(url);
	   wd.findElement(By.id("textboxuid_AD")).click();
	   wd.findElement(By.id("textboxuid_AD")).clear();
	   wd.findElement(By.id("textboxuid_AD")).sendKeys(id);
	   wd.findElement(By.id("textboxpwd_AD")).click();
	   wd.findElement(By.id("textboxpwd_AD")).clear();
	   wd.findElement(By.id("textboxpwd_AD")).sendKeys(pass);
	   wd.findElement(By.id("Login")).click();
	   
	   
	  
	   logger.info("login successful");
	   System.out.println("login successful");
			
	    logger.info("Select TM tab");
	    System.out.println("Select TM tab");
	    Thread.sleep(FrameworkConstants.SleepValue);
		wd.findElement(By.xpath("//*[@id='NavigationButton2']")).click();	
		wd.findElement(By.xpath("//*[@id='NavigationButton2']")).click();
		logger.info("Selected TM tab ");
		wd.findElement(By.name("timeZoneId")).click();
		wd.findElement(By.xpath("//select[@name='timeZoneId']/option[16]")).click();
		//.//*[@id='FileResult']/tbody/tr[2]/td[5]/p/font
		
		wd.findElement(By.xpath("//select[@name='filterBy']/option[2]")).click();
		wd.findElement(By.xpath("//input[@name='filterByValue']")).sendKeys(rmuser);
		wd.findElement(By.xpath("//input[@name='search']")).click();
		String lastact=wd.findElement(By.xpath(".//*[@id='FileResult']/tbody/tr[2]/td[5]/p/font")).getText();
		System.out.println(" The last activity time is "+lastact);
		
		String[] lastact1;
		String[] lastact2;
		String[] datetimestring1;
		String[] datetimestring2;
		
		
		
		/*LocalDate localDate = LocalDate.now(ZoneId.of("UTC-07:00"));
		DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyyMMdd HHmmss");
		formatter1.format(localDate);*/
		
		
		
		LocalDateTime datetime= LocalDateTime.now(ZoneId.of("UTC-07:00"));
		  String datetimestring=datetime.toString();
		  System.out.println(" LocalDateTime : "+datetime);
		 
		 
		  datetimestring1= datetimestring.split("T");
		  datetimestring2 =datetimestring1[1].split(":");
		  
		  lastact1=lastact.split(" ");
		  lastact2=lastact1[1].split("\\.");
		  
		  System.out.println("lastact1[1] = "+lastact1[1]);
		  
		  System.out.println("lastact1[0] "+lastact1[0]);
		  System.out.println(" datetimestring1[0] "+ datetimestring1[0]);
		  
		
		  
		  
		  
		  System.out.println("datetimestring2  "+datetimestring2[0]+" and "+datetimestring2[1]);
		  
		  System.out.println("lastact2 "+lastact2[0]+" and "+lastact2[1]);
		  
		  
		  if(lastact1[0].equals(datetimestring1[0]))
		  {
			  System.out.println(" The date are same");
			  logger.info(" The date are same");
			 
			  int hour1=Integer.parseInt(lastact2[0]);
			  hour1=(hour1*60)+Integer.parseInt(lastact2[1]);
			  System.out.println("hour1= "+hour1);
			  
			  int hour2=Integer.parseInt(datetimestring2[0]);
			  hour2=(hour2*60)+Integer.parseInt(datetimestring2[1]);
			  System.out.println("hour2= "+hour2);
			  
			  if((hour2-hour1)<=15 || (lastact2[0].equals("00")) || (datetimestring2[0].equals("12")) || (lastact2[0].equals("12")) || (datetimestring2[0].equals("00")))
			  {
				 logger.info("The time difference is matching");
				 System.out.println("The time difference is matching");
				 		
				  String stepStatus=wd.findElement(By.xpath(".//*[@id='FileResult']/tbody/tr[2]/td[6]/p/font")).getText();
				  System.out.println("stepStatus "+stepStatus);
				  logger.info("stepStatus "+stepStatus);
				//td[@class='imageAlign']
				 /* wd.findElement(By.xpath("//td[@class='imageAlign']")).click();
				  String Statusvalue1=wd.findElement(By.xpath(".//*[@id='SFTBUTTONLYR']/tbody/tr[4]/td[3]/a/p/font")).getText();
				  String Statusvalue2=wd.findElement(By.xpath(".//*[@id='SFTBUTTONLYR']/tbody/tr[4]/td[5]/p/font")).getText();
				  
				  Statusvalue1=Statusvalue1.trim();
				  Statusvalue2= Statusvalue2.trim();
				  System.out.println("Statusvalue1 "+Statusvalue1);
				  System.out.println("Statusvalue2 "+Statusvalue2);
				  
				  if((Statusvalue1.equals("Suspend")) && (Statusvalue2.equals("Completed")))
				  {
					  System.out.println(" the file is suspended successfully");
					  logger.info(" The file is suspended successfully");
					  if(wd.findElement(By.xpath(".//*[@id='abc3']/table[2]/tbody/tr[2]/td[5]/p/font")).getText().contains("User profile is not available - Moving the file to Suspended directory"))
					  {
						  TMStatus=1;
					  }
					  TMStatus=0;
				  }
				  else{
					  System.out.println(" the file is not suspended successfully");
					  logger.info(" The file is not suspended successfully");
					  TMStatus=0;
				  }*/
				  if(stepStatus.equals("Suspend-Completed"))
				  {
					  TMStatus=1;  
				  }
				  else
				  {
					  TMStatus=0;  
				  }
				  
			  }
			  else{
				  logger.info("The time difference is not matching");
					 System.out.println("The time difference is not matching");
					 TMStatus=0; 		
				  
			  }
			  
			  
		  }
		  else{
			  System.out.println(" The date are not matching");
			  logger.info(" The date are not matching");
			  TMStatus=0;
		  }
		  System.out.println(" TMStatus  "+TMStatus);
		  wd.quit();
		return TMStatus;
		  
		  
		  
		  
		  
			
		}
	 
	 
	 
	 
	 
	 
	 
}


