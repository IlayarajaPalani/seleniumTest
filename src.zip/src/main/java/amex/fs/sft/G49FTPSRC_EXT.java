package amex.fs.sft;



import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.LoggerFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import amex.fs.commons.Download;
import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.Login;
import amex.fs.commons.Logoff;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.Upload;
import amex.fs.commons.WriteTestResult;

public class G49FTPSRC_EXT {
	int teststatus=0;
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G49FTPSRC_EXT.class);
	 String uploadedfilename = null;
	 String decompressedfile = null;
	 String filetobedownloaded=null;
	 String src_filename=null;
	 String src_extoutbox=null;
	 String downloadedfilename=null;
	 
	  Map connectionmap, uplaodmap;
	  String servername;
	  String qcurl;
	  String qcuname;
	  String qcpwd;
	  String domain;
	  String project;
	  String TLpath;
	  String TSet;
	  String runIdFile;
	  List<String> lst;
	  WriteTestResult wtr,testlog;
	  String TID;
	  
	public static void main(String[] args)
	{
		G49FTPSRC_EXT fg = new G49FTPSRC_EXT();
		try {
			fg.f("G49FTPSRC_EXT", "G49FTPSRC_EXT", "amex123", "21", "FTP", "G49FTP_file", "C:\\Users\\PJ5026032\\Desktop\\TESTING\\Automation test data\\Auto_Test_data_Sel\\G49FTP_file.txt", "/inbox", "UD", "BINARY", "PASSIVE", "NULL");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	//compression starts here
	 @SuppressWarnings("unused")
	@Test
	 @Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode","BaseFile2"})
	 public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, String remotedirectory, String action, String filetype, String filetransfermode,String basefile2) throws IOException, InterruptedException{
		  logger.info("G49FTPSRC_EXT Execution Started");
		  logger.info("Loading Properties");
		  
		  LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);
		  servername=lp.readProperty("server");
		  qcurl=lp.readProperty("almurl");
		  qcuname=lp.readProperty("almuser");
		  qcpwd=lp.readProperty("almpwd");
		  domain=lp.readProperty("almdomain");
		  project=lp.readProperty("almproject");
		  TLpath=lp.readProperty("almTLPath");
		  TSet=lp.readProperty("almTSet");
		//BasicConfigurator.configure();
		  int intport=Integer.parseInt(port);
		  Map dwnld = new HashMap();
		  Map dwnld1 = new HashMap();
		  boolean constatus= false;
		  boolean sizestatus = false;
		  
		 // setting file name and file to be downloaded 
		  System.out.println(" the physical file name is :"+physicalfile);
		  File pfile=new File(physicalfile);
		  src_filename=pfile.getName();
		  System.out.println("the file name is :"+src_filename);
		  
		  String filedown[]=src_filename.split("\\.");
		  //String file1=filedown[0];
		  System.out.println("part1 "+filedown[0]);
		  System.out.println("part2 "+filedown[1]);
		  String uplodedfile_ext=filedown[1];
		  
		  filetobedownloaded =basefilename+"."+uplodedfile_ext;
		  System.out.println("To be downloaded filename "+filetobedownloaded);
		  
		  
		  Login lg=new Login(logger);
		  connectionmap= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD, protocol);
		  if((boolean) connectionmap.get("loginstatus")){
			  logger.info(sftuser+" logged into "+servername+" successfully ");
			  Upload up=new Upload(logger);
			  uplaodmap = up.uploadFile(connectionmap, basefilename, physicalfile, remotedirectory, filetype, filetransfermode);
		
			  if((boolean) uplaodmap.get("uploadstatus")){
				  uploadedfilename = (String) uplaodmap.get("Filename");
				  logger.info(sftuser+" uploaded "+uploadedfilename+" successfully ");
				  System.out.println("file in inbox:"+uploadedfilename);
				  System.out.println("file uploaded for verifying src extension");
				  
				 /*//get the source extension from inbox file
				  String getsrcext[] =uploadedfilename.split("#");
				  String ext1=getsrcext[0];
				  System.out.println("the first split value is "+ext1);
				  
				  String extsplit[]=ext1.split(".");
				  String src_extinbox=extsplit[1];*/
				  
				  
				  Download downloadmap = new Download(logger);
				  System.out.println(" download the file from outbox");
				  
				  
				  
				
				  
				  System.out.println("the file to be downloaded is :"+filetobedownloaded);
				  
				  switch(action)
				  {
				  case "UD" :
					  Thread.sleep(FrameworkConstants.SleepValue);
					  Thread.sleep(10000);
					  System.out.println("Inside Switch UD");
		  				dwnld= downloadmap.downloadFile(connectionmap, filetobedownloaded, FrameworkConstants.DownloadDirectory+""+filetobedownloaded, FrameworkConstants.RemoteOutbox, filetype, filetransfermode);
		  				System.out.println("Status: "+ (boolean) dwnld.get("downloadstatus"));
		  				if((boolean) dwnld.get("downloadstatus"))
		  				{
		  					//get the name of downloaded file 
		  					downloadedfilename = (String) dwnld.get("Filename");
		  					System.out.println("the downloaded file is "+downloadedfilename);
		  				
		  					
		  					
		  					logger.info(FrameworkConstants.DownloadDirectory+filetobedownloaded+" Downloaded Successfully");
		  					System.out.println("the download is successful");
		  				}else
		  				{
		  					logger.info(FrameworkConstants.DownloadDirectory+filetobedownloaded+" Download Failed");
		  					System.out.println("the download failed");
		  				}
		  				break;
		  	
				  case "UDD"  :
					  Thread.sleep(FrameworkConstants.SleepValue);
 						dwnld= downloadmap.downloadFile(connectionmap, filetobedownloaded, FrameworkConstants.DownloadDirectory+""+filetobedownloaded, FrameworkConstants.RemoteOutbox, filetype, filetransfermode);
 						
 						if((boolean) dwnld.get("downloadstatus"))
						{
 							
 							//get the name of downloaded file 
		  					downloadedfilename = (String) dwnld.get("Filename");
		  					System.out.println("the downloaded file is "+downloadedfilename);
 							
							logger.info(FrameworkConstants.DownloadDirectory+filetobedownloaded+" Downloaded Successfully from Outbox");
							Thread.sleep(FrameworkConstants.SleepValue);
	 						dwnld= downloadmap.downloadFile(connectionmap, filetobedownloaded, FrameworkConstants.DownloadDirectory+""+filetobedownloaded, FrameworkConstants.RemoteSent, filetype, filetransfermode);
	 						if((boolean) dwnld.get("downloadstatus"))
							{
								logger.info(FrameworkConstants.DownloadDirectory+filetobedownloaded+" Downloaded Successfully from Sent");
							}else
							{
								logger.info(FrameworkConstants.DownloadDirectory+filetobedownloaded+" Download Failed from Sent");
							} 
						}else
						{
							logger.info(FrameworkConstants.DownloadDirectory+filetobedownloaded+" Download Failed from Outbox");
						} 
 						break;
		  				
		  		default:
		  			 	teststatus=0;
		  				break;
			  }
				 
				//getting the extension from downloaded file 
				  
				 String downloadsplit[]= downloadedfilename.split("\\.");
				 src_extoutbox=downloadsplit[1];
				 if(src_extoutbox.equals(uplodedfile_ext))
				 {
					 logger.info("the extensions are equal");
					 System.out.println("the extensions are same");
				 }
				 else
				 {
					 logger.info("the extensions are different");
					 System.out.println("the extensions are different");
				 }
				//Compression ends here
				// uploading for decompression
				
					  
					  
				//Comparison of files:
					 /* System.out.println("the file comparission is starting:");
					  
					  FileComparision fc = new FileComparision(logger);
						constatus = fc.contentVerification(physicalfile, FrameworkConstants.DownloadDirectory+"/"+decompressedfile);
						logger.info("File comparison status:"+constatus);
						FileSizeCheck fs = new FileSizeCheck(logger);
						sizestatus = fs.fileSizeVerification(physicalfile, FrameworkConstants.DownloadDirectory+"/"+decompressedfile);
						logger.info("File size verification status:"+sizestatus);
						if(constatus&&sizestatus){
							teststatus=1; //if file same 
							
							System.out.println("the file before compression and file after decompression are same");
							}else{
								teststatus=0; // if different
								System.out.println("the file before compression and file after decompression are different");
								 }
						
						System.out.println("the comparision status is: "+teststatus);*/
					  
					  
					  
					  
					  
				  
				  }
						  
				
					 
			  else{
				  teststatus=0;
				  logger.info(sftuser+" failed to upload "+basefilename);
				  TID="Upload Failed";
			  }
			  TID=(String)uplaodmap.get("TID");
		  }else{
			  logger.info(sftuser+" unable to login to "+servername);
			  teststatus=0;
			  TID="Login Failed";
		  }
		  
		  
		  TestcaseLookup tl =new TestcaseLookup(logger);
		  //String groupname = tcname.substring(0, 2);
		  lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G49");
		  LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
		  runIdFile=(lp1.readProperty("RUNID"));
		  wtr=new WriteTestResult();
		  testlog=new WriteTestResult();
		  
		  switch(almupdate)
		  {
		  case "No":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G49,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G49,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "no":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G49,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G49,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  /*case "yes":
			  updateALM();
			  break;
		  case "Yes":
			  updateALM();
			  break;*/
		  }
		  
		  /*TestcaseLookup tl =new TestcaseLookup(logger);
		  //String groupname = tcname.substring(0, 2);
		  List<String> lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G29");
		  System.out.println("1st :"+lst.size());
		  ALMConnect alm = new ALMConnect();
		  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
		  if(qcstatus){
			  if(teststatus==1){
				  String strStatus="Passed";
				  String filePath=FrameworkConstants.RunLog;
		          String workdir=System.getProperty("user.dir");
		          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
		          System.out.println("workdir "+workdir);
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Passed");
					  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, fileName); 
				  }
			  }else{
					  String strStatus="Failed";
					  String filePath=FrameworkConstants.RunLog;
			          String workdir=System.getProperty("user.dir");
			          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
			          System.out.println("workdir"+workdir);
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Failed");
						  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, fileName); 
					  }
				  }
				  
			  }else{
			  System.out.println("Unable to login to ALM");
			  }*/
		  
		  if(teststatus==1)
		  {
		   Logoff loff=new Logoff(logger);
		   loff.logofffromSFT(connectionmap);
		  }
		  logger.info("G29FTPCompDecomp Execution completed");
	 
	 }
	 
	 public void updateALM()
	 {
		  /*ALMConnect alm = new ALMConnect();
		  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
		  if(qcstatus){
			  if(teststatus==1){
				  String strStatus="Passed";
				  String filePath=FrameworkConstants.RunLog;
				  String workdir=System.getProperty("user.dir");
		          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
		          System.out.println("workdir"+workdir);
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Passed");
					  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
					  wtr.writeToFile(runIdFile,"G48,"+ lst.get(i)+","+TID+",Passed");
				  }
			  }else{
					  String strStatus="Failed";
					  String filePath=FrameworkConstants.RunLog;
					  String workdir=System.getProperty("user.dir");
			          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
			          System.out.println("workdir"+workdir);
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Failed");
						  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						  wtr.writeToFile(runIdFile,"G48,"+ lst.get(i)+","+TID+",Failed");
					  }
				  }
				  
			  }else{
			  System.out.println("Unable to login to ALM");
			  }*/

	 
	 }

}
