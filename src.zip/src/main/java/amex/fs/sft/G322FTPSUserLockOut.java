package amex.fs.sft;




/*Description:
 * project: NGP Automation.
 * author: PJ5026032
 * This program is to test User lockout is not replicating in TP using FTPS protocol .
 * a user will try to login to TP with wrong password During 4th attempted  user should be lockout . 
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.net.ftp.FTPSClient;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import amex.fs.commons.Download;
import amex.fs.commons.FileComparision;
import amex.fs.commons.FileSizeCheck;
import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.Login;
import amex.fs.commons.Logoff;
import amex.fs.commons.TPUserLockCheck;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.Upload;
import amex.fs.commons.WriteTestResult;



	@SuppressWarnings("unused")
	public class G322FTPSUserLockOut{
		boolean teststatus=false;
		public static org.slf4j.Logger logger = LoggerFactory.getLogger(G322FTPSUserLockOut.class);
		 String uploadedfilename = null;
		 boolean TPcheck =true;
	
		  Map connectionmap, uplaodmap;
		  String servername,TPurl,TPuser,TPpwd;
		  String qcurl;
		  String qcuname;
		  String qcpwd;
		  String domain;
		  String project;
		  String TLpath;
		  String TSet;
		  String runIdFile;
		  List<String> lst;
		  WriteTestResult wtr,testlog;
		 boolean TMVerification_status = false;
		 String TID;
		 
		 
		  /* Main method which takes the parameter from the testng.xml
			  * 
			  */
		public static void main(String[] args) throws Throwable
		{
			G322FTPSUserLockOut fg = new G322FTPSUserLockOut();
			
				fg.f( "G322FTPSUserLockOut", "POD_SENTUSER","No", "21", "FTPS","HFUSER02file", null, null,null,null, null,null);
				
		}
		
		
		@Test
		/* Loading Properties for ALM and SFT details
		   * 
		   */
		@Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode","Basefile2"})

		public void f(String tcname, String sftuser, String almupdate, String port, String protocol ,String basefilename, String physicalfile, String remotedirectory,String Action, String filetype, String filetransfermode,String Basefile2) throws Throwable{
			try{

		logger.info("G322FTPSUserLockOut Execution Started");
		System.out.println("G322FTPSUserLockOut Execution Started");

		logger.info("Loading Properties");
		/* properties file loaded successfully
		  */
		

		LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);

		servername=lp.readProperty("server");
		qcurl=lp.readProperty("almurl");
		qcuname=lp.readProperty("almuser");
		qcpwd=lp.readProperty("almpwd");
		domain=lp.readProperty("almdomain");
		project=lp.readProperty("almproject");
		TLpath=lp.readProperty("almTLPath");
		TSet=lp.readProperty("almTSet");
		int intport=Integer.parseInt(port);

		TPurl=lp.readProperty("tpurl");
		TPuser=lp.readProperty("tpuser");
		TPpwd=lp.readProperty("tppwd");

		TPUserLockCheck track =new TPUserLockCheck();

		

		Login lg=new Login(logger); 
		/* Login to SFT server using SFTP protocol and checking the connection status
		   * 
		   */
		
		
	//checking user is already locked or not
		 teststatus= track.trackingidverify(sftuser,TPurl,TPuser,TPpwd);
		 if (teststatus){
			 System.out.println(sftuser+" is already locked in TP.\n Please unlock the user in TP");
			 TID="Account already locked";
			 teststatus =false;
		 } else{
			 
			 connectionmap= lg.logintoSFT(servername, intport, sftuser, "amex", protocol);
			// System.out.println("First message: " +connectionmap.get("Message"));
		 
		// String msgefirst [] = (String []) connectionmap.get("Message");
		/* for (String str : msgefirst.length){
		 System.out.println(msgefirst []]);
		 }*/
		 /*if(msgefirst[1].contains(" locked."))
		  {
			  System.out.println("User is already locked. Please unlock the user in TP application");
			  logger.info("User is already locked. Please unlock the user in TP application");
			  teststatus = false;
			  TID="User Account Already Locked";
			  TPcheck =false;
		  }else{*/
		  connectionmap= lg.logintoSFT(servername, intport, sftuser,"amex", protocol);
		  
		  connectionmap= lg.logintoSFT(servername, intport, sftuser, "amex", protocol);
		  
		  connectionmap= lg.logintoSFT(servername, intport, sftuser, "amex", protocol);
		  
		  //String msgefinal = (String) connectionmap.get("Message");
		  //if(connectionmap.get("Message").toString().contains("530 Authentication failed: User account is locked"))
		 /* if(msgefinal.contains(" locked"))
		  {   TPcheck =true;
			  teststatus=true;
			  TID="User Account Locked";
			  System.out.println("User is locked ");
		  }else{
			  TPcheck =true;
			  teststatus=false;
			  TID="User Account Not Locked after 3 attempts";
			  System.out.println("User is not locked");
		 }*/
		 // }

/*       for(int i=1;i<=4;i++)
       {
		connectionmap= lg.logintoSFT(servername, intport, sftuser, TPpwd, protocol);
		
		if((boolean) connectionmap.get("loginstatus")){ //check weather login is successful

			logger.info(sftuser+" logged into "+servername+" successfully ");
            System.out.println(sftuser+" logged into "+servername+" successfully ");

			teststatus=false; // if different
			
			System.out.println("able to login");
			logger.info("able to login");
			teststatus=false;
			TID="Login Successful";
			break;
	}
		else if(connectionmap.get("Message").toString().contains("locked")){
			TID="Login Failed";
			break;
		}
		System.out.println(sftuser+"Unable to login to due to wrong password in :"   +i+  "attempt");
		logger.info(sftuser+"Unable to login to due to wrong password: in"+i+"attempt");
       }*/
       
		//if(((boolean) connectionmap.get("loginstatus")==false) && TPcheck)
		 //if(TPcheck)
		 //check weather login is successful

            G322FTPSUserLockOut fg = new G322FTPSUserLockOut();
            
            System.out.println("TP checking started...");
			teststatus= track.trackingidverify(sftuser,TPurl,TPuser,TPpwd);
			System.out.println("testcase  is"+ teststatus);
			logger.info("testcase is "+teststatus);
			//teststatus=true;
			if (teststatus){
				TID="User Account Locked after 3 attempts in TP";
				System.out.println("User Account Locked after 3 attempts in TP");
				logger.info("User Account Locked after 3 attempts in TP");
			}else
			{   System.out.println("User Account Not Locked after 3 attempts in TP");
				TID="User Account Not Locked after 3 attempts in TP";
				logger.info("User Account Not Locked after 3 attempts in TP");
			}
			

}		
		
		
		
	
		TestcaseLookup tl =new TestcaseLookup(logger);
		// Identifying the testcase to be updated in the ALM based on the group number
		 
		 
		lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G322");
		
		  LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
		  runIdFile=(lp1.readProperty("RUNID"));
		  wtr=new WriteTestResult();
		  testlog=new WriteTestResult();
		  
		  switch(almupdate)
		  {
		  case "No":
			  if(teststatus)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G322,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G322,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "no":
			  if(teststatus)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G322,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G322,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "yes":
			  updateALM();
			  break;
		  case "Yes":
			  updateALM();
			  break;
		  }
		
		
		/*logging off from the SFT server
		 * 
		 */

		logger.info("G322FTPSUserLockOut Execution completed");
		System.out.println("G322FTPSUserLockOut Execution completed");

		
			}
		 catch(NullPointerException e1)
	        {   e1.printStackTrace();
	        	logger.info("unable to proceed:\t"+e1);
	        	TMVerification_status=false;
	        	
	        }
			catch (Throwable e3) {
				
				e3.printStackTrace();
	        	logger.info("unable to proceed:\t"+e3);
	        	TMVerification_status=false;

			}
		}
		
	
/*		 public boolean trackingidverify(String user,String url,String id,String pass) throws Throwable
		 
		    {
			 try{
				 System.out.println("connecting to firefox");
			
		           FirefoxProfile profile1 = new FirefoxProfile();  
		           profile1.setPreference("network.proxy.type",4);
		           
		           
		           WebDriver wd= new FirefoxDriver(profile1);
		           
		           wd.manage().window().maximize();
		           
		     wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		     logger.info("login to TP");
		     System.out.println("connected to TP");
		     System.out.println("opening TP");
		     wd.get(url);
		     Thread.sleep(FrameworkConstants.SleepValue); 
		     wd.findElement(By.id("textboxuid_AD")).click();
		     wd.findElement(By.id("textboxuid_AD")).clear();
		     wd.findElement(By.id("textboxuid_AD")).sendKeys(id);
		     wd.findElement(By.id("textboxpwd_AD")).click();
		     wd.findElement(By.id("textboxpwd_AD")).clear();
		     wd.findElement(By.id("textboxpwd_AD")).sendKeys(pass);
		     wd.findElement(By.id("Login")).click();
		     wd.findElement(By.id("NavigationButton2")).click();
		     logger.info("login successful");
		     System.out.println("login successful");
		     if (!wd.findElement(By.xpath(" /html/body/table[3]/tbody/tr/td[1]/form/table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr[4]/td/a/img")).isSelected()) {
		    	 wd.findElement(By.xpath(" /html/body/table[3]/tbody/tr/td[1]/form/table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr[4]/td/a/img")).click();
		     }
		    
		     if (!wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[1]/form/div/dl[4]/dd/a[1]/img")).isSelected()) {
		    	 wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[1]/form/div/dl[4]/dd/a[1]/img")).click();
		     }
		     Thread.sleep(FrameworkConstants.SleepValue); 
		     //wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[1]/input")).clear();
	         //wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[1]/input")).sendKeys(transmitter);
		    
		     wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[1]/input")).clear();
		         wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[1]/input")).sendKeys(user);
		         
		         Thread.sleep(FrameworkConstants.SleepValue); 
		         
		         if (!wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[8]/td/input[1]")).isSelected()) {
			    	 wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[8]/td/input[1]")).click();
			     }
		         logger.info("searching:"  +user);
			     System.out.println("searching:"    +user);   
		     
	 wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/table/tbody/tr[3]/td[1]/a")).click();
	 for(int i=2;i<=10;i++)
	 { 
		 for(int j=3;j<=22;j++)
		 {
			 String temp= wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/div/div[2]/table/tbody/tr["+j+"]/td[1]/a")).getText();
			 if(temp.equals(user))
			 {
				 wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/div/div[2]/table/tbody/tr["+j+"]/td[1]/a")).click();
				 TMVerification_status=true;
				 break;
			 }
			
				 
		 }
		 
		 
		 if( TMVerification_status==true)
		 {
			break; 
			 
		 }
		
		 
		 wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/div/div[2]/table/tbody/tr[23]/td/a["+i+"]")).click();
		 Thread.sleep(5000);
			 
		 }
	 Thread.sleep(FrameworkConstants.SleepValue); 
	
	
	 Thread.sleep(FrameworkConstants.SleepValue); 
	 String temp= wd.findElement(By.xpath(" /html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[10]/td[1]/font")).getText();
	
	
	
	 if(temp.equals("User Lockout Status: Locked"))
		   {
			   System.out.println("passed");
			   TMVerification_status =true;
			   logger.info(user+"is locked due to wrong password");
			   System.out.println(user+"is locked due to wrong password");
			
		     }
		   else{
			   System.out.println("failed");
			   TMVerification_status =false;
			   logger.info("test case is failed");
		   }
		     
	
		   logger.info("logoff from TP");
		     System.out.println("logoff from TP");   
		     
		     wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[1]/form/div/dl[9]/a/img")).click();
		     wd.switchTo().alert().accept();
		     
		     Thread.sleep(FrameworkConstants.SleepValue); 
		     wd.quit();
		     
		           
		           
		     
		          
		          
		    
		    }
			 catch(NullPointerException e1)
		        {   e1.printStackTrace();
		        	logger.info("unable to proceed:\t"+e1);
		        	TMVerification_status=false;
		        	
		        }
		        catch(NoSuchElementException e2)
		        {   
		        	e2.printStackTrace();
		        	logger.info("unable to proceed:\t"+e2);
		        	TMVerification_status=false;
		        } catch (Throwable e3) {
					
					e3.printStackTrace();
		        	logger.info("unable to proceed:\t"+e3);
		        	TMVerification_status=false;

				}
		        return TMVerification_status; 
	}*/
		 
		 public void updateALM()
		 {
			/*  ALMConnect alm = new ALMConnect();
			  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
			  if(qcstatus){
				  if(teststatus){
					  String strStatus="Passed";
					  String filePath=FrameworkConstants.RunLog;
					  String workdir=System.getProperty("user.dir");
			          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
			          System.out.println("workdir"+workdir);
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Passed");
						  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						  wtr.writeToFile(runIdFile,"G322,"+ lst.get(i)+","+TID+",Passed");
					  }
				  }else{
						  String strStatus="Failed";
						  String filePath=FrameworkConstants.RunLog;
						  String workdir=System.getProperty("user.dir");
				          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
				          System.out.println("workdir"+workdir);
						  for(int i=0;i<lst.size();i++)
						  {
							  logger.info("Updating"+lst.get(i)+"status as Failed");
							  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
							  wtr.writeToFile(runIdFile,"G322,"+ lst.get(i)+","+TID+",Failed");
						  }
					  }
					  
				  }else{
				  System.out.println("Unable to login to ALM");
				  }
*/
		 
		 }	
		 
	}