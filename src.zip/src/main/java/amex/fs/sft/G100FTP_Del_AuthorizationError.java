package amex.fs.sft;




/*Description:
 * project: NGP Automation.
 * author: Viren Tiwari
 * This program is to test Suspended_File using AS2 protocol .
 * A file will be uploaded to SFT server and the file will be verified at the T&M   . 
 */
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.Login;
import amex.fs.commons.Logoff;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.Upload;
import amex.fs.commons.WriteTestResult;




	public class G100FTP_Del_AuthorizationError{
		boolean teststatus=false;
		public static org.slf4j.Logger logger = LoggerFactory.getLogger(G100FTP_Del_AuthorizationError.class);
		 String uploadedfilename = null;
		  String servername;
		  String qcurl;
		  String qcuname;
		  String qcpwd;
		  String domain;
		  String project;
		  String TLpath;
		  String TSet;
		  String runIdFile;
		  List<String> lst;
		  WriteTestResult wtr;
		  String TPuser;
		  String TPpwd;
		  String TPurl;
		
		 String TID = null;
		 Map connectionmap,connectionmap1,uploadmap;
		 boolean TMVerification_status = false;	
		 
		 
		  /* Main method which takes the parameter from the testng.xml
			  * 
			  */
		public static void main(String[] args) throws Throwable
		{
			G100FTP_Del_AuthorizationError fg = new G100FTP_Del_AuthorizationError();
			
				fg.f( "G100FTP_Del_AuthorizationError", "FTP_filepushUser","amex123", "21", "FTP", "authz_errorfile", "TESTFILE.txt", "/inbox",null, "ASCII", "PASSIVE","MAIL_FILE_2");
				
		}
		
		
		@Test
		/* Loading Properties for ALM and SFT details
		   * 
		   */
		@Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode","Basefile2"})

		public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, String remotedirectory,String Action, String filetype, String filetransfermode,String Basefile2 ) throws Throwable{
			try{

		logger.info("G100FTP_Del_AuthorizationError Execution Started");

		logger.info("Loading Properties");
		/* properties file loaded successfully
		  */
		

		LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);

		servername=lp.readProperty("server");
		qcurl=lp.readProperty("almurl");
		qcuname=lp.readProperty("almuser");
		qcpwd=lp.readProperty("almpwd");
		domain=lp.readProperty("almdomain");
		project=lp.readProperty("almproject");
		TLpath=lp.readProperty("almTLPath");
		TSet=lp.readProperty("almTSet");
		TPurl=lp.readProperty("tpurl");
		//BasicConfigurator.configure();
		TPuser=lp.readProperty("tpuser");
		
		TPpwd=lp.readProperty("tppwd");
		

		int intport=Integer.parseInt(port);

		uploadmap = new HashMap();

		Map dwnld = new HashMap();

		

		Login lg=new Login(logger); 
		/* Login to SFT server using SFTP protocol and checking the connection status
		   * 
		   */


		connectionmap= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD, protocol);
		if((boolean) connectionmap.get("loginstatus")){ //check weather login is successful

		logger.info(sftuser+" logged into "+servername+" successfully ");

		Upload up=new Upload(logger); //uploading the files into the server

		uploadmap = up.uploadFile(connectionmap, basefilename, physicalfile, remotedirectory, filetype, filetransfermode);
		 uploadedfilename = (String) uploadmap.get("Filename");
		 String[] file = uploadedfilename.split("\\#");
		  TID  = file[1];
		  System.out.println(TID);
		if((boolean) uploadmap.get("uploadstatus"))
		{
			G100FTP_Del_AuthorizationError fg = new G100FTP_Del_AuthorizationError();
			
			teststatus= fg.trackingidverify( TID,TPurl,TPuser,TPpwd);
			System.out.println("testcase  is"+teststatus);
			logger.info("testcase is "+teststatus);
			teststatus=true;
			
		}
			
      else{teststatus=false; // if different
		
			logger.info("unable to upload file");
			
		}}
		
		else{
			teststatus=false; // if different
			
			System.out.println("unable to login");
			logger.info("unable to login");
			teststatus=false;
		}
		
		
	
		TestcaseLookup tl =new TestcaseLookup(logger);
		// Identifying the testcase to be updated in the ALM based on the group number
		 
		 
		  lst = tl.lookupTestcase(FrameworkConstants.TCLookup,"G100");
		  
		  LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
		  runIdFile=(lp1.readProperty("RUNID"));
		  wtr=new WriteTestResult();
		  
		  switch(almupdate)
		  {
		  case "No":
			  if(teststatus)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G100,"+ lst.get(i)+","+uploadmap.get("TID")+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G100,"+ lst.get(i)+","+uploadmap.get("TID")+",Failed");
				  }
				  
			  }
			  break;
		  case "no":
			  if(teststatus)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G100,"+ lst.get(i)+","+uploadmap.get("TID")+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G100,"+ lst.get(i)+","+uploadmap.get("TID")+",Failed");
				  }
				  
			  }
			  break;

		  }

		
		/*logging off from the SFT server
		 * 
		 */

		logger.info("G100FTP_Del_AuthorizationError Execution completed");
		System.out.println("G100FTP_Del_AuthorizationError Execution completed");

		Logoff loff=new Logoff(logger);
		loff.logofffromSFT(connectionmap);
			}
		 catch(NullPointerException e1)
	        {   e1.printStackTrace();
	        	logger.info("unable to proceed:\t"+e1);
	        	TMVerification_status=false;
	        	
	        }
			catch (Throwable e3) {
				
				e3.printStackTrace();
	        	logger.info("unable to proceed:\t"+e3);
	        	TMVerification_status=false;

			}
		}
		
	
		 public boolean trackingidverify(String tid,String url,String id,String pass) throws Throwable
		 
		    {
			 try{
				 System.out.println("connecting to firefox");
			
		           FirefoxProfile profile1 = new FirefoxProfile();  
		           profile1.setPreference("network.proxy.type",4);
		           
		           
		           WebDriver wd= new FirefoxDriver(profile1);
		           
		           wd.manage().window().maximize();
		           
		     wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		     logger.info("login to TM");
		     System.out.println("connected to TM");
		     System.out.println("opening TM");
		     wd.get(url);
		     wd.findElement(By.id("textboxuid_AD")).click();
		     wd.findElement(By.id("textboxuid_AD")).clear();
		     wd.findElement(By.id("textboxuid_AD")).sendKeys(id);
		     wd.findElement(By.id("textboxpwd_AD")).click();
		     wd.findElement(By.id("textboxpwd_AD")).clear();
		     wd.findElement(By.id("textboxpwd_AD")).sendKeys(pass);
		     wd.findElement(By.id("Login")).click();
		     wd.findElement(By.id("NavigationButton2")).click();
		     logger.info("login successful");
		     System.out.println("login successful");
		     
		     if (!wd.findElement(By.id("NavigationButton2")).isSelected()) {
		    	 wd.findElement(By.id("NavigationButton2")).click();
		     }
		     
		    
		     if (!wd.findElement(By.xpath("//table[@id='Table6']/tbody/tr[3]/td/table/tbody/tr[2]/td[1]/p/font/select//option[5]")).isSelected()) {
		         wd.findElement(By.xpath("//table[@id='Table6']/tbody/tr[3]/td/table/tbody/tr[2]/td[1]/p/font/select//option[5]")).click();
		     }
		     wd.findElement(By.name("filterByValue")).click();
		     wd.findElement(By.name("filterByValue")).clear();
		     wd.findElement(By.name("filterByValue")).sendKeys(tid);
		   
		    
             
		     
	     
		     wd.findElement(By.name("search")).click();
		     wd.findElement(By.id("Picture14")).click();
		    
		     
		     wd.findElement(By.xpath("//div[@id='SFTBUTTONLYR']/layer/table/tbody/tr[5]/td[3]/a/p/font")).click();
		   Boolean temp= wd.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[3]/form/div[5]/layer/table[2]/tbody/tr[3]/td[1]/p/font")).getText().contains("Failed");
		 System.out.println("problem:");
		   
		   if(temp==true)
		   {
			   System.out.println("passed");
			   TMVerification_status =true;
			   logger.info("file is failed to push due to Authorization Error");
			  String temp1= wd.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[3]/form/div[5]/layer/table[2]/tbody/tr[3]/td[5]/p")).getText();
			
			  System.out.println(temp1);
			  logger.info("Error Message /t"+temp1 );
		   }
		   else{
			   System.out.println("failed");
			   TMVerification_status =false;
			   logger.info("test case is failed");
		   }
		     
		     
		   logger.info("logoff from TM");
		     wd.findElement(By.name("logoutTM")).click();
		     Thread.sleep(FrameworkConstants.SleepValue); 
		     wd.quit();
		     
		           
		           
		           if( TMVerification_status)
		           {
		                  System.out.println(" the delivery is completed");
		           }
		           else
		           {
		                  System.out.println("the delivery got failed");
		           }
		           
		          
		          
		    
		    }
			 catch(NullPointerException e1)
		        {   e1.printStackTrace();
		        	logger.info("unable to proceed:\t"+e1);
		        	TMVerification_status=false;
		        	
		        }
		        catch(NoSuchElementException e2)
		        {   
		        	e2.printStackTrace();
		        	logger.info("unable to proceed:\t"+e2);
		        	TMVerification_status=false;
		        } catch (Throwable e3) {
					
					e3.printStackTrace();
		        	logger.info("unable to proceed:\t"+e3);
		        	TMVerification_status=false;

				}
		        return TMVerification_status; 
	}
	
		 public void updateALM()
		 {
			  /*ALMConnect alm = new ALMConnect();
			  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
			  if(qcstatus){
				  if(teststatus){
					  String strStatus="Passed";
					  String filePath=FrameworkConstants.RunLog;
					  String workdir=System.getProperty("user.dir");
			          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
			          System.out.println("workdir"+workdir);
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Passed");
						  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						  wtr.writeToFile(runIdFile,"G100,"+ lst.get(i)+","+uploadmap.get("TID")+",Passed");
					  }
				  }else{
						  String strStatus="Failed";
						  String filePath=FrameworkConstants.RunLog;
						  String workdir=System.getProperty("user.dir");
				          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
				          System.out.println("workdir"+workdir);
						  for(int i=0;i<lst.size();i++)
						  {
							  logger.info("Updating"+lst.get(i)+"status as Failed");
							  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
							  wtr.writeToFile(runIdFile,"G100,"+ lst.get(i)+","+uploadmap.get("TID")+",Failed");
						  }
					  }
					  
				  }else{
				  System.out.println("Unable to login to ALM");
				  }*/

		 
		 }
	 
	}