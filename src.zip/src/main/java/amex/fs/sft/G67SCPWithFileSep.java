package amex.fs.sft;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.slf4j.LoggerFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


import amex.fs.commons.FileComparision;
import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LinuxBoxFileTransfer;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.SCPClient;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.WriteTestResult;

/*
 * POA_File Upload using SCP Protocol_Source and destination user should be migrated.
 *
 * POA_Download file from outbox using SCP Protocol
 * 
 * POA_Download file from sent using SCP protocol
 * 
 */
public class G67SCPWithFileSep {

	int teststatus=0;
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G67SCPWithFileSep.class);
	String uploadedfilename = null;

	String filename;
	Map connectionmap, uplaodmap;
	String servername;
	String qcurl;
	String qcuname;
	String qcpwd;
	String domain;
	String project;
	String TLpath;
	String TSet;
	String runIdFile;
	List<String> lst;
	WriteTestResult wtr,testlog;
	String TID="";

	boolean constatus= false;
	boolean sizestatus = false;


	public static void main(String[] args) throws IOException, InterruptedException
	{
		G67SCPWithFileSep fg = new G67SCPWithFileSep();

		//fg.f( "G67SCPWithFileSep", "G67SCPWithFileSepUser","no", "21", "FTP", "G67SCPWithFileSepFile", "TESTFILE.txt", "", "POA", "", "", "G67SCPWithFileSepFile");
		fg.f( "G67SCPWithFileSep", "GK_User_04","no", "", "", "Mail_File", "TESTFILE.txt", "/inbox/", "POA", "", "", "Mail_File");
		//fg.f( "G67SCPWithFileSep", "MBXUSER","no", "", "", "Mail_File", "TESTFILE.txt", "/inbox/", "POA", "", "", "Mail_File$S$");

	}

	@Test
	@Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode","Basefile2"})
	public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String inputFileName, String physicalfile, String remotedirectory, 
			String action, String filetype, String filetransfermode,String expRmtFileName) throws IOException, InterruptedException{
		logger.info("G67SCPWithFileSep Execution Started");
		logger.info("Loading Properties");

		LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);
		String unixServerUrl=lp.readProperty("unixServerUrl");
		String unixId =lp.readProperty("unixId");
		String unixPwd =lp.readProperty("unixPwd");
		String ftpServer=lp.readProperty("server");

		String rPath1 = "/outbox/";		
		String rPath2 = "/sent/";

		LinuxBoxFileTransfer lbft = null;
		SCPClient scpc = null;


		try{
			lbft = new LinuxBoxFileTransfer();
			scpc = new SCPClient();

			boolean bootStatus = lbft.bootLinuxBox(unixServerUrl, 446, unixId, null, unixPwd);
			if(!bootStatus) throw new Exception("Unable to Boot linux box");

			String insertTime = lbft.getServerTime(); //scpc.getMSTTime();
			
			logger.info("Server time:"+insertTime);
			System.out.println("Server time:"+insertTime);

			if(! scpc.push(ftpServer, sftuser, FrameworkConstants.DefaultSFTPWD, remotedirectory, inputFileName)){
				throw new Exception("Unable to transfer file to "+ftpServer+" in SCP mode");
			}
			else{
				logger.info("SCP Push successfull");
				System.out.println("SCP Push successfull");
			}

			if(! lbft.sendCommand("ftp -inv "+ftpServer).contains("Connected to "+ftpServer)) 
				throw new Exception("Unable to connect to "+ftpServer);

			if(! lbft.sendCommand("user "+sftuser+" "+FrameworkConstants.DefaultSFTPWD).contains("230 User logged in")) 
				throw new Exception("Unable to login");
			
			lbft.sendCommand("cd "+rPath1);

			String output = lbft.sendCommand("ls -R");
			String temp = "";
			do{
				temp = lbft.getOutput();
				if(temp != null && !temp.isEmpty()) { System.out.println(temp); output+=temp;}
			}
			while(!temp.isEmpty());

			if(expRmtFileName == null || expRmtFileName.isEmpty()) expRmtFileName = inputFileName;
			
			String outputFileName = scpc.getFileNamefromOutput(output, expRmtFileName, insertTime);
			logger.info("SCP Push successfull with file: "+outputFileName);
			System.out.println("SCP Push successfull with file: "+outputFileName);

			lbft.sendCommand("bye");

			if(! scpc.pull(ftpServer, sftuser, FrameworkConstants.DefaultSFTPWD, rPath1, outputFileName)){
				throw new Exception("Unable to transfer file from "+ftpServer+" in SCP mode");
			}
			else{
				logger.info("SCP Pull1 successfull");
				System.out.println("SCP Pull1 successfull");
			}

			FileComparision fc =new FileComparision(LoggerFactory.getLogger(SCPClient.class));
			boolean contentVerificationvalue1 = false;

			try{
				logger.info("Verifying the content of "+inputFileName+" against "+outputFileName);
				System.out.println("Verifying the content of "+inputFileName+" against "+outputFileName);
				contentVerificationvalue1= fc.contentVerification(inputFileName,FrameworkConstants.DownloadDirectory+"/"+outputFileName+"_"+rPath1.replaceAll("/", ""));
				logger.info("contentVerificationvalue of "+rPath1+" :"+contentVerificationvalue1);
				System.out.println("contentVerificationvalue of "+rPath1+" :"+contentVerificationvalue1);

			}catch(Exception exc)
			{
				logger.info("Exception in file type verification is: "+exc.getStackTrace());
				System.out.println("Exception in file type verification is: ");
				exc.printStackTrace();
				throw exc;
			}

			if(! scpc.pull(ftpServer, sftuser, FrameworkConstants.DefaultSFTPWD, rPath2, outputFileName)){
				throw new Exception("Unable to transfer file from "+ftpServer+" in SCP mode");
			}
			else{
				logger.info("SCP Pull2 successfull");
				System.out.println("SCP Pull2 successfull");
			}

			boolean contentVerificationvalue2 = false;
			fc =new FileComparision(LoggerFactory.getLogger(SCPClient.class));
			try{
				logger.info("Verifying the content of "+inputFileName+" against "+outputFileName);
				System.out.println("Verifying the content of "+inputFileName+" against "+outputFileName);
				contentVerificationvalue2= fc.contentVerification(inputFileName,FrameworkConstants.DownloadDirectory+"/"+outputFileName+"_"+rPath2.replaceAll("/", ""));
				logger.info("contentVerificationvalue of "+rPath1+" :"+contentVerificationvalue2);
				System.out.println("contentVerificationvalue of "+rPath2+" :"+contentVerificationvalue2);

			}catch(Exception exc)
			{
				logger.info("Exception in file type verification is: "+exc.getStackTrace());
				System.out.println("Exception in file type verification is: ");
				exc.printStackTrace();
				throw exc;
			}

			if(contentVerificationvalue1 && contentVerificationvalue2){
				logger.info("G67SCPWithFileSep executed successfully");
				System.out.println("G67SCPWithFileSep executed successfully");
				teststatus = 1;

				if(outputFileName.indexOf("#") != -1 && outputFileName.split("#").length > 1){
					TID = outputFileName.split("#")[1];
				}
				else{
					TID = "No TID available";
				}

			}
			else{
				logger.info("G67SCPWithFileSep execution failed");
				System.out.println("G67SCPWithFileSep execution failed");
			}
		}
		catch(Exception e){
			teststatus=0;
			TID = e.getMessage();
			logger.info("Exception caught:"+e.getMessage());
			e.printStackTrace();
		}
		finally{
			lbft.destroy();
		}


		TestcaseLookup tl =new TestcaseLookup(logger);
		lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G67");
		LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
		runIdFile=(lp1.readProperty("RUNID"));
		wtr=new WriteTestResult();
		testlog=new WriteTestResult();

		boolean loggedResult = false;
		switch(almupdate)
		{
		case "No":
			if(teststatus==1)
			{
				for(int i=0;i<lst.size();i++)
				{
					if(lst.get(i) != null && lst.get(i).indexOf(action) != -1) {
						loggedResult = true;
						logger.info("Updating"+lst.get(i)+"status as Passed");
						wtr.writeToFile(runIdFile,"G67,"+ lst.get(i)+","+TID+",Passed");
					}
				}
			}else
			{
				for(int i=0;i<lst.size();i++)
				{
					if(lst.get(i) != null && lst.get(i).indexOf(action) != -1) {
						loggedResult = true;
						logger.info("Updating"+lst.get(i)+"status as Failed");
						wtr.writeToFile(runIdFile,"G67,"+ lst.get(i)+","+TID+",Failed");
					}
				}

			}
			break;
		case "no":
			if(teststatus==1)
			{
				for(int i=0;i<lst.size();i++)
				{
					if(lst.get(i) != null && lst.get(i).indexOf(action) != -1) {
						loggedResult = true;
						logger.info("Updating"+lst.get(i)+"status as Passed");
						wtr.writeToFile(runIdFile,"G67,"+ lst.get(i)+","+TID+",Passed");
					}
				}
			}else
			{
				for(int i=0;i<lst.size();i++)
				{
					if(lst.get(i) != null && lst.get(i).indexOf(action) != -1) {
						loggedResult = true;
						logger.info("Updating"+lst.get(i)+"status as Failed");
						wtr.writeToFile(runIdFile,"G67,"+ lst.get(i)+","+TID+",Failed");
					}
				}

			}
			break;
	/*	case "yes":
			updateALM();
			loggedResult = true;
			break;
		case "Yes":
			updateALM();
			loggedResult = true;
			break;*/
		}

		if(!loggedResult){
			System.out.println("Unable to update status for G67");
			logger.info("Unable to update status for G67");
		}
		
	}

	public void updateALM()
	{
		/*ALMConnect alm = new ALMConnect();
		boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
		if(qcstatus){
			if(teststatus==1){
				String strStatus="Passed";
				String filePath=FrameworkConstants.RunLog;
				String workdir=System.getProperty("user.dir");
				String fileName=workdir+"\\"+FrameworkConstants.RunLog;
				System.out.println("workdir"+workdir);
				for(int i=0;i<lst.size();i++)
				{
					logger.info("Updating"+lst.get(i)+"status as Passed");
					alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
					wtr.writeToFile(runIdFile,"G67,"+ lst.get(i)+","+TID+",Passed");
				}
			}else{
				String strStatus="Failed";
				String filePath=FrameworkConstants.RunLog;
				String workdir=System.getProperty("user.dir");
				String fileName=workdir+"\\"+FrameworkConstants.RunLog;
				System.out.println("workdir"+workdir);
				for(int i=0;i<lst.size();i++)
				{
					logger.info("Updating"+lst.get(i)+"status as Failed");
					alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
					wtr.writeToFile(runIdFile,"G67,"+ lst.get(i)+","+TID+",Failed");
				}
			}

		}else{
			System.out.println("Unable to login to ALM");
		}
*/

	}
}
