package amex.fs.sft;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import org.slf4j.LoggerFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.SFTP_Module;
import amex.fs.commons.TPUserLockCheck;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.WriteTestResult;

public class G324SFTPUserLockOut {
	boolean teststatus=false;
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G323FTPUserLockOut.class);
	 String uploadedfilename = null;
	 boolean TPcheck =true;

	  Map connectionmap, uplaodmap;
	  String servername,TPurl,TPuser,TPpwd;
	  String qcurl;
	  String qcuname;
	  String qcpwd;
	  String domain;
	  String project;
	  String TLpath;
	  String TSet;
	  String runIdFile;
	  List<String> lst;
	  WriteTestResult wtr,testlog;
	 boolean TMVerification_status = false;
	 String TID;
	 TPUserLockCheck track =new TPUserLockCheck();

	 public static void main(String[] args) throws Throwable{
		 G324SFTPUserLockOut fg = new G324SFTPUserLockOut();
		 //ZEROBYTEFILE.txt
		 fg.f("G324SFTPUserLockOut", "POD_SENTUSER", "no", "22", "SFTP", "G65SFTPLoginFile", "TESTFILE.txt", "/inbox", "UD", "ASCII", "PASSIVE",null);
		// fg.closeConnections();
	 }
	 
	 @Test
	 @Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode","Basefile2"})
	 public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, String remotedirectory, String action, String filetype, String filetransfermode,String basefilename2) throws Throwable{
		 try{ 
		 
		 logger.info("G324SFTPUserLockOut Execution Started");
		  logger.info("Loading Properties");
		  LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);
		  servername=lp.readProperty("server");
		  qcurl=lp.readProperty("almurl");
		  qcuname=lp.readProperty("almuser");
		  qcpwd=lp.readProperty("almpwd");
		  domain=lp.readProperty("almdomain");
		  project=lp.readProperty("almproject");
		  TLpath=lp.readProperty("almTLPath");
		  TSet=lp.readProperty("almTSet");
		  TPurl=lp.readProperty("tpurl");
		  TPpwd=lp.readProperty("tppwd");
		  TPuser=lp.readProperty("tpuser");
		  
		  int intport=Integer.parseInt(port);
		  
		  logger.info("servername : "+servername);
		  logger.info("almurl : "+qcurl);
		  logger.info("qcuname :"+qcuname);
		  logger.info("qcpwd :"+qcpwd);
		  logger.info("domain : "+domain);
		  logger.info("project : "+project);
		  logger.info("TLpath : "+TLpath );
		  logger.info("TSet : "+TSet);
		  logger.info("intport : "+intport);
		  
		  logger.info("Properties file loaded successfully");
		 
		 /* properties file loaded successfully
		  * 
		  */
		  SFTP_Module lg=new SFTP_Module(logger);
		  teststatus= track.trackingidverify(sftuser,TPurl,TPuser,TPpwd);
			 if (teststatus){
				 System.out.println(sftuser+" is already locked in TP.\n Please unlock the user in TP");
				 TID="Account already locked";
				 teststatus =false;
			 } else{
		  connectionmap= lg.logintoSFT(servername, intport, sftuser,"amex",null,FrameworkConstants.AcceptHostKey);
		  connectionmap= lg.logintoSFT(servername, intport, sftuser,"amex",null,FrameworkConstants.AcceptHostKey);
		  connectionmap= lg.logintoSFT(servername, intport, sftuser,"amex",null,FrameworkConstants.AcceptHostKey);
		  //System.out.println("First message: " +connectionmap.get("Message"));
		
          
          System.out.println("TP checking started...");
			teststatus= track.trackingidverify(sftuser,TPurl,TPuser,TPpwd);
			System.out.println("testcase  is"+ teststatus);
			logger.info("testcase is "+teststatus);
			//teststatus=true;
			if (teststatus){
				TID="User Account Locked after 3 attempts in TP";
				System.out.println("User Account Locked after 3 attempts in TP");
				logger.info("User Account Locked after 3 attempts in TP");
			}else
			{   System.out.println("User Account Not Locked after 3 attempts in TP");
				TID="User Account Not Locked after 3 attempts in TP";
				logger.info("User Account Not Locked after 3 attempts in TP");
			}
		  
	 }
			 TestcaseLookup tl =new TestcaseLookup(logger);
				// Identifying the testcase to be updated in the ALM based on the group number
				 
				 
				lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G324");
				
				  LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
				  runIdFile=(lp1.readProperty("RUNID"));
				  wtr=new WriteTestResult();
				  testlog=new WriteTestResult();
				  
				  switch(almupdate)
				  {
				  case "No":
					  if(teststatus)
					  {
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Passed");
						  wtr.writeToFile(runIdFile,"G324,"+ lst.get(i)+","+TID+",Passed");
					  }
					  }else
					  {
						  for(int i=0;i<lst.size();i++)
						  {
							  logger.info("Updating"+lst.get(i)+"status as Failed");
							  wtr.writeToFile(runIdFile,"G324,"+ lst.get(i)+","+TID+",Failed");
						  }
						  
					  }
					  break;
				  case "no":
					  if(teststatus)
					  {
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Passed");
						  wtr.writeToFile(runIdFile,"G324,"+ lst.get(i)+","+TID+",Passed");
					  }
					  }else
					  {
						  for(int i=0;i<lst.size();i++)
						  {
							  logger.info("Updating"+lst.get(i)+"status as Failed");
							  wtr.writeToFile(runIdFile,"G324,"+ lst.get(i)+","+TID+",Failed");
						  }
						  
					  }
					  break;
				  case "yes":
					  updateALM();
					  break;
				  case "Yes":
					  updateALM();
					  break;
				  }
				
				
				/*logging off from the SFT server
				 * 
				 */

				logger.info("G324SFTPUserLockOut Execution completed");
				System.out.println("G324SFTPUserLockOut Execution completed");

				
					}
				 catch(NullPointerException e1)
			        {   e1.printStackTrace();
			        	logger.info("unable to proceed:\t"+e1);
			        	TMVerification_status=false;
			        	
			        }
					catch (Throwable e3) {
						
						e3.printStackTrace();
			        	logger.info("unable to proceed:\t"+e3);
			        	TMVerification_status=false;

					}
				}

public void updateALM()
{
	  /*ALMConnect alm = new ALMConnect();
	  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
	  if(qcstatus){
		  if(teststatus){
			  String strStatus="Passed";
			  String filePath=FrameworkConstants.RunLog;
			  String workdir=System.getProperty("user.dir");
	          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
	          System.out.println("workdir"+workdir);
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
				  wtr.writeToFile(runIdFile,"G324,"+ lst.get(i)+","+TID+",Passed");
			  }
		  }else{
				  String strStatus="Failed";
				  String filePath=FrameworkConstants.RunLog;
				  String workdir=System.getProperty("user.dir");
		          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
		          System.out.println("workdir"+workdir);
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
					  wtr.writeToFile(runIdFile,"G324,"+ lst.get(i)+","+TID+",Failed");
				  }
			  }
			  
		  }else{
		  System.out.println("Unable to login to ALM");
		  }*/


}	


	 }
	 
