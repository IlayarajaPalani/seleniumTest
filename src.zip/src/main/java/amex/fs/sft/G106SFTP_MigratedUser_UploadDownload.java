package amex.fs.sft;

/*Description:
 * project: NGP Automation.
 * author: Viren Tiwari
 * This program is to test TEXT file upload and validate the downloaded file for content verification.
 * A TEXT file will be uploaded to SFT server and the content of the file is verified by downloading file at the outbox folder.
 */


import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


import amex.fs.commons.CompareExcel;
import amex.fs.commons.Download;
import amex.fs.commons.FileComparision;
import amex.fs.commons.FileSizeCheck;
import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.Login;
import amex.fs.commons.Logoff;
import amex.fs.commons.SFTP_Module;
import amex.fs.commons.Sentinels;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.Upload;
import amex.fs.commons.WriteTestResult;

public class G106SFTP_MigratedUser_UploadDownload
{
	int teststatus=0;
	  Map connectionmap, uplaodmap;
	  String servername;
	  String qcurl;
	  String qcuname;
	  String qcpwd;
	  String domain;
	  String project;
	  String TLpath;
	  String TSet;
	  String runIdFile;
	  List<String> lst;
	  WriteTestResult wtr,testlog;
	  String TID;
	  
	  Logoff lg = null;
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G106SFTP_MigratedUser_UploadDownload.class);
	 String uploadedfilename = null;
	
	 public static void main(String[] args) throws IOException, ParseException, InterruptedException{
		 G106SFTPSRCDESMigratedModified fg = new G106SFTPSRCDESMigratedModified();
		 //String PvtKey,String acceptHostKey
		 fg.f("G106SFTP_MigratedUser_UploadDownload", "G106SFTP_MigratedUser_UploadDownload", "no", "22", "SFTP", "G106SFTP_MigratedUser_UploadDownloadFile", "TESTFILE.txt", "/inbox", "UD", "BINARY", "PASSIVE",null);
		// fg.closeConnections();
	 }
	 /* Main method which takes the parameter from the testng.xml
	  * 
	  */
	 
	 @Test
	 @Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode","Basefile2"})
	 public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, String remotedirectory, String action, String filetype, String filetransfermode,String basefilename2) throws IOException, InterruptedException, ParseException{
		  logger.info("G106SFTPSRCDESMigratedModified Execution Started");
          logger.info("Loading Properties for ALM and SFT");
          LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);
		  String servername=lp.readProperty("server");
		  String remoteserver = lp.readProperty("remoteserver");
		  String nonmigrateduser = lp.readProperty("nonmigrateduser");
		  String qcurl=lp.readProperty("almurl");
		  String qcuname=lp.readProperty("almuser");
		  String qcpwd=lp.readProperty("almpwd");
		  String domain=lp.readProperty("almdomain");
		  String project=lp.readProperty("almproject");
		  String TLpath=lp.readProperty("almTLPath");
		  String TSet=lp.readProperty("almTSet");
		  int intport=Integer.parseInt(port);
		  Map dwnld = new HashMap();
		  boolean constatus= false;
		  boolean sizestatus = false;
		  SFTP_Module lg=new SFTP_Module(logger);
		  //Download downloadmap = new Download(logger);
		
		  /* Loading Properties for ALM and SFT details
		   * 
		   */
		 
		  logger.info("servername : "+servername);
		  logger.info("almurl : "+qcurl);
		  logger.info("qcuname :"+qcuname);
		  logger.info("domain : "+domain);
		  logger.info("project : "+project);
		  logger.info("TLpath : "+TLpath );
		  logger.info("TSet : "+TSet);
		  logger.info("intport : "+intport);
		  
		  logger.info("Properties file loaded successfully");
			 
			 /* properties file loaded successfully
			  * 
			  */
		  
		  
		  /* Login to SFT server using SFTP protocol and checking the connection status
		   * 
		   */
		  connectionmap= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD,null,FrameworkConstants.AcceptHostKey);
		  if((boolean) connectionmap.get("result")){
			  logger.info(sftuser+" logged into "+servername+" successfully ");
			  /* Uploading the file to SFT once the above connection is successful
				 * 
				 */
			  logger.info("Uploading the file to SFT once the above connection is successful");
			  uplaodmap = lg.uploadFile(connectionmap, physicalfile, basefilename, remotedirectory);
			  uploadedfilename = (String) uplaodmap.get("Filename");
			  if((boolean) uplaodmap.get("Status")){
				 // String sentvalue = sent.sentinelCheck("SHORT_DATE");
				 // uploadedfilename = basefilename+"#"+sentvalue;
				  System.out.println("File name is:"+uploadedfilename);
				  logger.info(sftuser+" uploaded "+uploadedfilename+" successfully ");
				  System.out.println(sftuser+" uploaded "+uploadedfilename+" successfully ");
				  /*Downloading file from user outbox or sent based on parameter action from tesng.xml
					UD --> download the file from outbox directory
					UDD --> download the file sent directory
					*/
				 // switch(action)
				 // {
				 // case "UD" :
					  lg.logofffromSFT(connectionmap);
					  logger.info("Login to the non migrated user to download the file");
					     System.out.println("Login to the non migrated user to download the file");
				
						connectionmap= lg.logintoSFT(servername, intport, nonmigrateduser, FrameworkConstants.DefaultSFTPWD,null,FrameworkConstants.AcceptHostKey);
						  Thread.sleep(FrameworkConstants.SleepValue);

						 /* if((boolean) uplaodmap.get("uploadstatus")){
							  uploadedfilename = (String) uplaodmap.get("Filename");
							  logger.info(sftuser+" uploaded "+uploadedfilename+" successfully ");
							  System.out.println(sftuser+" uploaded "+uploadedfilename+" successfully");
							  
							  lg.logofffromSFT(connectionmap);
							  logger.info("Login to the non migrated user to download the file");
							     System.out.println("Login to the non migrated user to download the file");*/
						
								  Thread.sleep(FrameworkConstants.SleepValue);

									dwnld= lg.downloadFile(connectionmap, uploadedfilename, FrameworkConstants.DownloadDirectory+""+uploadedfilename, FrameworkConstants.RemoteOutbox);
					  				if((boolean) dwnld.get("Status"))
					  				{
					  					logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Downloaded Successfully");
					  					System.out.println(FrameworkConstants.DownloadDirectory+uploadedfilename+" Downloaded Successfully");
					  					teststatus=1;
					  				}else
					  				{
					  					logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Download Failed");
					  					System.out.println("Failed to download..");
					  					teststatus=0;
					  				}
					  			  
								   
				  
				  /* Validation comparing the downloaded file from the outbox with the uploaded physical file for filesize and file content
					 * 
					 */
				FileComparision fc = new FileComparision(logger);
				constatus = fc.contentVerification(physicalfile, FrameworkConstants.DownloadDirectory+"/"+uploadedfilename);
				logger.info("File comparision status:"+constatus);
				System.out.println("File comparision status:"+constatus);
				FileSizeCheck fs = new FileSizeCheck(logger);
				sizestatus = fs.fileSizeVerification(physicalfile, FrameworkConstants.DownloadDirectory+"/"+uploadedfilename);
				logger.info("File size verification status:"+sizestatus);
				System.out.println("File size verification status:"+sizestatus);
				if(constatus&&sizestatus){
					teststatus=1;
					}else{
						teststatus=0;
						 }
			TID=(String) uplaodmap.get("TID");	
			  }
			  else{
				  teststatus=0;
				  logger.info(sftuser+" failed to upload "+basefilename);
				  System.out.println(sftuser+" failed to upload "+basefilename);
				  TID="Upload Failed";
			  }
		  }else{
			  logger.info(sftuser+" unable to login to "+servername);
			  System.out.println(sftuser+" unable to login to "+servername);
			  teststatus=0;
			  TID="Login Failed";
			  
		  }
		  /* Identifying the testcase to be updated in the ALM based on the group number
		   * 
		   */
		 System.out.println(teststatus);
		  System.out.println("The QC upload is started");
		   logger.info("The QC upload is started");
		  TestcaseLookup tl =new TestcaseLookup(logger);
		  //String groupname = tcname.substring(0, 2);
		  lst = tl.lookupTestcase(FrameworkConstants.TCLookup,"G106");
		  
		  LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
		  runIdFile=(lp1.readProperty("RUNID"));
		  wtr=new WriteTestResult();
		  testlog=new WriteTestResult();
		  
		  switch(almupdate)
		  {
		  case "No":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G106,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G106,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "no":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G106,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G106,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "yes":
			  updateALM();
			  break;
		  case "Yes":
			  updateALM();
			  break;
		  }

		  
		  //ALM upload completed 
		  /*logging off from the SFT server
		   * 
		   */
		  
		  logger.info("G106SFTP_MigratedUser_UploadDownload Execution completed");
		  System.out.println("G106SFTP_MigratedUser_UploadDownload Execution completed");
		  if(teststatus==1){
		  lg.logofffromSFT(connectionmap);
		  
		  }
		  }
 

	 public void updateALM()
	 {
		  /*ALMConnect alm = new ALMConnect();
		  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
		  if(qcstatus){
			  if(teststatus==1){
				  String strStatus="Passed";
				  String filePath=FrameworkConstants.RunLog;
				  String workdir=System.getProperty("user.dir");
		          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
		          System.out.println("workdir"+workdir);
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Passed");
					  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
					  wtr.writeToFile(runIdFile,"G106,"+ lst.get(i)+","+TID+",Passed");
				  }
			  }else{
					  String strStatus="Failed";
					  String filePath=FrameworkConstants.RunLog;
					  String workdir=System.getProperty("user.dir");
			          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
			          System.out.println("workdir"+workdir);
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Failed");
						  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						  wtr.writeToFile(runIdFile,"G106,"+ lst.get(i)+","+TID+",Failed");
					  }
				  }
				  
			  }else{
			  System.out.println("Unable to login to ALM");
			  }
*/
	 
	 }	 
}

