
package amex.fs.sft;

import java.io.IOException;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


import amex.fs.commons.Download;
import amex.fs.commons.FileComparision;
import amex.fs.commons.FileSizeCheck;
import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.Login;
import amex.fs.commons.Logoff;
import amex.fs.commons.Sentinels;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.Upload;
import amex.fs.commons.WriteTestResult;

public class G325FtpList30Files
 {
	int teststatus=0;
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G325FtpList30Files.class);
	 String uploadedfilename = null;
	  Map connectionmap, uplaodmap;
	  String servername;
	  String qcurl;
	  String qcuname;
	  String qcpwd;
	  String domain;
	  String project;
	  String TLpath;
	  String TSet;
	  String runIdFile;
	  List<String> lst;
	  WriteTestResult wtr,testlog;
	  FTPClient ftpclient = null;
	  String TID;
	
	 
		 Sentinels sent = new Sentinels();
		 public static void main(String[] args) throws IOException, ParseException, InterruptedException{
			 G325FtpList30Files fg = new G325FtpList30Files();
			 fg.f("G325FtpList30Files", "MAILUSER2", "No", "21", "FTP", "Mail_File", "TESTFILE.txt", "/inbox", "UD", "ASCII", "PASSIVE");
			// fg.closeConnections();
		 }
	  
	 @Test
	 @Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode"})
	 public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, String remotedirectory, String action, String filetype, String filetransfermode) throws IOException, InterruptedException{
		  logger.info("G325FtpList30Files Execution Started");
		  logger.info("Loading Properties");
		  LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);
		  servername=lp.readProperty("server");
		  qcurl=lp.readProperty("almurl");
		  qcuname=lp.readProperty("almuser");
		  qcpwd=lp.readProperty("almpwd");
		  domain=lp.readProperty("almdomain");
		  project=lp.readProperty("almproject");
		  TLpath=lp.readProperty("almTLPath");
		  TSet=lp.readProperty("almTSet");
		  int intport=Integer.parseInt(port);
		  Map dwnld = new HashMap();
		  boolean constatus= false;
		  boolean sizestatus = false;
		  Login lg=new Login(logger);
		  
		  //Login to SFT
		  connectionmap= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD, protocol);
		  if((boolean) connectionmap.get("loginstatus")){
			  logger.info(sftuser+" logged into "+servername+" successfully ");
			  Upload up=new Upload(logger);
			  
			  
		  //  upload 30 files
			  for(int i=0;i<3;i++)
			  {
			  uplaodmap = up.uploadFile(connectionmap, basefilename, physicalfile, remotedirectory, filetype, filetransfermode);
			  if((boolean) uplaodmap.get("uploadstatus")){
				  uploadedfilename = (String) uplaodmap.get("Filename");
				  logger.info(sftuser+" uploaded "+uploadedfilename+" successfully ");
			  
				  
				 
				
				  
				TID=(String) uplaodmap.get("TID");
					 }
			   else{
				  teststatus=0;
				  logger.info(sftuser+" failed to upload "+basefilename);
				  TID="Upload Failed";
			   }
			  }
			  
			  
			 // Getting the time in seconds before listing the outbox
			  
			  
			  logger.info("Getting the time beforen listing ");
			  LocalDateTime datetime= LocalDateTime.now();
			  String datetimestring=datetime.toString();
			  System.out.println(" LocalDateTime : "+datetime);
			  
			  String timevalue[]=datetimestring.split(":");
			  String second=timevalue[2];
			  System.out.println("second : "+second);
			  String secondvalue[]=second.split("\\.");
			  String reqsecond=secondvalue[0];
			  System.out.println("reqsecond : "+reqsecond);
			  
			//listing of file in outbox
			  
			  ftpclient= (FTPClient) connectionmap.get("connection");
			  System.out.println(" The remote directory is : "+remotedirectory );
			  ftpclient.changeWorkingDirectory(remotedirectory);
			  
			  
			  logger.info("The listing begins");
			  FTPFile[] listfiles=ftpclient.listFiles();
			  int lenlistfiles =listfiles.length;
			  System.out.println("The no of files in the out box : "+lenlistfiles);
			  for( FTPFile listfiles1:listfiles)
			  {
				  System.out.println("The outbox files are: ");
				  System.out.println(listfiles1.getName());
			  }
			  
			  
			// Getting the time in seconds after listing the outbox
			  
			  
			  logger.info("Getting the time after listing ");
			  
			  LocalDateTime datetime1= LocalDateTime.now();
			  String datetimestring1=datetime.toString();
			  System.out.println(" LocalDateTime : "+datetime1);
			  
			  String timevalue1[]=datetimestring1.split(":");
			  String second1=timevalue1[2];
			  System.out.println("second1 : "+second1);
			  String secondvalue1[]=second.split("\\.");
			  String reqsecond1=secondvalue[0];
			  System.out.println("reqsecond1 : "+reqsecond1);
			  int timing=Integer.parseInt(reqsecond);
			  int timing1=Integer.parseInt(reqsecond1);
			  
			  //get the time gap
			  logger.info("Checking the the time difference ");
			  int totallisttime;
			  if(timing<timing1)
			  {
				  totallisttime= timing1-timing;
			  }else{
				  totallisttime= timing-timing1;
			  }
			  
			  // teststatus based on time gap
			  
			  System.out.println("totallisttime : "+totallisttime);
			  if(totallisttime<30)
			  {
				  System.out.println("Test case is pass ");
				  logger.info("Test case is pass ");
				  teststatus=1;
				  
			  }
			  else{
				  System.out.println("Test case is fail ");
				  teststatus=0;
				  logger.info("Test case is fail ");
			  }
			  
			  
		  }else{
			  logger.info(sftuser+" unable to login to "+servername);
			  teststatus=0;
			  TID="Login Failed";
		  }
		  
		  
		  TestcaseLookup tl =new TestcaseLookup(logger);
		  //String groupname = tcname.substring(0, 2);
		  lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G325");
		  
		  LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
		  runIdFile=(lp1.readProperty("RUNID"));
		  System.out.println(" runIdFile "+runIdFile);
		  wtr=new WriteTestResult();
		  testlog=new WriteTestResult();
		  
		  switch(almupdate)
		  {
		  case "No":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  System.out.println("TID  .."+TID);
				  wtr.writeToFile(runIdFile,"G325,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G325,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "no":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G325,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G325,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "yes":
			  updateALM();
			  break;
		  case "Yes":
			  updateALM();
			  break;
		  }

		  
		  Logoff logoff = new Logoff(logger);
		  if(teststatus==1){
		  logoff.logofffromSFT(connectionmap);}
		  logger.info("G325FtpList30Files Execution completed");
	 }
	 
	 public void updateALM()
	 {
		  /*ALMConnect alm = new ALMConnect();
		  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
		  if(qcstatus){
			  if(teststatus==1){
				  String strStatus="Passed";
				  String filePath=FrameworkConstants.RunLog;
				  String workdir=System.getProperty("user.dir");
		          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
		          System.out.println("workdir"+workdir);
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Passed");
					  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
					  wtr.writeToFile(runIdFile,"G325,"+ lst.get(i)+","+TID+",Passed");
				  }
			  }else{
					  String strStatus="Failed";
					  String filePath=FrameworkConstants.RunLog;
					  String workdir=System.getProperty("user.dir");
			          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
			          System.out.println("workdir"+workdir);
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Failed");
						  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						  wtr.writeToFile(runIdFile,"G325,"+ lst.get(i)+","+TID+",Failed");
					  }
				  }
				  
			  }else{
			  System.out.println("Unable to login to ALM");
			  }
*/
	 
	 }	
	 
 }
	 
		  


