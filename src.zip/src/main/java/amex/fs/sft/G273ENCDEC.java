package amex.fs.sft;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.LoggerFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


import amex.fs.commons.Download;
import amex.fs.commons.FileComparision;
import amex.fs.commons.FileSizeCheck;
import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.Login;
import amex.fs.commons.Logoff;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.Upload;
import amex.fs.commons.WriteTestResult;

/*
 * Encryption using KeyPair_1K strength with signature (Key algorithm_cipher AES_128 hashing  SHA512 and signature algorithm_cipher AES_256 and hashing  MD5) using SFT
 *
 * Decryption using KeyPair_1K strength with signature (Key algorithm_cipher AES_128 hashing  SHA512 and signature algorithm_cipher AES_256 and hashing  MD5) using Bouncy Castle algorithm
 */
public class G273ENCDEC {

	int teststatus=0;
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G273ENCDEC.class);
	String uploadedfilename = null;

	String filename;
	Map connectionmap, uplaodmap;
	String servername;
	String qcurl;
	String qcuname;
	String qcpwd;
	String domain;
	String project;
	String TLpath;
	String TSet;
	String runIdFile;
	List<String> lst;
	WriteTestResult wtr,testlog;
	String TID;

	boolean constatus= false;
	boolean sizestatus = false;


	public static void main(String[] args) throws IOException, InterruptedException
	{
		G273ENCDEC fg = new G273ENCDEC();

		fg.f( "G273ENCDEC", "GK_User_04","no", "21", "FTP", "GK_ENC_273", "TESTFILE.txt", "/inbox","", "BINARY", "PASSIVE","GK_DEC_273");

	}

	@Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode","Basefile2"})
	@Test
	public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, String remotedirectory,String Action, String filetype, String filetransfermode ,String basefilename2) throws IOException, InterruptedException{

		logger.info("G273ENCDEC Execution Started");
		logger.info("Loading Properties");

		LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);
		servername=lp.readProperty("server");
		qcurl=lp.readProperty("almurl");
		qcuname=lp.readProperty("almuser");
		qcpwd=lp.readProperty("almpwd");
		domain=lp.readProperty("almdomain");
		project=lp.readProperty("almproject");
		TLpath=lp.readProperty("almTLPath");
		TSet=lp.readProperty("almTSet");
		int intport=Integer.parseInt(port);
		uplaodmap = new HashMap();
		Map dwnld = new HashMap();

		try{
			Login lg=new Login(logger); 

			connectionmap= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD, protocol);
			if((boolean) connectionmap.get("loginstatus")){
				logger.info(sftuser+" logged into "+servername+" successfully ");
				Upload up=new Upload(logger);
				uplaodmap = up.uploadFile(connectionmap, basefilename, physicalfile, remotedirectory, filetype, filetransfermode);
				uploadedfilename = (String) uplaodmap.get("Filename");
				if((boolean) uplaodmap.get("uploadstatus"))
				{
					logger.info(sftuser+" uploaded "+uploadedfilename+" successfully "); //check weather the file is uploaded or not
					Thread.sleep(FrameworkConstants.SleepValue);
					System.out.println("download");
					Download downloadmap = new Download(logger);//create a download object.
					dwnld= downloadmap.downloadFile(connectionmap, uploadedfilename, FrameworkConstants.DownloadDirectory+""+uploadedfilename, FrameworkConstants.RemoteOutbox, filetype, filetransfermode);
					filename=FrameworkConstants.DownloadDirectory+""+uploadedfilename;//getting encrypted file name
					if((boolean) dwnld.get("downloadstatus"))
					{
						logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Downloaded Successfully");
						Logoff loff=new Logoff(logger);
						loff.logofffromSFT(connectionmap);
						connectionmap= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD, protocol);
						if((boolean) connectionmap.get("loginstatus")){
							uplaodmap = up.uploadFile(connectionmap, basefilename2, filename, remotedirectory, filetype, filetransfermode);
							if((boolean) uplaodmap.get("uploadstatus"))
							{
								uploadedfilename = (String) uplaodmap.get("Filename");
								logger.info(sftuser+" uploaded "+uploadedfilename+" successfully "); //check weather the file is uploaded or not
								Thread.sleep(FrameworkConstants.SleepValue);
								dwnld= downloadmap.downloadFile(connectionmap, uploadedfilename, FrameworkConstants.DownloadDirectory+""+uploadedfilename, FrameworkConstants.RemoteOutbox, filetype, filetransfermode);
								if((boolean) dwnld.get("downloadstatus"))
								{
									logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Downloaded Successfully");
									String temp=FrameworkConstants.DownloadDirectory+uploadedfilename;
									FileComparision fc = new FileComparision(logger);
									constatus = fc.contentVerification(physicalfile, temp);
									logger.info("File comparison status:"+constatus);
									FileSizeCheck fs = new FileSizeCheck(logger);
									sizestatus = fs.fileSizeVerification(physicalfile, temp);
									logger.info("File size verification status:"+sizestatus);
									System.out.println(sizestatus+""+constatus);
									if(constatus&&sizestatus){
										teststatus=1;

										System.out.println("the file before Encrytion and file after decryption are same");
										logger.info("the file before Encrytion and file after decryption are same");
									}else{
										teststatus=0;
										System.out.println("the file before Encrytion and file afterEncrytion are different");
										logger.info("the file before Encrytion and file afterEncrytion are different");
									}
								}
								else{
									teststatus=0;
									logger.info("unable to download Encrypted file");
									System.out.println("unable to download encrypted file");
								}




							}}
						else{teststatus=0;

						logger.info("unable to upload file");

						}}

					else{
						teststatus=0; // if different

						logger.info("unable to download");
						System.out.println("unable to download");
					}

				}
				else{teststatus=0; // if different

				logger.info("unable to upload file");
				TID="Upload Failed";

				}
				TID=(String)uplaodmap.get("TID");
			}
			else{
				teststatus=0; // if different

				System.out.println("unable to login");
				logger.info("unable to login");
				teststatus=0;
				TID="Login Failed";
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}


		TestcaseLookup tl =new TestcaseLookup(logger);
		/* Identifying the testcase to be updated in the ALM based on the group number
		 * 
		 */ 
		lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G273");
		LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
		runIdFile=(lp1.readProperty("RUNID"));
		wtr=new WriteTestResult();
		testlog=new WriteTestResult();

		switch(almupdate)
		{
		case "No":
			if(teststatus==1)
			{
				for(int i=0;i<lst.size();i++)
				{
					logger.info("Updating"+lst.get(i)+"status as Passed");
					wtr.writeToFile(runIdFile,"G273,"+ lst.get(i)+","+TID+",Passed");
				}
			}else
			{
				for(int i=0;i<lst.size();i++)
				{
					logger.info("Updating"+lst.get(i)+"status as Failed");
					wtr.writeToFile(runIdFile,"G273,"+ lst.get(i)+","+TID+",Failed");
				}

			}
			break;
		case "no":
			if(teststatus==1)
			{
				for(int i=0;i<lst.size();i++)
				{
					logger.info("Updating"+lst.get(i)+"status as Passed");
					wtr.writeToFile(runIdFile,"G273,"+ lst.get(i)+","+TID+",Passed");
				}
			}else
			{
				for(int i=0;i<lst.size();i++)
				{
					logger.info("Updating"+lst.get(i)+"status as Failed");
					wtr.writeToFile(runIdFile,"G273,"+ lst.get(i)+","+TID+",Failed");
				}

			}
			break;
	/*	case "yes":
			updateALM();
			break;
		case "Yes":
			updateALM();
			break;*/
		}

		logger.info("G273ENCDEC Execution completed");
		System.out.println("G273ENCDEC Execution completed");
		if(teststatus==1)
		{
			Logoff loff=new Logoff(logger);
			loff.logofffromSFT(connectionmap);
		}
	}

	public void updateALM()
	{
		/*ALMConnect alm = new ALMConnect();
		boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
		if(qcstatus){
			if(teststatus==1){
				String strStatus="Passed";
				String filePath=FrameworkConstants.RunLog;
				String workdir=System.getProperty("user.dir");
				String fileName=workdir+"\\"+FrameworkConstants.RunLog;
				System.out.println("workdir"+workdir);
				for(int i=0;i<lst.size();i++)
				{
					logger.info("Updating"+lst.get(i)+"status as Passed");
					alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
					wtr.writeToFile(runIdFile,"G273,"+ lst.get(i)+","+TID+",Passed");
				}
			}else{
				String strStatus="Failed";
				String filePath=FrameworkConstants.RunLog;
				String workdir=System.getProperty("user.dir");
				String fileName=workdir+"\\"+FrameworkConstants.RunLog;
				System.out.println("workdir"+workdir);
				for(int i=0;i<lst.size();i++)
				{
					logger.info("Updating"+lst.get(i)+"status as Failed");
					alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
					wtr.writeToFile(runIdFile,"G273,"+ lst.get(i)+","+TID+",Failed");
				}
			}

		}else{
			System.out.println("Unable to login to ALM");
		}

*/
	}
}
