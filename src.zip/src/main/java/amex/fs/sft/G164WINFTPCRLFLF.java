package amex.fs.sft;



	import java.io.IOException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.LoggerFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import amex.fs.commons.AsciiFileComparison;
import amex.fs.commons.Download;
import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.Login;
import amex.fs.commons.Logoff;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.Upload;
import amex.fs.commons.WriteTestResult;


/**
 * @author KG5007455
 *
 * This test case is to Upload a file in ASCII mode, Download in Binary
 * on FTP Protocol
 * from Windows OS
 * with file type CRLF
 */

	public class G164WINFTPCRLFLF{
	 
		int teststatus=0;
		public static org.slf4j.Logger logger = LoggerFactory.getLogger(G164WINFTPCRLFLF.class);
		 String uploadedfilename = null;
		  Map connectionmap, uploadmap;
		  String servername;
		  String qcurl;
		  String qcuname;
		  String qcpwd;
		  String domain;
		  String project;
		  String TLpath;
		  String TSet;
		  String runIdFile;
		  List<String> lst;
		  WriteTestResult wtr,testlog;
		  boolean contentVerificationvalue;
		  String TID=null;
		  
		  
		  public static void main(String[] args) throws IOException, ParseException, InterruptedException{
			  G164WINFTPCRLFLF fg = new G164WINFTPCRLFLF();
				 fg.f("G164WINFTPCRLFLF", "SFTPzerofileuser", "no", "21", "FTP", "SFTPfilezero", "HTTPSE2FILE01.txt", "/inbox", "UD","ASCII", "Binary","PASSIVE");
				
			 }
		  
		 @Test
		 @Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTypeDown","FileTransferMode"})
		 public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, String remotedirectory, String action, String filetypeup, String filetypedown,String filetransfermode) throws IOException, InterruptedException{
			  logger.info("G164WINFTPCRLFLF Execution Started");
			  logger.info("Loading Properties");
			  LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);
			  servername=lp.readProperty("server");
			  qcurl=lp.readProperty("almurl");
			  qcuname=lp.readProperty("almuser");
			  qcpwd=lp.readProperty("almpwd");
			  domain=lp.readProperty("almdomain");
			  project=lp.readProperty("almproject");
			  TLpath=lp.readProperty("almTLPath");
			  TSet=lp.readProperty("almTSet");
			  //BasicConfigurator.configure();
			  int intport=Integer.parseInt(port);
			  Map dwnld = new HashMap();

			  /*Login to the application*/
			  Login lg=new Login(logger);
			  connectionmap= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD, protocol);
			  if((boolean) connectionmap.get("loginstatus")){
				  logger.info(sftuser+" logged into "+servername+" successfully ");
				  /*uploading a file*/
				  Upload up=new Upload(logger);
				  uploadmap = up.uploadFile(connectionmap, basefilename, physicalfile, remotedirectory, filetypeup, filetransfermode);
				  if((boolean) uploadmap.get("uploadstatus")){
					  uploadedfilename = (String) uploadmap.get("Filename");
					  logger.info(sftuser+" uploaded "+uploadedfilename+" successfully ");
					  
					  /*Downloading a file*/
					  Download downloadmap = new Download(logger);
					  switch(action)
					  {
					  case "UD" :
						  Thread.sleep(FrameworkConstants.SleepValue);
						
			  				dwnld= downloadmap.downloadFile(connectionmap, uploadedfilename, FrameworkConstants.DownloadDirectory+""+uploadedfilename, FrameworkConstants.RemoteOutbox, filetypedown, filetransfermode);
			  				if((boolean) dwnld.get("downloadstatus"))
			  				{
			  					logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Downloaded Successfully");
			  				}else
			  				{
			  					logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Download Failed");
			  				}
			  				break;
			  	
					  case "UDD"  :
						  Thread.sleep(FrameworkConstants.SleepValue);
	 						dwnld= downloadmap.downloadFile(connectionmap, uploadedfilename, FrameworkConstants.DownloadDirectory+""+uploadedfilename, FrameworkConstants.RemoteOutbox, filetypedown, filetransfermode);
	 						
	 						if((boolean) dwnld.get("downloadstatus"))
							{
								logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Downloaded Successfully from Outbox");
								Thread.sleep(FrameworkConstants.SleepValue);
		 						dwnld= downloadmap.downloadFile(connectionmap, uploadedfilename, FrameworkConstants.DownloadDirectory+""+uploadedfilename, FrameworkConstants.RemoteSent, filetypedown, filetransfermode);
		 						if((boolean) dwnld.get("downloadstatus"))
								{
									logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Downloaded Successfully from Sent");
								}else
								{
									logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Download Failed from Sent");
								} 
							}else
							{
								logger.info(FrameworkConstants.DownloadDirectory+uploadedfilename+" Download Failed from Outbox");
							} 
	 						break;
			  				
			  		default:
			  			 	teststatus=0;
			  				break;
				  }
					
					  
			//File type comparison for uploaded and downloaded file
					  
					  AsciiFileComparison fc =new AsciiFileComparison();
					  try{
						  logger.info("verifying the content of "+physicalfile+" against "+uploadedfilename);
						  contentVerificationvalue= fc.contentVerification(physicalfile, FrameworkConstants.WinEOL,FrameworkConstants.DownloadDirectory+"/"+uploadedfilename, FrameworkConstants.UnixEOL);
					  }catch(Exception exc)
					  {
						  System.out.println("Exception in file type verification is: ");
						  exc.printStackTrace();
					  }
					  if(contentVerificationvalue)
					  {
						  teststatus=1;
						  logger.info("The filetype verification status is true");
						  System.out.println("contentVerificationvalue is : "+contentVerificationvalue);
						  System.out.println("The filetype verification is true");
					  }
					  else
					  {
						  teststatus=0;
						  logger.info("The filetype verification status is false");
						  System.out.println("contentVerificationvalue is : "+contentVerificationvalue);
						  System.out.println("The filetype verification is false");
					  }
					  TID=(String) uploadmap.get("TID");
					  }
			   else{
					  teststatus=0;
					  logger.info(sftuser+" failed to upload "+basefilename);
					  TID="Upload Failed";
				  }
			  }else{
				  logger.info(sftuser+" unable to login to "+servername);
				  TID="Login Failed";
				  teststatus=0;
			  }
			  
			  TestcaseLookup tl =new TestcaseLookup(logger);
			  lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G164");
			  //System.out.println(lst);
			  LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
			  runIdFile=(lp1.readProperty("RUNID"));
			  wtr=new WriteTestResult();
			  //testlog=new WriteTestResult();
			  
			  switch(almupdate)
			  {
			  case "No":
				  if(teststatus==1)
				  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Passed");
					  wtr.writeToFile(runIdFile,"G164,"+ lst.get(i)+","+TID+",Passed");
					  System.out.println("Updating"+lst.get(i)+"status as Passed");
				  }
				  }else
				  {
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Failed");
						  wtr.writeToFile(runIdFile,"G164,"+ lst.get(i)+","+TID+",Failed");
						  System.out.println("Updating"+lst.get(i)+"status as Failed");
					  }
					  
				  }
				  break;
			  case "no":
				  if(teststatus==1)
				  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Passed");
					  wtr.writeToFile(runIdFile,"G164,"+ lst.get(i)+","+TID+",Passed");
				  }
				  }else
				  {
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Failed");
						  wtr.writeToFile(runIdFile,"G164,"+ lst.get(i)+","+TID+",Failed");
					  }
					  
				  }
				  break;
			/*  case "yes":
				  updateALM();
				  break;
			  case "Yes":
				  updateALM();
				  break;*/
			  }

			   Logoff loff=new Logoff(logger);
			   loff.logofffromSFT(connectionmap);
			  logger.info("G164WINFTPCRLFLF Execution completed");
		 }
		/*Updating ALM*/
		 public void updateALM()
		 {
			 /* ALMConnect alm = new ALMConnect();
			  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
			  if(qcstatus){
				  if(teststatus==1){
					  String strStatus="Passed";
					  String filePath=FrameworkConstants.RunLog;
					  String workdir=System.getProperty("user.dir");
			          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
			          System.out.println("workdir"+workdir);
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Passed");
						  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						  wtr.writeToFile(runIdFile,"G164,"+ lst.get(i)+","+TID+",Passed");
					  }
				  }else{
						  String strStatus="Failed";
						  String filePath=FrameworkConstants.RunLog;
						  String workdir=System.getProperty("user.dir");
				          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
				          System.out.println("workdir"+workdir);
						  for(int i=0;i<lst.size();i++)
						  {
							  logger.info("Updating"+lst.get(i)+"status as Failed");
							  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
							  wtr.writeToFile(runIdFile,"G164,"+ lst.get(i)+","+TID+",Failed");
						  }
					  }
					  
				  }else{
				  System.out.println("Unable to login to ALM");
				  logger.info("Unable to login to ALM");
				  }*/

		 
		 }
	 
	 }

