
package amex.fs.sft;

import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPSClient;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;


import amex.fs.commons.Download;
import amex.fs.commons.FileComparision;
import amex.fs.commons.FileSizeCheck;
import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.Login;
import amex.fs.commons.Logoff;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.Upload;
import amex.fs.commons.WriteTestResult;

public class G310FTPMultipleSession {
	
	int teststatus=0;
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G310FTPMultipleSession.class);
	String uploadedfilenameFTP = null;
	String uploadedfilenameFTP1 = null;
	FTPClient connect = null;
	Map connectionmapFTP,uplaodmapFTP;
	Map connectionmapFTP1;
	  Map connectionmap, uplaodmap;
	  String servername;
	  String qcurl;
	  String qcuname;
	  String qcpwd;
	  String domain;
	  String project;
	  String TLpath;
	  String TSet;
	  String runIdFile;
	  List<String> lst;
	  WriteTestResult wtr,testlog;
	  String TID;
	  
	Logoff logoff = new Logoff(logger);
	 
	public static void main(String[] args)
	{
		G310FTPMultipleSession fg = new G310FTPMultipleSession();
		try {
			
			fg.f("G310FTPMultipleSession", "G31Multiple", "No", "21", "FTP", "G31MultipleFile", "TESTFILE.txt", "/inbox","null", "BINARY", "PASSIVE", "null");
						
			} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	 @Test
	 @Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode", "Basefile2"})
	 public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, String remotedirectory, String action, String filetype, String filetransfermode, String Basefile2) throws IOException, InterruptedException{
	 {
		  logger.info("G310FTPMultipleSession Execution Started");
		  logger.info("Loading Properties");
		  LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);
		  servername=lp.readProperty("server");
		  qcurl=lp.readProperty("almurl");
		  qcuname=lp.readProperty("almuser");
		  qcpwd=lp.readProperty("almpwd");
		  domain=lp.readProperty("almdomain");
		  project=lp.readProperty("almproject");
		  TLpath=lp.readProperty("almTLPath");
		  TSet=lp.readProperty("almTSet");
		  int intport=Integer.parseInt(port);
		  Map dwnld = new HashMap();
		  boolean constatus= false;
		  boolean sizestatus = false;
		  Login lg=new Login(logger);
		  connectionmapFTP= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD, protocol);
		  if((boolean) connectionmapFTP.get("loginstatus")){
			  logger.info(sftuser+" logged into "+servername+" successfully ");
			  Upload up=new Upload(logger);
			  uplaodmapFTP = up.uploadFile(connectionmapFTP, basefilename, physicalfile, remotedirectory, filetype, filetransfermode);
			  
			  if((boolean) uplaodmapFTP.get("uploadstatus") && protocol.equalsIgnoreCase("FTP")){
				  uploadedfilenameFTP = (String) uplaodmapFTP.get("Filename");		  
				  logger.info(sftuser+" uploaded "+uploadedfilenameFTP+" successfully ");
				  connectionmapFTP1= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD,protocol);
			  if((boolean) connectionmapFTP1.get("loginstatus")){
				  logger.info(sftuser+" logged into "+servername+" successfully ");
				  Map uplaodmapFTP1 = up.uploadFile(connectionmapFTP1, basefilename, physicalfile, remotedirectory, filetype, filetransfermode);
					
			  if((boolean) uplaodmapFTP1.get("uploadstatus")){
				  uploadedfilenameFTP1 = (String) uplaodmapFTP1.get("Filename");		  
				  logger.info(sftuser+" uploaded "+uploadedfilenameFTP1+" successfully ");  
				  
				  System.out.println("File lISTING");
				  System.out.println("File 1--> "+uploadedfilenameFTP);
				  System.out.println("File 2--> "+uploadedfilenameFTP1);
					 
				  connect = (FTPClient) connectionmapFTP1.get("connection");
				  String pwd = connect.printWorkingDirectory();
				  System.out.println("Present working dir"+pwd);
				  FTPFile[] files = connect.listFiles();
				  System.out.println(files.length);
				  for (FTPFile f : files){
				  		  System.out.println("f-->"+f.getName());
						  if(( f.getName()).equalsIgnoreCase(uploadedfilenameFTP) || (f.getName()).equalsIgnoreCase(uploadedfilenameFTP1))
						  {
							  teststatus = 1;
						  }
						  else
							  teststatus = 0;
					 }
				  if (teststatus == 1){
					  System.out.println("***PASS***");
				  }else
					  System.out.println("***FAIL***");
				 }
			  else{
				  teststatus=0;
				  logger.info(sftuser+" failed to upload "+basefilename);
				  TID="Upload Failed";
			  	}
			  }else{
			  logger.info(sftuser+" unable to login to "+servername);
			  teststatus=0;
			  TID="Login Failed";
			  }
			}
			  
		  }else
		  {
			  logger.info(sftuser+" unable to login to "+servername);
			  teststatus=0;
			  TID="Login Failed";
		  }


		  TestcaseLookup tl =new TestcaseLookup(logger);
		 
		  lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G310");
		  
		  LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
		  runIdFile=(lp1.readProperty("RUNID"));
		  wtr=new WriteTestResult();
		  testlog=new WriteTestResult();
		  
		  switch(almupdate)
		  {
		  case "No":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G310,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G310,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "no":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G310,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G310,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "yes":
			  updateALM();
			  break;
		  case "Yes":
			  updateALM();
			  break;
		  }

		  logger.info("G10FTPpassiveUploadDownload Execution completed");
	
	 
}}

	 public void updateALM()
	 {
		/*  ALMConnect alm = new ALMConnect();
		  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
		  if(qcstatus){
			  if(teststatus==1){
				  String strStatus="Passed";
				  String filePath=FrameworkConstants.RunLog;
				  String workdir=System.getProperty("user.dir");
		          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
		          System.out.println("workdir"+workdir);
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Passed");
					  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
					  wtr.writeToFile(runIdFile,"G310,"+ lst.get(i)+","+TID+",Passed");
				  }
			  }else{
					  String strStatus="Failed";
					  String filePath=FrameworkConstants.RunLog;
					  String workdir=System.getProperty("user.dir");
			          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
			          System.out.println("workdir"+workdir);
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Failed");
						  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						  wtr.writeToFile(runIdFile,"G310,"+ lst.get(i)+","+TID+",Failed");
					  }
				  }
				  
			  }else{
			  System.out.println("Unable to login to ALM");
			  }
*/
	 
	 }	 
}