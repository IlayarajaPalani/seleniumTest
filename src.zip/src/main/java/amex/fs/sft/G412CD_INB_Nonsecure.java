package amex.fs.sft;


/*Description:
 * project: NGP Automation.
 * author: Viren Tiwari
 * This program is to test CD non secure plus node using CD protocol .
 * A file will be uploaded to SFT server and the file will be verified at the T&M   . 
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;


import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import amex.fs.commons.Download;
import amex.fs.commons.FileComparision;
import amex.fs.commons.FileSizeCheck;
import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.Login;
import amex.fs.commons.Logoff;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.Upload;
import amex.fs.commons.WriteTestResult;



	public class G412CD_INB_Nonsecure{
		boolean teststatus=false;
		int teststatus1=0;
		public static org.slf4j.Logger logger = LoggerFactory.getLogger(G412CD_INB_Nonsecure.class);
		 String uploadedfilename = null;
		
		 String status="	Completed";
		 Map connectionmap,connectionmap1,uplaodmap;
		  String servername,TPurl,TPuser,TPpwd,certTPurl,certTPuser,certTPpwd;
		  String qcurl;
		  String qcuname;
		  String qcpwd;
		  String domain;
		  String project;
		  String TLpath;
		  String TSet;
		  String runIdFile;
		  List<String> lst;
		  WriteTestResult wtr,testlog;
		  String TID;
		  String tid=null;
		  String CDremoteuser="PODCDINBUSER";
		  String cdphysicalfile="'WXX830.OBB.TEST.FILE.G0666V00'";
		  FirefoxProfile profile1 = new FirefoxProfile();  
		  WebDriver wd= new FirefoxDriver(profile1);
		  
		  Logoff loff = null;
		  
		 boolean TMVerification_status = false;	
		 boolean certTMVerification_status = false;	
		 
		  /* Main method which takes the parameter from the testng.xml
			  * 
			  */
		public static void main(String[] args) throws Throwable
		{
			G412CD_INB_Nonsecure fg = new G412CD_INB_Nonsecure();
			
				fg.f( "G412CD_INB_Nonsecure", "POD_DELVUSER01","amex123", "21", "FTP", "NONSECUREINB", "TESTFILE.txt", "/inbox",null,"ASCII", "PASSIVE","PODCDINBUSERFILE");
				
		}
		
			
		@Test
		/* Loading Properties for ALM and SFT details
		   * 
		   */
		@Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode","Basefile2"})

		public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, String remotedirectory,String Action, String filetype, String filetransfermode,String Basefile2 ) throws Throwable{
			 logger.info("CDInboundTransferCheck Execution Started");
			  logger.info("Loading Properties");
			  LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);
			  String servername=lp.readProperty("server");
			  String remoteserver = lp.readProperty("remoteserver");
			  String remoteuser = lp.readProperty("remoteuser");
			  String qcurl=lp.readProperty("almurl");
			  String qcuname=lp.readProperty("almuser");
			  String qcpwd=lp.readProperty("almpwd");
			  String domain=lp.readProperty("almdomain");
			  String project=lp.readProperty("almproject");
			  String TLpath=lp.readProperty("almTLPath");
			  String TSet=lp.readProperty("almTSet");
			  TPurl=lp.readProperty("tpurl");
				TPuser=lp.readProperty("tpuser");
				TPpwd=lp.readProperty("tppwd");
		    certTPurl=lp.readProperty("Certtpurl");
			certTPuser=lp.readProperty("Certtpuser");
			certTPpwd=lp.readProperty("Certtppwd");
			  
			  
			  int intport=Integer.parseInt(port);
			  Map dwnld = new HashMap();
			  boolean constatus= false;
			  boolean sizestatus = false;
			  Login lg=new Login(logger);
			  Download downloadmap = new Download(logger);
			  loff=new Logoff(logger);
			 /* File f = new File("sysoutput.txt");
			  PrintStream out = new PrintStream(new FileOutputStream(f, true));
			  System.setOut(out);*/
			  
			//login into the remote server and downloading the file if it exists
			  
			  connectionmap= lg.logintoSFT(remoteserver, intport, CDremoteuser, FrameworkConstants.DefaultSFTPWD, protocol);
	          logger.info(CDremoteuser+" logged into "+servername+" successfully ");
	          System.out.println();
	          FTPClient ftpclient = (FTPClient) connectionmap.get("connection");
	          ftpclient.changeWorkingDirectory(FrameworkConstants.RemoteOutbox);
	          logger.info(CDremoteuser+"changed the working directory as "+FrameworkConstants.RemoteOutbox+" successfully");
	          FTPFile[] files= ftpclient.listFiles();
	          System.out.println(files.length);
	          if(files.length>0){
	                 logger.info(sftuser+"is having+"+files.length+"in outbox directory");
	                 for (FTPFile file : files)
	                 {
	                       if(file.getName().equals(Basefile2)){
	                              logger.info(sftuser+"is having"+Basefile2+"in outbox directory and downalod is started ");
	                              dwnld= downloadmap.downloadFile(connectionmap, Basefile2, FrameworkConstants.DownloadDirectory+""+Basefile2, FrameworkConstants.RemoteOutbox, filetype, filetransfermode);
	                              break;
	                 }
	               
	               }
	          }
	          else{
	                 System.out.println("Remote server is not having any files in"+FrameworkConstants.RemoteOutbox);
	          }
	          loff.logofffromSFT(connectionmap);

		logger.info("G412CD_INB_Nonsecure Execution Started");

		logger.info("Loading Properties");
		/* properties file loaded successfully
		  */
		
		
		

		 uplaodmap = new HashMap();

		/* Login to SFT server using SFTP protocol and checking the connection status
		   * 
		   */
		 
		connectionmap= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD, protocol);
		if((boolean) connectionmap.get("loginstatus")){ //check weather login is successful

		logger.info(sftuser+" logged into "+servername+" successfully ");

		Upload up=new Upload(logger); //uploading the files into the server

		uplaodmap = up.uploadFile(connectionmap, basefilename, physicalfile, remotedirectory, filetype, filetransfermode);
		
		 uploadedfilename = (String) uplaodmap.get("Filename");
		 System.out.println("File name  "+uploadedfilename);
		 String []splitfilename= uploadedfilename.split("#");
		 tid= splitfilename[1];
		 System.out.println("TID value : "+tid);
		 
		if((boolean) uplaodmap.get("uploadstatus"))
		{
			//G412CD_INB_Nonsecure fg = new G412CD_INB_Nonsecure();
			 Thread.sleep(FrameworkConstants.SleepValue); 
			 
			teststatus= trackingidverify(tid,TPurl,TPuser,TPpwd);
			System.out.println("testcase  is"+teststatus);
			logger.info("testcase is "+teststatus);
			teststatus=true;
			
		}
			
      else{teststatus=false; // if different
		
			logger.info("unable to upload file");
			TID="Upload Failed";
			
		}
		TID=(String) uplaodmap.get("TID");
		}
		
		else{
			teststatus=false; // if different
			
			System.out.println("unable to login");
			logger.info("unable to login");
			teststatus=false;
			TID="Login Failed";
		}
		
		
	
		TestcaseLookup tl =new TestcaseLookup(logger);
		// Identifying the testcase to be updated in the ALM based on the group number
		 
		 
		  lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G412");
		
		  LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
		  runIdFile=(lp1.readProperty("RUNID"));
		  wtr=new WriteTestResult();
		  testlog=new WriteTestResult();
		  
		  switch(almupdate)
		  {
		  case "No":
			  if(teststatus)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G412,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G412,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "no":
			  if(teststatus)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G412,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G412,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "yes":
			  updateALM();
			  break;
		  case "Yes":
			  updateALM();
			  break;
		  }
		
		
		  connectionmap= lg.logintoSFT(remoteserver, intport, CDremoteuser, FrameworkConstants.DefaultSFTPWD, protocol);
		  Thread.sleep(FrameworkConstants.SleepValue);
				dwnld= downloadmap.downloadFile(connectionmap, Basefile2, FrameworkConstants.DownloadDirectory+""+Basefile2, FrameworkConstants.RemoteOutbox, filetype, filetransfermode);
				if((boolean) dwnld.get("downloadstatus"))
				{
					logger.info(FrameworkConstants.DownloadDirectory+Basefile2+" Downloaded Successfully");
					System.out.println(FrameworkConstants.DownloadDirectory+Basefile2+" Downloaded Successfully");
					teststatus1=1;
				}else
				{
					logger.info(FrameworkConstants.DownloadDirectory+Basefile2+" Download Failed");
					System.out.println(FrameworkConstants.DownloadDirectory+Basefile2+" Download Failed");
					teststatus1=0;
				}
			   loff.logofffromSFT(connectionmap);
			   
			FileComparision fc = new FileComparision(logger);
			constatus = fc.contentVerification(cdphysicalfile, FrameworkConstants.DownloadDirectory+"/"+Basefile2);
			logger.info("File comparision status:"+constatus);
			System.out.println("File comparision status:"+constatus);
			FileSizeCheck fs = new FileSizeCheck(logger);
			sizestatus = fs.fileSizeVerification(cdphysicalfile, FrameworkConstants.DownloadDirectory+"/"+Basefile2);
			logger.info("File size verification status:"+sizestatus);
			System.out.println("File size verification status:"+sizestatus);
			if(constatus&&sizestatus){
				teststatus1=1;
				}else{
					teststatus1=0;
					 }
				
			/*logging off from the SFT server
			 * 
			 */	

		logger.info("G412CD_INB_Nonsecure Execution completed");
		System.out.println("G412CD_INB_Nonsecure Execution completed");
        if(teststatus){
		Logoff loff=new Logoff(logger);
		loff.logofffromSFT(connectionmap);
        }

        
		}
		
		 public boolean trackingidverify(String tid,String url,String id,String pass) throws Throwable
		    {       
			 TMpagetrackingidverify(TPurl,TPuser,TPpwd);
		     
		     if (!wd.findElement(By.xpath("//table[@id='Table6']/tbody/tr[3]/td/table/tbody/tr[2]/td[1]/p/font/select//option[5]")).isSelected()) {
		         wd.findElement(By.xpath("//table[@id='Table6']/tbody/tr[3]/td/table/tbody/tr[2]/td[1]/p/font/select//option[5]")).click();
		     }
		     wd.findElement(By.name("filterByValue")).click();
		     wd.findElement(By.name("filterByValue")).clear();
		     wd.findElement(By.name("filterByValue")).sendKeys(tid);
		   
		     Thread.sleep(400000);
		        
		     wd.findElement(By.name("search")).click();
		     
		     Thread.sleep(FrameworkConstants.SleepValue); 
		     String time_SFT= wd.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[3]/form/table/tbody/tr[4]/td[1]/table/tbody/tr[2]/td[5]/p/font")).getText();
			  System.out.println("SFT Time:"+time_SFT);
			  String[] splittime1 = time_SFT.split("\\.");
			  /*for (String element : splittime1) {
				    System.out.println("Element: " + element);
				}*/
				String SFT_time= splittime1[0];
				 System.out.println("SFT_tim value : "+SFT_time);
			  Thread.sleep(FrameworkConstants.SleepValue); 
			  
		     wd.findElement(By.id("Picture14")).click();
		    
		     boolean temp= wd.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[3]/form/div[2]/layer/table/tbody/tr[5]/td[3]/a/p/font")).getText().contains("File Push to Client");
		   
		 
		   if(temp==true)
		   {
			   System.out.println("passed");
			   TMVerification_status =true;
			   logger.info("file push to Client is Completed");
			  String temp1= wd.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[3]/form/div[2]/layer/table/tbody/tr[5]/td[5]/p/font")).getText().trim();
			
			  System.out.println("Status :"+temp1);
			  logger.info(" Message: /t"+temp1 );
			  
			 
			    /* wd.findElement(By.name("logoutTM")).click();
			     Thread.sleep(FrameworkConstants.SleepValue); 
			     wd.quit();*/
			  
			  if(temp1.equals("Completed"))
			{  
			  //wd.switchTo().frame(1);
			  //wd.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[3]/form/div[2]/layer/table/tbody/tr[1]/td/table/tbody/tr/td[3]/a/img")).click();
			  logger.info("logoff from TM");
			  wd.findElement(By.name("logoutTM")).click();
			 // wd.switchTo().defaultContent();
			  
			  TMpagetrackingidverify(certTPurl,certTPuser,certTPpwd);
			  //wd.findElement(By.id("Picture67")).click();
			  //wd.findElement(By.id("Picture7")).click();

			     if (!wd.findElement(By.xpath("//table[@id='Table6']/tbody/tr[3]/td/table/tbody/tr[2]/td[1]/p/font/select//option[2]")).isSelected()) {
			         wd.findElement(By.xpath("//table[@id='Table6']/tbody/tr[3]/td/table/tbody/tr[2]/td[1]/p/font/select//option[2]")).click();
			     }
			     wd.findElement(By.name("filterByValue")).click();
			     wd.findElement(By.name("filterByValue")).clear();
			     
				wd.findElement(By.name("filterByValue")).sendKeys(CDremoteuser);
			     
				Thread.sleep(FrameworkConstants.SleepValue);
			     
			     
			     wd.findElement(By.name("search")).click();
			     
			     Thread.sleep(FrameworkConstants.SleepValue); 
			     String time_Inb= wd.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[3]/form/table/tbody/tr[4]/td[1]/table/tbody/tr[2]/td[5]/p/font")).getText();
				  System.out.println("Inbound Time:"+time_Inb);
				  String splittime2[]= time_Inb.split("\\.");
					String INB_time= splittime2[0];
					 System.out.println("INB_time value : "+INB_time);
				  Thread.sleep(FrameworkConstants.SleepValue);
				  
				 				  
		 if(INB_time.equals(SFT_time))
				  {
			     wd.findElement(By.id("Picture14")).click();
			     Boolean temp2= wd.findElement(By.xpath(" .//*[@id='SFTBUTTONLYR']/tbody/tr[5]/td[3]/a/p/font")).getText().contains("File Mailbox");
			     if(temp2==true)
				   {
					   System.out.println("Inbound is passed");
					   TMVerification_status =true;
					   logger.info("file is suspended due to configuration");
					  String temp3= wd.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[3]/form/div[2]/layer/table/tbody/tr[5]/td[5]/p/font")).getText();
					
					  System.out.println(temp3);
					  logger.info(" Message: /t"+temp3 ); 
				   }
				 
				 else{
						   System.out.println("failed");
						   TMVerification_status =false;
						   logger.info("test case is failed");
					   }
				  }
		 
			}
			  else{
					System.out.println("failed due to :"+temp1);
					logger.info("test case is failed due to"+temp1);
				}
			  
			  }
			     
		 
		   else{
			   System.out.println("failed");
			   TMVerification_status =false;
			   logger.info("test case is failed");
		   }
		   
		     
		   logger.info("logoff from TM");
		     wd.findElement(By.name("logoutTM")).click();
		     Thread.sleep(FrameworkConstants.SleepValue); 
		     wd.quit();
		     
		           
		           
		           if( TMVerification_status)
		           {
		                  System.out.println(" the delivery is completed");
		           }
		           else
		           {
		                  System.out.println("the delivery got failed");
		           }
		           
		           return TMVerification_status;
		               
		  
		   }
		 
//*****************
		 public void TMpagetrackingidverify(String url,String id,String pass) throws Throwable
		    {       
		           System.out.println("connecting to firefox");
		          // FirefoxProfile profile1 = new FirefoxProfile();  
		           profile1.setPreference("network.proxy.type",4);
		           
		           
		          // WebDriver wd= new FirefoxDriver(profile1);
		           
		           wd.manage().window().maximize();
		           
		     wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		     logger.info("login to TM");
		     System.out.println("connected to TM");
		     System.out.println("opening TM");
		     wd.get(url);
		     wd.findElement(By.id("textboxuid_AD")).click();
		     wd.findElement(By.id("textboxuid_AD")).clear();
		     wd.findElement(By.id("textboxuid_AD")).sendKeys(id);
		     wd.findElement(By.id("textboxpwd_AD")).click();
		     wd.findElement(By.id("textboxpwd_AD")).clear();
		     wd.findElement(By.id("textboxpwd_AD")).sendKeys(pass);
		     wd.findElement(By.id("Login")).click();
		     wd.findElement(By.id("NavigationButton2")).click();
		     logger.info("login successful");
		     System.out.println("login successful");
		     
		     if (!wd.findElement(By.id("NavigationButton2")).isSelected()) {
		    	 wd.findElement(By.id("NavigationButton2")).click();
		     }
		     Thread.sleep(FrameworkConstants.SleepValue); 
		     if (!wd.findElement(By.xpath("/html/body/table[3]/tbody/tr[1]/td[3]/form/table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/font/input[2]")).isSelected()) {
		         wd.findElement(By.xpath("/html/body/table[3]/tbody/tr[1]/td[3]/form/table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/font/input[2]")).click();
		     }
		     
		        
		     
		    // return certTMVerification_status;
		    }
//***************

		 
		 
		public void updateALM()
		 {
			 /* ALMConnect alm = new ALMConnect();
			  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
			  if(qcstatus){
				  if(teststatus){
					  String strStatus="Passed";
					  String filePath=FrameworkConstants.RunLog;
					  String workdir=System.getProperty("user.dir");
			          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
			          System.out.println("workdir"+workdir);
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Passed");
						  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						  wtr.writeToFile(runIdFile,"G412,"+ lst.get(i)+","+TID+",Passed");
					  }
				  }else{
						  String strStatus="Failed";
						  String filePath=FrameworkConstants.RunLog;
						  String workdir=System.getProperty("user.dir");
				          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
				          System.out.println("workdir"+workdir);
						  for(int i=0;i<lst.size();i++)
						  {
							  logger.info("Updating"+lst.get(i)+"status as Failed");
							  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
							  wtr.writeToFile(runIdFile,"G412,"+ lst.get(i)+","+TID+",Failed");
						  }
					  }
					  
				  }else{
				  System.out.println("Unable to login to ALM");
				  }*/

		 
		 }	
	}
