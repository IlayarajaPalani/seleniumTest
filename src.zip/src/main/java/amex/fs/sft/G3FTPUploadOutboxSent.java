package amex.fs.sft;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.LoggerFactory;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.Login;
import amex.fs.commons.Logoff;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.Upload;
import amex.fs.commons.WriteTestResult;

import com.saucelabs.common.SauceOnDemandAuthentication;
import com.saucelabs.common.SauceOnDemandSessionIdProvider;
import com.saucelabs.testng.SauceOnDemandAuthenticationProvider;
import com.saucelabs.testng.SauceOnDemandTestListener;

@Listeners({SauceOnDemandTestListener.class})
public class G3FTPUploadOutboxSent implements SauceOnDemandSessionIdProvider, SauceOnDemandAuthenticationProvider{
	
	public String username = System.getenv("SAUCE_USER_NAME") != null ? System.getenv("SAUCE_USER_NAME") : System.getenv("SAUCE_USERNAME");
    public String accesskey = System.getenv("SAUCE_API_KEY") != null ? System.getenv("SAUCE_API_KEY") : System.getenv("SAUCE_ACCESS_KEY");
	
    public SauceOnDemandAuthentication authentication = new SauceOnDemandAuthentication(username, accesskey);
    
    private ThreadLocal<String> sessionId = new ThreadLocal<String>();
    
	
	
	
	int teststatus=0;
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G3FTPUploadOutboxSent.class);
	 String uploadedfilename = null;
	  Map connectionmap, uplaodmap;
	  String servername;
	  String qcurl;
	  String qcuname;
	  String qcpwd;
	  String domain;
	  String project;
	  String TLpath;
	  String TSet;
	  String runIdFile;
	  List<String> lst;
	  WriteTestResult wtr,testlog;
	  String TID;
	
	 @Test
	 @Parameters({"TestCaseName","SFTUser","ALMUpdate","Port","Protocol","BaseFileName","PhysicalFile","RemoteDirectory","Action","FileType","FileTransferMode"})
	 public void f(String tcname, String sftuser, String almupdate, String port, String protocol, String basefilename, String physicalfile, String remotedirectory, String action, String filetype, String filetransfermode) throws IOException, InterruptedException{
		  logger.info("G3FTPUploadOutboxSent Execution Started");
		  logger.info("Loading Properties");
		  LoadProperties lp=new LoadProperties(FrameworkConstants.SFT);
		  servername=lp.readProperty("server");
		  qcurl=lp.readProperty("almurl");
		  qcuname=lp.readProperty("almuser");
		  qcpwd=lp.readProperty("almpwd");
		  domain=lp.readProperty("almdomain");
		  project=lp.readProperty("almproject");
		  TLpath=lp.readProperty("almTLPath");
		  TSet=lp.readProperty("almTSet");
		  int intport=Integer.parseInt(port);
		  //BasicConfigurator.configure();
		  uplaodmap = new HashMap();
		  Map dwnld = new HashMap();
		  /*File f = new File("sysoutput.txt");
		  PrintStream out = new PrintStream(new FileOutputStream(f));
		  System.setOut(out);*/
		  Login lg=new Login(logger);
		  connectionmap= lg.logintoSFT(servername, intport, sftuser, FrameworkConstants.DefaultSFTPWD, protocol);
		  System.out.println("connection map "+connectionmap);
		  if((boolean) connectionmap.get("loginstatus")){
			  logger.info(sftuser+" logged into "+servername+" successfully ");
			  Upload up=new Upload(logger);
				  switch(action)
				  {
				  case "U" :
					  uplaodmap = up.uploadFile(connectionmap, basefilename, physicalfile, remotedirectory, filetype, filetransfermode);
		  				if((boolean) uplaodmap.get("uploadstatus"))
		  				{
		  					logger.info(sftuser+" uploaded "+uploadedfilename+" successfully ");
		  				}else
		  				{
		  					logger.info(sftuser+" failed to upload "+basefilename);
		  				}
		  				break;
		  	
				  case "UU"  :
					  uplaodmap = up.uploadFile(connectionmap, basefilename, physicalfile, remotedirectory, filetype, filetransfermode);
		  				if((boolean) uplaodmap.get("uploadstatus"))
		  				{
		  					logger.info(sftuser+" uploaded "+uploadedfilename+" successfully from "+remotedirectory);
		  					uplaodmap = up.uploadFile(connectionmap, basefilename, physicalfile, FrameworkConstants.RemoteSent, filetype, filetransfermode);
		  					if((boolean) uplaodmap.get("uploadstatus")){
		  						logger.info(sftuser+" uploaded "+uploadedfilename+" successfully from"+ FrameworkConstants.RemoteSent);
		  						teststatus=1;
		  					}else{
		  						logger.info(sftuser+" failed to upload file: "+uploadedfilename+" from"+ FrameworkConstants.RemoteSent);
		  					}
		  					
		  				}else
		  				{
		  					logger.info(sftuser+" failed to upload "+basefilename+"from "+remotedirectory);
		  					TID="Upload Failed";
		  				}
		  				break;
 						
		  				
		  		default:
		  			 	teststatus=0;
		  				break;
		  				}
				  TID=(String)uplaodmap.get("TID");
				  }
		  else{
			  logger.info(sftuser+" unable to logint to "+servername);
			  teststatus=0;
			  TID="Login Failed";
		  }
		  TestcaseLookup tl =new TestcaseLookup(logger);
		  //String groupname = tcname.substring(0, 2);
		  lst = tl.lookupTestcase(FrameworkConstants.TCLookup, "G3");
		  
		  LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
		  runIdFile=(lp1.readProperty("RUNID"));
		  wtr=new WriteTestResult();
		  testlog=new WriteTestResult();
		  
		  switch(almupdate)
		  {
		  case "No":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G3,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G3,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
		  case "no":
			  if(teststatus==1)
			  {
			  for(int i=0;i<lst.size();i++)
			  {
				  logger.info("Updating"+lst.get(i)+"status as Passed");
				  wtr.writeToFile(runIdFile,"G3,"+ lst.get(i)+","+TID+",Passed");
			  }
			  }else
			  {
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Failed");
					  wtr.writeToFile(runIdFile,"G3,"+ lst.get(i)+","+TID+",Failed");
				  }
				  
			  }
			  break;
/*		  case "yes":
			  updateALM();
			  break;
		  case "Yes":
			  updateALM();
			  break;*/
		  }

		  if(teststatus==1)
		  {
		  Logoff loff=new Logoff(logger);
		   loff.logofffromSFT(connectionmap);
		  }
		  logger.info("G3FTPUploadOutboxSent Execution completed");
		  }
	 
	 public void updateALM()
	 {
		  /*ALMConnect alm = new ALMConnect();
		  boolean qcstatus = alm.connectALM(qcurl, qcuname, qcpwd, domain, project );
		  if(qcstatus){
			  if(teststatus==1){
				  String strStatus="Passed";
				  String filePath=FrameworkConstants.RunLog;
				  String workdir=System.getProperty("user.dir");
		          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
		          System.out.println("workdir"+workdir);
				  for(int i=0;i<lst.size();i++)
				  {
					  logger.info("Updating"+lst.get(i)+"status as Passed");
					  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
					  wtr.writeToFile(runIdFile,"G3,"+ lst.get(i)+","+TID+",Passed");
				  }
			  }else{
					  String strStatus="Failed";
					  String filePath=FrameworkConstants.RunLog;
					  String workdir=System.getProperty("user.dir");
			          String fileName=workdir+"\\"+FrameworkConstants.RunLog;
			          System.out.println("workdir"+workdir);
					  for(int i=0;i<lst.size();i++)
					  {
						  logger.info("Updating"+lst.get(i)+"status as Failed");
						  alm.updateTestCase(TLpath, TSet, lst.get(i), strStatus, filePath);
						  wtr.writeToFile(runIdFile,"G3,"+ lst.get(i)+","+TID+",Failed");
					  }
				  }
				  
			  }else{
			  System.out.println("Unable to login to ALM");
			  }*/

	 
	 }
	 	public String getSessionId() {
	        return sessionId.get();
	    }
	    
	    @Override
	    public SauceOnDemandAuthentication getAuthentication() {
	        return authentication;
	    }
}
