package amex.fs.sft;

import java.io.IOException;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.apache.log4j.BasicConfigurator;
import org.testng.TestListenerAdapter;
import org.testng.TestNG;
import org.testng.annotations.Test;
import org.testng.collections.Lists;

import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.RunId;
import amex.fs.commons.XMLGen;

public class SFTController_PGP {
  @Test
  public void f() throws IOException, JAXBException {
	  
	 // TestListenerAdapter tla = new TestListenerAdapter();
	 // BasicConfigurator.configure();
	 // String className = this.getClass().getSimpleName();
	  TestNG tng = new TestNG();
	  List<String> suites = Lists.newArrayList();
	  //RunId rd= new RunId(className);
	  RunId rd= new RunId();
	  rd.generateRunId();
	  XMLGen dynamicxml=new XMLGen(true);
	  
	  dynamicxml.readExcel(FrameworkConstants.ExecutionSheet_PGP, "testng-nonhttps-pgp.xml");
	  
	  suites.add("testng-nonhttps-pgp.xml");
	  
	 tng.setTestSuites(suites);
	 tng.run();
  }
}
