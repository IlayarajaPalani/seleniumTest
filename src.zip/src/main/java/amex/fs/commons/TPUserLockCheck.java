package amex.fs.commons;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.slf4j.LoggerFactory;

import amex.fs.sft.G322FTPSUserLockOut;

public class TPUserLockCheck {
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G322FTPSUserLockOut.class);
	 boolean TMVerification_status = false;
	 
	 public boolean trackingidverify(String user,String url,String id,String pass) throws Throwable
	 
	    {
		 try{ 
			 System.out.println("connecting to firefox");
		
	           FirefoxProfile profile1 = new FirefoxProfile();  
	           profile1.setPreference("network.proxy.type",4);
	           
	           
	           WebDriver wd= new FirefoxDriver(profile1);
	           
	           wd.manage().window().maximize();
	           
	     wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	    // logger.info("login to TP");
	     System.out.println("connected to TP");
	     System.out.println("opening TP");
	     wd.get(url);
	     Thread.sleep(FrameworkConstants.SleepValue); 
	     wd.findElement(By.id("textboxuid_AD")).click();
	     wd.findElement(By.id("textboxuid_AD")).clear();
	     wd.findElement(By.id("textboxuid_AD")).sendKeys(id);
	     wd.findElement(By.id("textboxpwd_AD")).click();
	     wd.findElement(By.id("textboxpwd_AD")).clear();
	     wd.findElement(By.id("textboxpwd_AD")).sendKeys(pass);
	     wd.findElement(By.id("Login")).click();
	     wd.findElement(By.id("NavigationButton2")).click();
	    logger.info("login successful");
	     System.out.println("login successful");
	     if (!wd.findElement(By.xpath(" /html/body/table[3]/tbody/tr/td[1]/form/table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr[4]/td/a/img")).isSelected()) {
	    	 wd.findElement(By.xpath(" /html/body/table[3]/tbody/tr/td[1]/form/table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr[4]/td/a/img")).click();
	     }
	    
	     if (!wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[1]/form/div/dl[4]/dd/a[1]/img")).isSelected()) {
	    	 wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[1]/form/div/dl[4]/dd/a[1]/img")).click();
	     }
	     Thread.sleep(FrameworkConstants.SleepValue); 
	     //wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[1]/input")).clear();
      //wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[1]/input")).sendKeys(transmitter);
	    
	     wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[1]/input")).clear();
	         wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[1]/input")).sendKeys(user);
	         
	         Thread.sleep(FrameworkConstants.SleepValue); 
	         
	         if (!wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[8]/td/input[1]")).isSelected()) {
		    	 wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[8]/td/input[1]")).click();
		     }
	        logger.info("searching:"  +user);
		     System.out.println("searching:"    +user);   
	     
wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/table/tbody/tr[3]/td[1]/a")).click();
for(int i=2;i<=10;i++)
{ 
	 for(int j=3;j<=22;j++)
	 {
		 String temp= wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/div/div[2]/table/tbody/tr["+j+"]/td[1]/a")).getText();
		 if(temp.equals(user))
		 {
			 wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/div/div[2]/table/tbody/tr["+j+"]/td[1]/a")).click();
			 TMVerification_status=true;
			 break;
		 }
		
			 
	 }
	 
	 
	 if( TMVerification_status==true)
	 {
		break; 
		 
	 }
	
	 
	 wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/div/div[2]/table/tbody/tr[23]/td/a["+i+"]")).click();
	 Thread.sleep(5000);
		 
	 }
Thread.sleep(FrameworkConstants.SleepValue); 


Thread.sleep(FrameworkConstants.SleepValue); 
 List<WebElement> ele = wd.findElements(By.xpath(" /html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[10]/td[1]/font"));
 int temp= ele.size();
 
//if(temp.equals("User Lockout Status: Locked"))
/*	if(temp == 0)
		//if (!(wd.findElement(By.xpath(" /html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[10]/td[1]/font")).isDisplayed()))
	{
		  System.out.println("User Lockout field is disabled");
		  logger.info("User Lockout field is disabled");
		   TMVerification_status =false;
		 // logger.info("test case is failed");
		
	     }
	   else if(ele.get(0).isDisplayed()) {
		 
		   System.out.println("User Lockout field is enabled");
		   String lockmsge = wd.findElement(By.xpath(" /html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[10]/td[1]/font")).getText();
		   if (lockmsge.equals("User Lockout Status: Locked")){
			   System.out.println(lockmsge);
			   logger.info(lockmsge);
			  // System.out.println("Test case is : passed");
			   TMVerification_status =true;
			  logger.info(user+"is locked due to wrong password");
			   System.out.println(user+"is locked due to wrong password"); 
		   }
		  
	   }
	   else{
		   
	   }*/

	    if(temp > 0 && ele.get(0).isDisplayed()){
	    	 System.out.println("User Lockout field is enabled");
			   String lockmsge = wd.findElement(By.xpath(" /html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[10]/td[1]/font")).getText();
			   if (lockmsge.equals("User Lockout Status: Locked")){
				   System.out.println(lockmsge);
				   logger.info(lockmsge);
				  // System.out.println("Test case is : passed");
				   TMVerification_status =true;
				  logger.info(user+"is locked due to wrong password");
				   System.out.println(user+"is locked due to wrong password"); 
			   }
	    }
	    else{
	    	System.out.println("User Lockout field is disabled");
			  logger.info("User Lockout field is disabled");
			   TMVerification_status =false;
			 // logger.info("test case is failed");
	    }

	   logger.info("logoff from TP");
	     System.out.println("logoff from TP");   
	     
	     wd.findElement(By.xpath("/html/body/table[2]/tbody/tr/td[1]/form/div/dl[9]/a/img")).click();
	     wd.switchTo().alert().accept();
	     
	     Thread.sleep(FrameworkConstants.SleepValue); 
	     wd.quit();
	     
	           
	           
	     
	          
	          
	    
	    }
		 catch(NullPointerException e1)
	        {   e1.printStackTrace();
	        logger.info("unable to proceed:\t"+e1);
	        	TMVerification_status=false;
	        	
	        }
	        catch(NoSuchElementException e2)
	        {   
	        	e2.printStackTrace();
	        	logger.info("unable to proceed:\t"+e2);
	        	TMVerification_status=false;
	        } catch (Throwable e3) {
				
				e3.printStackTrace();
	        	logger.info("unable to proceed:\t"+e3);
	        	TMVerification_status=false;

			}
	        return TMVerification_status; 
}
	
	
}
