package amex.fs.commons;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import amex.fs.sft.G61SSL;

public class WriteTestResult {

	static FileOutputStream fos;
	File resultfile;
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(WriteTestResult.class);
	@Test
	public static void main(String args[]) throws FileNotFoundException
	{
		LoadProperties lp1=new LoadProperties(FrameworkConstants.RunIdFile);
		String runIdFile=(lp1.readProperty("RUNID"));
		WriteTestResult wrt=new WriteTestResult();
		wrt.writeToFile(runIdFile,"Check");
		
	}
	
	public boolean writeToFile(String testresultfilename,String texttowrite)
	{
		try(FileWriter fw = new FileWriter(testresultfilename, true);
			    BufferedWriter bw = new BufferedWriter(fw);
			    PrintWriter out = new PrintWriter(bw))
			{
			    out.println(texttowrite);
			    logger.info("writeToFile:"+texttowrite);
			} catch (IOException e) {
				logger.info("writeToFile failed:"+e.getMessage());
				e.printStackTrace();
			}
	
		return true;
	}
	
	
}
