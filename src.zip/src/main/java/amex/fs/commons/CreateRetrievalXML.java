
/* 
 Description : This module generates the xml by from the input data  provided in the excel sheet
  
 */

package amex.fs.commons;


import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;

import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.slf4j.LoggerFactory;



public class CreateRetrievalXML {
	static String Parallelism;
	static boolean parallel = false;
	String DynTID;
	
	boolean status = false;
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(CreateRetrievalXML.class);
	public CreateRetrievalXML(boolean parallelval) {
		// TODO Auto-generated constructor stub
		Parallelism = "tests" ; 
		parallel = parallelval;
	}
	
	public static void main(String[] args){
		// TODO Auto-generated method stub
	
		
        CreateRetrievalXML xml = new CreateRetrievalXML(false);
        xml.createXML("./test-data/ExecutionSheet_RETRIEVAL.xls", "TEST.xml","/sent","REMOTEDELFILE");
	
	}

	//  This method generates the xml
	
	public String createXML(String excelfilepath, String xmlfilepath,String remotefilepath,String remotefilename){
		logger.info("XML generation got started ");
		logger.info(" excelfilepath : "+excelfilepath);
		logger.info("xmlfilepath : "+xmlfilepath);
		
		String testcasename = null;
		String method = null;
		String basefile = null;
		HSSFWorkbook workbook;
		HSSFSheet worksheet = null;
		Map map = new LinkedHashMap();
		ArrayList al = new ArrayList();
		Map datamap = new HashMap();
		String Testcasename = null;
		StringBuilder sb = new StringBuilder();
		
		try{
		FileInputStream inputStream = new FileInputStream(new File(excelfilepath));
		workbook = new HSSFWorkbook(inputStream);
		worksheet = workbook.getSheet("Sheet1");
		}
		catch(IOException e){
			e.printStackTrace();
			logger.info("The exception: "+e.getMessage());
		}
		sb.append("<Envelope xmlns:xsi="+"\"http://www.w3.org/2001/XMLSchema-instance\""+" xsi:noNamespaceSchemaLocation="+"\"SubmitSecureFileFLow v1.0.xsd\""+" envelopeId="+"\"EMI\""+" majorVersion="+"\"1\""+" minorVersion="+"\"3\""+">");
		sb.append("\n");
		sb.append("<Header>");
		sb.append("\n");
		sb.append("<TransactionBlk name="+"\"StdTransBlk\""+" majorVersion="+"\"1\""+" minorVersion="+"\"2\""+" actor="+"\"NEXT\""+" mustUnderstand="+"\"1\""+">");
		sb.append("\n");
		sb.append("<EncodingTypeCd/>");
		sb.append("\n");
		sb.append("<CharacterSetCd/>");
		sb.append("\n");
		sb.append("<MessageId/>");
		sb.append("\n");
		sb.append("<CorrelationId/>");
		sb.append("\n");
		sb.append("<OriginatorNm>FileServices</OriginatorNm>");
		sb.append("\n");
		sb.append("<ServiceNm>SubmitSecureFileFLow</ServiceNm>");
		sb.append("\n");
		sb.append("<SrvcMajVersionNbr>1</SrvcMajVersionNbr>");
		sb.append("\n");
		sb.append("<SrvcMinVersionNbr>0</SrvcMinVersionNbr>");
		sb.append("\n");
		sb.append("<MsgPatternTypeCd>RR</MsgPatternTypeCd>");
		sb.append("\n");
		sb.append("<MsgTypeCd>I</MsgTypeCd>");
		sb.append("\n");
		sb.append("<MsgSrvcDomainNm/>");
		sb.append("\n");
		sb.append("<MsgSetId/>");
		sb.append("\n");
		sb.append("<MsgNm>SubmitSecureFileFLow</MsgNm>");
		sb.append("\n");
		sb.append("<MsgFormatCd/>");
		sb.append("\n");
		sb.append("<MsgMajVersionNbr>1</MsgMajVersionNbr>");
		sb.append("\n");
		sb.append("<MsgMinVersionNbr>0</MsgMinVersionNbr>");
		sb.append("\n");
		sb.append("<MsgPersistenceTypeCd>P</MsgPersistenceTypeCd>");
		sb.append("\n");
		sb.append("<MsgPriorityNbr>9</MsgPriorityNbr>");
		sb.append("\n");
		sb.append("<MsgExpireTimeQty>999</MsgExpireTimeQty>");
		sb.append("\n");
		Date today=new Date();
		SimpleDateFormat sdfdate=new SimpleDateFormat("yyyy-mm-dd");
		String msgputdate=sdfdate.format(today);
		sb.append("<MsgPutDt>"+msgputdate+"</MsgPutDt>");
		SimpleDateFormat sdftime=new SimpleDateFormat("HH:mm:ss");
		String msgputtime=sdftime.format(today);
		sb.append("\n");
		sb.append("<MsgPutTime>"+msgputtime+"</MsgPutTime>");
		sb.append("\n");
		sb.append("<MsgSLATimeQty>2</MsgSLATimeQty>");
		sb.append("\n");
		sb.append("<SrvcResponseTimeQty/>");
		sb.append("\n");
		sb.append("<ProcessControlId/>");
		sb.append("\n");
		sb.append("<SLAMode>REALTIME</SLAMode>");
		sb.append("\n");
		sb.append("<ReportOptionCd/>");
		sb.append("\n");
		sb.append("<MQMsgTypeCd/>");
		sb.append("\n");
		sb.append("<ReplyToQNm>SubmitFileTransformationReply</ReplyToQNm>");
		sb.append("\n");
		sb.append("<ReplyToQMgrNm>"+FrameworkConstants.RETRIEVAL_QMANAGER+"</ReplyToQMgrNm>");
		sb.append("\n");
		sb.append("</TransactionBlk>");
		sb.append("\n");
		sb.append("</Header>");
		sb.append("\n");
		sb.append("<Body>");
		sb.append("\n");
		sb.append("<Request>");
		sb.append("\n");
		sb.append("<Identifier>");
		sb.append("\n");
		sb.append("<XmitId>00000053004</XmitId>");
		sb.append("\n");
		sb.append("<UserId>"+FrameworkConstants.RetrievalUserID+"</UserId>");
		sb.append("\n");
		sb.append("<BaseFileNm>"+FrameworkConstants.RetrievalBaseFileName+"</BaseFileNm>");
		sb.append("\n");
		sb.append("</Identifier>");
		sb.append("\n");
		sb.append("<File>");
		sb.append("\n");
		String DynTID="A02";
		Random rand = new Random();
		int num = rand.nextInt(9000000) + 1000000;
		DynTID=DynTID+"RTST"+num;
		sb.append("<FileId>"+DynTID+"</FileId>");
		sb.append("\n");
		sb.append("</File>");
		sb.append("\n");
		sb.append("<FileFlow>");
		sb.append("\n");
		sb.append("<FileFlowId/>");
		sb.append("\n");
		sb.append("<FileFlowStepCd/>");
		sb.append("\n");
		sb.append("<FileFlowStepSeqNbr/>");
		sb.append("\n");
		sb.append("<OperUserId/>");
		sb.append("\n");
		sb.append("</FileFlow>");
		sb.append("\n");
		sb.append("<PhysicalFile>");
		sb.append("\n");
		sb.append("<PathTxt>"+remotefilepath+"</PathTxt>");
		sb.append("\n");
		sb.append("<FileNm>"+remotefilename+"</FileNm>");
		sb.append("\n");
		sb.append("</PhysicalFile>");
		sb.append("\n");
		sb.append("</Request>");
		sb.append("\n");
		sb.append("</Body>");
		sb.append("\n");
		sb.append("</Envelope>");
		
	
System.out.println("Into REtrieval xml creation");
try{
File xmlfile = new File(xmlfilepath);
FileWriter fwriter = new FileWriter(xmlfile);
BufferedWriter bwriter = new BufferedWriter(fwriter);
bwriter.write(sb.toString());
bwriter.close();
status= true;
}
catch(IOException e){
	e.printStackTrace();
	System.err.println("Problem writing to the file"+xmlfilepath);
	logger.info("Problem writing to the file"+xmlfilepath);
	status= false;
}
System.out.println(status);
logger.info("The XML is generated successfully");
return DynTID;


		
	  
		}
}