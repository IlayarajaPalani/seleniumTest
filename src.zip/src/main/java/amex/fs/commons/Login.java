/*Description : This module is used to login to the user using FTP and FTPs protocol.
*/
package amex.fs.commons;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.net.PrintCommandListener;
import org.apache.commons.net.ProtocolCommandListener;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPSClient;



public class Login {
	Map<String, Object> connectionobj = new HashMap<String, Object>();
	FTPSClient ftpsclient = null;
	FTPClient ftpclient = null;
	static org.slf4j.Logger  logger;
	boolean loginstatus = false;
	/**org.slf4j.LoggerFactory
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	Login lg = new Login(logger);
		
	lg.logintoSFT("mft.e2-env1.sft.dev.ipc.us.aexp.com", 21, "G1FTPUser", "amex123", "FTPS");
	}
	
		
	/**
	 * 
	 * @param Host
	 * @param Port
	 * @param Username
	 * @param Password
	 * @param Protocol
	 * @return
	 */
	
	public Login(org.slf4j.Logger logger )
	{
		Login.logger=logger;
	}
	
	
	public Map<String, Object> logintoSFT(String Host, int Port, String Username, String  Password, String Protocol)
	{   
		/* Below if condition is executed if user tries to login with FTP protocol. 
		*/
		if (Protocol.equalsIgnoreCase("FTP"))
		{
		
		try {
			ftpclient = new FTPClient();
			ftpclient.addProtocolCommandListener((ProtocolCommandListener) new PrintCommandListener(new PrintWriter(System.out)));
			logger.info("connecting to the Host");
			ftpclient.connect(Host, Port);	
			logger.info("Logging to the server");
			loginstatus = ftpclient.login(Username, Password);
			logger.info("loginstatus------- "+loginstatus);
			connectionobj.put("loginstatus", loginstatus);
			logger.info(ftpclient.getReplyString());
			//System.out.println(ftpclient.getReplyString());
			connectionobj.put("Message", ftpclient.getReplyString());
			System.out.println("connectionobj->"+connectionobj);
			connectionobj.put("loginstatus", loginstatus);
			if(loginstatus){
				connectionobj.put("connection", ftpclient);
				connectionobj.put("protocol", "FTP");
				connectionobj.put("TID", "Only Login Completed");
				
			}
			}
		catch (IOException e) {
		// TODO Auto-generated catch block
	    	e.printStackTrace();
		    logger.info("Exception"+e);
		    connectionobj.put("loginstatus", loginstatus);
			connectionobj.put("TID", "Login Failed");
		   
		}
		}
		
		/* Below if condition is executed if user tries to login with FTPs protocol. 
		*/
		if(Protocol.equalsIgnoreCase("FTPS"))
		{
			
			try {
				ftpsclient = new FTPSClient("SSL");
				ftpsclient.setAuthValue("SSL");
				ftpsclient.addProtocolCommandListener((ProtocolCommandListener) new PrintCommandListener(new PrintWriter(System.out)));
				logger.info("connecting to the Host");
				ftpsclient.connect(Host, Port);	
				logger.info("Logging to the server");
				loginstatus = ftpsclient.login(Username, Password);
				logger.info("loginstatus------- "+loginstatus);
				connectionobj.put("loginstatus", loginstatus);
				logger.info(ftpsclient.getReplyString());
				ftpsclient.setBufferSize(1000);
				ftpsclient.execPROT("P");
				//connectionobj.put("loginstatus", loginstatus);
				connectionobj.put("Message", ftpsclient.getReplyString());
				if(loginstatus){
					connectionobj.put("connection", ftpsclient);
					connectionobj.put("protocol", "FTPS");
					connectionobj.put("TID", "Only Login Completed");
					//connectionobj.put("loginstatus", loginstatus);
					
					/*System.out.println("loginstatus->"+loginstatus);*/
					System.out.println("connectionobj->"+connectionobj);
				}
		}catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			logger.info("Exception"+e);
		    connectionobj.put("loginstatus", loginstatus);
			connectionobj.put("TID", "Login Failed");
		   
		}
		}
			
		
		return connectionobj;
	}
	
	
	
	
	
	
	

}
