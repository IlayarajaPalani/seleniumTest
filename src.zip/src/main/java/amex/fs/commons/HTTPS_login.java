package amex.fs.commons;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.zip.ZipOutputStream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HTTPS_login {
	Map<String, Object> connectionobj = new HashMap<String, Object>();
	boolean loginstatus=false;
	//static org.slf4j.Logger  logger;
	WebDriver fdriver;
	static Map loginmap;
	DriverManager dManager;
	
	public HTTPS_login(Logger logger) {
		// TODO Auto-generated constructor stub
	}

	private static org.slf4j.Logger logger=LoggerFactory.getLogger(HTTPS_login.class);
	

	public static void main(String args[]) throws FileNotFoundException
	{
		
		FileOutputStream fos=new FileOutputStream(new File(FrameworkConstants.ScreenShots+"\\G126\\"+"G126.zip"));
		ZipOutputStream zos=new ZipOutputStream(fos); 
		HTTPS_login lg=new HTTPS_login(logger);
		loginmap=lg.HlogintoSFT("Mailuser01","amex123","Firefox",zos);
		
	}
	
	
	public Map<String, Object> HlogintoSFT(String username,String password,String browser,ZipOutputStream zos)
	{
		LoadProperties lp=new LoadProperties(FrameworkConstants.HTTPS_Props);
        String servername=lp.readProperty("server");
		String usernamefield=lp.readProperty("usernamefield");
        String passwordfield=lp.readProperty("passwordfield");
        String login_button=lp.readProperty("login_button");
        try{
        	switch(browser)
        	{
				case "Firefox":
					try
					{
						System.out.println("launching Firefox browser");
						dManager = DriverManager.getDriverManager();
						fdriver= dManager.getWebDriver();
						
						System.out.println(username+":trying to login to sft");
						System.out.println("usernamefield :"+usernamefield);
                
						fdriver.get("https://"+servername);
                
						fdriver.findElement(By.id(usernamefield)).sendKeys(username);
						fdriver.findElement(By.id(passwordfield)).sendKeys(password);
               
						fdriver.findElement(By.id(login_button)).click();
                 
						Thread.sleep(1000);
						connectionobj.put("TID", "No File Uploaded");		
						if (fdriver.findElement(By.tagName("html")).getText().contains("Login failed")) {
							System.out.println("verifyTextPresent true");
							loginstatus=false;
							connectionobj.put("sessionid", dManager.getSessionId());
							connectionobj.put("loginstatus", loginstatus);
							connectionobj.put("fdriver", fdriver);
							logger.info("Invalid User Name or Password");
							System.out.println("Invalid User Name or Password");
						}
						else
						{
							Thread.sleep(FrameworkConstants.SleepValue); 
							logger.info(username+":Sucessfully login to sft");
							logger.info(":Sucessfully login to sft");
							System.out.println(username+":Sucessfully login to sft");
							loginstatus=true;
							connectionobj.put("sessionid", dManager.getSessionId());
							connectionobj.put("loginstatus", loginstatus);
							connectionobj.put("fdriver",fdriver);
							connectionobj.put("browser",browser);
							
							System.out.println("logged in to SFT");
						}
					}catch(NoSuchElementException nse){
						logger.info("Page Not Loaded "+nse.getMessage());
						connectionobj.put("TID", "No File Uploaded");
						} 
                 
					break;                        
        		 
				case "IE":
					break;
				case "GoogleChrome":
					break;
				}
        	
			}catch(NullPointerException e1)
			{   e1.printStackTrace();
				logger.info("unable to proceed:\t"+e1);
                loginstatus=false;
				connectionobj.put("sessionid", dManager.getSessionId());
				connectionobj.put("loginstatus", loginstatus);
				connectionobj.put("fdriver",fdriver);
			}
		catch(NoSuchElementException e2)
		{   
			e2.printStackTrace();
			logger.info("unable to proceed:\t"+e2);
            loginstatus=false;
			connectionobj.put("sessionid", dManager.getSessionId());
			connectionobj.put("loginstatus", loginstatus);
			connectionobj.put("fdriver",fdriver);
        } catch (Throwable e3) {
            e3.printStackTrace();
			logger.info("unable to proceed:\t"+e3);
            loginstatus=false;
			connectionobj.put("sessionid", dManager.getSessionId());
			connectionobj.put("loginstatus", loginstatus);
			connectionobj.put("fdriver",fdriver);
        }
		return connectionobj;
		
	}
	

}
