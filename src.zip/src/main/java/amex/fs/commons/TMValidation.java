package amex.fs.commons;


/*Description:
 * project: NGP Automation.
 * author:  Babu K Barrey
 * This module will perform the search on TM based on the filter supplied and verify the file flow steps provided
 *  
 */
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Parameters;

import sun.net.www.content.audio.x_aiff;

import amex.fs.commons.Download;
import amex.fs.commons.FileComparision;
import amex.fs.commons.FileSizeCheck;
import amex.fs.commons.FrameworkConstants;
import amex.fs.commons.LoadProperties;
import amex.fs.commons.Login;
import amex.fs.commons.Logoff;
import amex.fs.commons.Sentinels;
import amex.fs.commons.TestcaseLookup;
import amex.fs.commons.Upload;
import amex.fs.commons.WriteTestResult;

public class TMValidation
{
	Map<String, Object> TnMSchedule=new HashMap<String, Object>();
	
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(TMValidation.class);
	
	boolean TMstatus = false;	
	String tmurl=null;
	String tmid=null;
	String tmpwd=null;
	String envStatus=null;
	String filterbyname=null;
	String filterbyvalue=null;
	String search=null;
	static String TID="A02HJ4B49015QF";
    static String TMFilterByValue=null;
    WebDriver wd;
    String TMTID=FrameworkConstants.TMTrackingID;
    List <WebElement> l;
    String stepstoverify[];
    String eventTS;
    String TSConv;
    Date today;
    SimpleDateFormat sdftm;
    SimpleDateFormat dt;
    String todaydate;
    SimpleDateFormat sdftoday;
    Date todayft;
    Date tmdate;
    String errmsg;
    
    
	public static void main(String args[]) throws Throwable
	{
		TMValidation tmv=new TMValidation(LoggerFactory.getLogger(TMValidation.class));
		TMFilterByValue=TID;
		//TMFilterByValue="SUB002.NETSNRWY54.A";
		tmv.TNMverify(FrameworkConstants.TMTrackingID, TMFilterByValue,"File Pull from Client,File Catalog,File Push to Client");
		//tmv.TNMverify(FrameworkConstants.TMBaseFileName, TMFilterByValue);
	}
	
	public TMValidation(org.slf4j.Logger logger )
	{
		this.logger=logger;
	}
	  
	public TMValidation()
	{
		
	}

 
	public boolean TNMverify(String TMFilterBy,String TMFilterByValue,String fileflowsteps) throws Throwable
	   {  
		
		LoadProperties lp = new LoadProperties(FrameworkConstants.TMProperties);
		tmurl=lp.readProperty("tmurl");
		tmid=lp.readProperty("tmid");
		tmpwd=lp.readProperty("tmpwd");
		envStatus=lp.readProperty("envStatus_name");
		filterbyname=lp.readProperty("filterBy_name");
		filterbyvalue=lp.readProperty("filterByValue_name");
		search=lp.readProperty("search_name");
		
		System.out.println("connecting to IE");
		System.setProperty("webdriver.ie.driver", "./drivers./IEDriverServer.exe");
		wd= new InternetExplorerDriver();
		wd.manage().window().maximize();
		

		wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		logger.info("login to TM");
		System.out.println("connected to TM");
		System.out.println("opening TM");
		wd.navigate().to(tmurl);
		
		wd.findElement(By.id("textboxuid_AD")).click();
		wd.findElement(By.id("textboxuid_AD")).clear();
		wd.findElement(By.id("textboxuid_AD")).sendKeys(tmid);
		wd.findElement(By.id("textboxpwd_AD")).click();
		wd.findElement(By.id("textboxpwd_AD")).clear();
		wd.findElement(By.id("textboxpwd_AD")).sendKeys(tmpwd);
		wd.findElement(By.id("Login")).click();
		wd.findElement(By.id("NavigationButton2")).click();
		
		logger.info("login successful");
		
		stepstoverify= fileflowsteps.split(",");
		//int k=stepstoverify.length;
		

		//test radio button
		List <WebElement> envTSConv= wd.findElements(By.name(envStatus));
		Thread.sleep(2000);
		envTSConv.get(0).click();
		
		Select filterby;
		
		switch(TMFilterBy)
		{
		case FrameworkConstants.TMTrackingID:
				filterby= new Select(wd.findElement(By.name(filterbyname)));
				filterby.selectByVisibleText(FrameworkConstants.TMTrackingID);
				wd.findElement(By.name(filterbyvalue)).sendKeys(TMFilterByValue);
				wd.findElement(By.name(search)).click();
				errmsg=wd.findElement(By.className("redMessage")).getText();
				System.out.println(errmsg);
				if(!errmsg.contains("No matching results found. You may refine search criteria and Retry "))
				{
					if(tmTimeStampCheck())
					{
						TMstatus=true;
					}
				}else
				{
					TMstatus=false;
					logger.info("No Macthing results found for TrackingId");
				}
				
				break;
		case FrameworkConstants.TMBaseFileName :
				filterby= new Select(wd.findElement(By.name(filterbyname)));
				filterby.selectByVisibleText(FrameworkConstants.TMBaseFileName);
				wd.findElement(By.name(filterbyvalue)).sendKeys(TMFilterByValue);
				wd.findElement(By.name(search)).click();
				errmsg=wd.findElement(By.className("redMessage")).getText();
				if(!errmsg.contains("No matching results found. You may refine search criteria and Retry "))
				{
					if(tmTimeStampCheck())
					{
						TMstatus=true;
					}
				}else
				{
					TMstatus=false;
				}
				
				logger.info("No Macthing results found for Basefilename");
				break;
		
		default:
			 logger.info("Undefined Filter in Tracking/Monitoring" + TMFilterBy);	
			 break;
			
		}
		
		return TMstatus;
	
	
    }
	
public boolean sftTMStatus()
{
  try
  {
	l=wd.findElements(By.id("Picture14"));
	l.get(0).click();
	Thread.sleep(3000);
	
	System.out.println(wd.findElement(By.xpath(".//*[@id='SFTBUTTONLYR']/tbody/tr[3]/td[3]/a/p/font")).getText());
	List <WebElement> rows= wd.findElements(By.xpath(".//*[@id='SFTBUTTONLYR']/tbody/tr"));
	
	System.out.println("rows" +rows.size());
	int j=0;
	for(int i=3;i<=rows.size();i++)
	{
		String FFtext= wd.findElement(By.xpath(".//*[@id='SFTBUTTONLYR']/tbody/tr["+i+"]/td["+3+"]/a/p/font")).getText();
		
		if(FFtext.equals(stepstoverify[j]))
		{
			String FFstatus= wd.findElement(By.xpath(".//*[@id='SFTBUTTONLYR']/tbody/tr["+i+"]/td["+5+"]/p/font")).getText();
			
			if(FFstatus.trim().equals("Completed"))
			{
				TMstatus=true;
				logger.info(FFtext+" "+FFstatus);
			}else
			{
				logger.info(FFtext+" "+FFstatus);
				TMstatus=false;
				break;
			}
			
			/*System.out.println(FFtext);
			System.out.println(FFstatus);*/
			
		}else
		{
			logger.info(FFtext+" File Flow Step did not match");
			TMstatus=false;
			break;
		}
		j++;
		
	}
  }catch(Exception e){
		logger.info("TMValidation : + Exception occurred "+e.getMessage());
		TMstatus=false;
		
  }
  if(TMstatus)
  {
	  return true;
  }else
  {
	  return false;
  }
	  

}
	
public boolean tmTimeStampCheck() 
{
	try
	{
	eventTS=wd.findElement(By.xpath(".//*[@id='FileResult']/tbody/tr[2]/td[4]/p/font")).getText();
	TSConv=eventTS.replace(".", ":");
	eventTS=TSConv+".000";
	
	System.out.println(eventTS);
	System.out.println(TSConv);
	
	today=new Date();

	dt=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
	todaydate=dt.format(today);

	sdftm =  new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss.SSS");
	sdftoday =  new SimpleDateFormat ("yyyy-MM-dd HH:mm:ss.SSS");

	System.out.println(todaydate);
	todayft=sdftoday.parse(todaydate);
	tmdate=sdftm.parse(eventTS);

	if(tmdate.after(todayft))
	{
		System.out.println("TM Date is After Today Date");
		if(sftTMStatus())
		{
			return true;
		}
	}else
	{
		System.out.println("TM Date is before Today Date");
		Thread.sleep(5000);
		if(sftTMStatus())
		{
			return true;
		}
	}

	System.out.println("Current Date: " + sdftm.format(today));
	}catch(Exception e)
	{
		logger.info("TMValidation : Exception occured while verifying in TM"+e.getMessage());
		return false;
	}
	return false;
}

}
