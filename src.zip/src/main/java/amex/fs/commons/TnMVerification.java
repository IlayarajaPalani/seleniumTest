package amex.fs.commons;



/*Description:
 * project: NGP Automation.
 * author: Viren Tiwari.
 * file will be verified at the T&M   . 
 */

import java.util.Map;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;





import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.LoggerFactory;





	public class TnMVerification{
		boolean teststatus=false;
		public static org.slf4j.Logger logger = LoggerFactory.getLogger(TnMVerification.class);
		 boolean TMVerification_status = false;	
		 
		 
		  /* Main method which takes the parameter from the testng.xml
			  * 
			  */
		
		
			
		public static void main(String[] args) throws Throwable
		{
			TnMVerification fg = new TnMVerification();
			
				
			boolean temp1= fg.TnMVerify( "P32HAH351177TQ",null,null,"https://central930.intra.aexp.com/TPWeb/SearchTransmitterProfile.do","vtiwa25","viren9893$","Failed");
		
			System.out.println(temp1);
				
				
		}
		
		
		
	
		 public boolean TnMVerify(String TID,String SFTuser,String Basefilename ,String url,String userid,String password ,String status) throws Throwable
		    {
		       try{    System.out.println("connecting to firefox");
		       
		           FirefoxProfile profile1 = new FirefoxProfile();  
		           profile1.setPreference("network.proxy.type",4);
		           
		           
		           WebDriver wd= new FirefoxDriver(profile1);
		           
		           wd.manage().window().maximize();
		           
		     wd.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		     //login to the TP
		     logger.info("login to TM");
		     System.out.println("connected to TM");
		     System.out.println("opening TM");
		     wd.get(url);
		     wd.findElement(By.id("textboxuid_AD")).click();
		     wd.findElement(By.id("textboxuid_AD")).clear();
		     wd.findElement(By.id("textboxuid_AD")).sendKeys(userid);
		     wd.findElement(By.id("textboxpwd_AD")).click();
		     wd.findElement(By.id("textboxpwd_AD")).clear();
		     wd.findElement(By.id("textboxpwd_AD")).sendKeys(password);
		     wd.findElement(By.id("Login")).click();
		     wd.findElement(By.id("NavigationButton2")).click();
		     logger.info("login successful");
		     System.out.println("login successful");
		     //Navigate to TnM
		     
		     if (!wd.findElement(By.id("NavigationButton2")).isSelected()) {
		    	 wd.findElement(By.id("NavigationButton2")).click();
		     }
		     switch(status)
		     {//for Failed test status
		     case  "Failed":
		    	//select the test radio button
		    	 if (!wd.findElement(By.xpath("/html/body/table[3]/tbody/tr[1]/td[3]/form/table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/font/input[2]")).isSelected()) {
			         wd.findElement(By.xpath("/html/body/table[3]/tbody/tr[1]/td[3]/form/table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/font/input[2]")).click();
			     }
		    	//filtered by tracking ID
			     if (!wd.findElement(By.xpath("//table[@id='Table6']/tbody/tr[3]/td/table/tbody/tr[2]/td[1]/p/font/select//option[5]")).isSelected()) {
			         wd.findElement(By.xpath("//table[@id='Table6']/tbody/tr[3]/td/table/tbody/tr[2]/td[1]/p/font/select//option[5]")).click();
			     }
			     Thread.sleep(FrameworkConstants.SleepValue); 
			     wd.findElement(By.name("filterByValue")).click();
			     wd.findElement(By.name("filterByValue")).clear();
			     wd.findElement(By.name("filterByValue")).sendKeys(TID);
			   
			    
			     Thread.sleep(FrameworkConstants.SleepValue); 
			     
			   //Search  by tracking ID
			     wd.findElement(By.name("search")).click();
			     wd.findElement(By.id("Picture14")).click();
			    
			     Thread.sleep(FrameworkConstants.SleepValue); 
			     wd.findElement(By.xpath("//div[@id='SFTBUTTONLYR']/layer/table/tbody/tr[5]/td[3]/a/p/font")).click();
			   Boolean temp= wd.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[3]/form/div[5]/layer/table[2]/tbody/tr[3]/td[1]/p/font")).getText().contains("Failed");
			 System.out.println("problem:");
			   
			   if(temp==true)
			   {
				   System.out.println("passed");
				   TMVerification_status =true;
				   logger.info(" failed to push a file ");
				  String temp1= wd.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[3]/form/div[5]/layer/table[2]/tbody/tr[3]/td[5]/p")).getText();
				
				  System.out.println(temp1);
				  logger.info("Error Message /t"+temp1 );
			   }
			   else{
				   System.out.println("failed");
				   TMVerification_status =false;
				   logger.info("test case is failed");
			   }
			  break;
			  
			//for Suspend test status
		     case  "Suspend":
		    	  if (!wd.findElement(By.xpath("//table[@id='Table6']/tbody/tr[3]/td/table/tbody/tr[2]/td[1]/p/font/select//option[2]")).isSelected()) {
				         wd.findElement(By.xpath("//table[@id='Table6']/tbody/tr[3]/td/table/tbody/tr[2]/td[1]/p/font/select//option[2]")).click();
				     }
		    	//filtered by tracking ID
			     wd.findElement(By.name("filterByValue")).click();
			     wd.findElement(By.name("filterByValue")).clear();
			     wd.findElement(By.name("filterByValue")).sendKeys(TID);
			   
			     Thread.sleep(FrameworkConstants.SleepValue); 
	             
			     
			     //Search  by tracking ID
			     wd.findElement(By.name("search")).click();
			     wd.findElement(By.id("Picture14")).click();
			    
			     Thread.sleep(FrameworkConstants.SleepValue); 
			      temp= wd.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[3]/form/div[5]/layer/table[2]/tbody/tr[2]/td[1]/p/font")).getText().contains("Suspend");
				   if(temp==true)
				   {
					   System.out.println("passed");
					   TMVerification_status =true;
					   logger.info("file is suspended due to configuration");
					  String temp1= wd.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[3]/form/div[5]/layer/table[2]/tbody/tr[2]/td[5]/p")).getText();
					  System.out.println(temp1);
					  logger.info("Error Message /t"+temp1 );
				   }
				   else{
					   System.out.println("failed");
					   TMVerification_status =false;
					   logger.info("test case is failed");
				   }
				
				     
			     break;
			   //for Completed test status
		     case  "Completed":
		    	 Thread.sleep(FrameworkConstants.SleepValue); 
		    	//select the test radio button
		    	 if (!wd.findElement(By.xpath("/html/body/table[3]/tbody/tr[1]/td[3]/form/table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/font/input[2]")).isSelected()) {
			         wd.findElement(By.xpath("/html/body/table[3]/tbody/tr[1]/td[3]/form/table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td/font/input[2]")).click();
			     }
		    	 Thread.sleep(FrameworkConstants.SleepValue); 
		    	//filtered by tracking ID
		    	   if (!wd.findElement(By.xpath("//table[@id='Table6']/tbody/tr[3]/td/table/tbody/tr[2]/td[1]/p/font/select//option[2]")).isSelected()) {
				         wd.findElement(By.xpath("//table[@id='Table6']/tbody/tr[3]/td/table/tbody/tr[2]/td[1]/p/font/select//option[2]")).click();
				     }
				     wd.findElement(By.name("filterByValue")).click();
				     wd.findElement(By.name("filterByValue")).clear();
				     wd.findElement(By.name("filterByValue")).sendKeys(TID);
				   
				    
				     Thread.sleep(FrameworkConstants.SleepValue); 
				     
				     //Search  by tracking ID
				     wd.findElement(By.name("search")).click();
				     wd.findElement(By.id("Picture14")).click();
				     Thread.sleep(FrameworkConstants.SleepValue); 
				     wd.findElement(By.xpath("//div[@id='SFTBUTTONLYR']/layer/table/tbody/tr[5]/td[3]/a/p/font")).click();
				    temp= wd.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[3]/form/div[5]/layer/table[2]/tbody/tr[2]/td[1]/p/font")).getText().contains("Completed");
				 System.out.println("problem:");
				   
				   if(temp==true)
				   {
					   System.out.println("passed");
					   TMVerification_status =true;
					   logger.info("file is suspended due to configuration");
					  String temp1= wd.findElement(By.xpath("/html/body/table[3]/tbody/tr/td[3]/form/div[5]/layer/table[2]/tbody/tr[2]/td[5]/p")).getText();
					
					  System.out.println(temp1);
					  logger.info(" Message: /t"+temp1 );
				   }
				   else{
					   System.out.println("failed");
					   TMVerification_status =false;
					   logger.info("test case is failed");
				   }
			   break;
			   
		     default:
		    	 System.out.println("please check the status:");
		    	 logger.info("please check the status");
		    	 TMVerification_status=false;
		    	 break;
		     }
		     
		   logger.info("logoff from TM");
		     wd.findElement(By.name("logoutTM")).click();
		     Thread.sleep(FrameworkConstants.SleepValue); 
		     wd.quit();
		    
		           
		           
		           if( TMVerification_status)
		           {
		                  System.out.println(" the delivery is completed");
		           }
		           else
		           {
		                  System.out.println("the delivery got failed");
		           }
		    }
		           catch(NullPointerException e1)
			        {   e1.printStackTrace();
			        	logger.info("unable to proceed:\t"+e1);
			        	TMVerification_status=false;
			        	
			        }
			        catch(NoSuchElementException e2)
			        {   
			        	e2.printStackTrace();
			        	logger.info("unable to proceed:\t"+e2);
			        	TMVerification_status=false;
			        } catch (Throwable e3) {
						
						e3.printStackTrace();
			        	logger.info("unable to proceed:\t"+e3);
			        	TMVerification_status=false;

					}
			
		           
		           return TMVerification_status;
		           
		           
		    }}