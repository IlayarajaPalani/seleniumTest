/*Description: This program is used to logoff from the user using FTP and FTPs user.
*/

package amex.fs.commons;

import java.io.IOException;
import java.util.Map;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPSClient;

public class Logoff {
	FTPSClient ftpsclient = null;
	FTPClient ftpclient = null;
	boolean logoffstatus = false;
	public static org.slf4j.Logger  logger;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Login lg = new Login(logger);
		Map connectionobj = lg.logintoSFT("fsgatewaytest.intra.aexp.com", 21, "G1FTPUser", "amex123", "FTP");
		System.out.println(connectionobj);
		Logoff lgoff = new Logoff(logger);
		try {
			lgoff.logofffromSFT(connectionobj);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public Logoff(org.slf4j.Logger logger )
	{
		Logoff.logger=logger;
	}
	public boolean logofffromSFT(Map connectionobj) throws IOException{
		
		if(connectionobj.get("protocol").equals("FTP") && connectionobj.get("connection")!= null){
			ftpclient = (FTPClient) connectionobj.get("connection");
			logoffstatus = ftpclient.logout();
			
		}
		if(connectionobj.get("protocol").equals("FTPS") && connectionobj.get("connection")!= null){
			ftpsclient = (FTPSClient) connectionobj.get("connection");
			logoffstatus = ftpsclient.logout();
		}
		logger.info("logoffstatus        "+logoffstatus);
	System.out.println("Logoff status---------------> "+logoffstatus);
	return logoffstatus;	
	}

}
