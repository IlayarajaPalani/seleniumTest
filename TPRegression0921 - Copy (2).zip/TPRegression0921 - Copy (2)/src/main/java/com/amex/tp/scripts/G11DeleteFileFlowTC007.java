package com.amex.tp.scripts;

//Description - delete a file flow with Catalog and encryption

import java.io.File;
import java.io.FileOutputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipOutputStream;

import org.openqa.selenium.WebDriver;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import bsh.ParseException;

import com.amex.tp.common.CreateZip;
import com.amex.tp.common.FrameworkConstants;
import com.amex.tp.common.LoadProperties;
import com.amex.tp.common.ScreenShot;
import com.amex.tp.common.TP_Login;
import com.amex.tp.common.TestcaseLookup;
import com.amex.tp.common.WriteTestResult;
import com.amex.tp.common.commandManager;

@Test
public class G11DeleteFileFlowTC007 {

	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G11DeleteFileFlowTC007.class);

	Map<String, Object> connectionmap;
	ScreenShot screenPrint;
	String runIdFile;
	List<String> testCaseList;
	WriteTestResult wtr;
	WebDriver fdriver;
	String filePath = FrameworkConstants.ScreenShots + "/G11DeleteFileFlowTC007/G11DeleteFileFlowTC007.zip";
	String screenshotname;
	int screenshotnumber = 1;
	String loginscreenshot;
	File folder;
	CreateZip zipfile = null;
	ZipOutputStream zos = null;
	FileOutputStream fos = null;
	boolean testCasesucessFlag=false;
	commandManager cmd;

	@Parameters({ "TestCaseName", "Browser" })
	public void addFileFlow(String tcname, String browser) throws InterruptedException,ParseException, Throwable {

		LoadProperties lp = new LoadProperties(FrameworkConstants.G11_Props);
		String tcid = ""; cmd=commandManager.getInstance(browser,tcid);

		try {
			folder = new File(FrameworkConstants.ScreenShots + "/G11DeleteFileFlowTC007");

			if (folder.mkdir()) {
				// System.out.println("Directory is created!");
				logger.info("Group Folder Created");
			} else {
				logger.info("Directory Already Exists. Results will be added to the existing folder.");
				// System.out.println("Directory Already Exists!");
			}
		} catch (Exception e) {
			logger.info("Group Folder Creation Failed");
			// System.out.println("exception is:"+ e);
		}

		try {
			TP_Login tp = new TP_Login(logger,browser,cmd);;
			connectionmap = tp.HlogintoTP(browser, zos);
			fdriver = (WebDriver) connectionmap.get("fdriver");
			screenPrint = new ScreenShot();
			screenshotname = tcname + "_" + screenshotnumber;
			System.out.println("Screenshot: " + screenshotname);
			System.out.println(folder.getAbsolutePath());
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);

			System.out.println("The  screen shot " + screenshotnumber+ " got added");
			logger.info("The  screen shot " + screenshotnumber + " got added");
			Thread.sleep(FrameworkConstants.SleepValue);
			
			System.out.println(" *** Add File flow with Catalog and Encryption step is started ***");
			
			cmd.click(".//*[@id='menu']/dl[5]/dt/img", "xpath");//click on Maintain File Flow
			
			cmd.click(".//*[@id='smenu2']/a[2]/img", "xpath");//Click on Add File Flow
			String FileFlowName = lp.readProperty("G11DeleteFF007_fileflowname")+System.currentTimeMillis();
			cmd.type("fileFlowName", "name",FileFlowName);
			cmd.type("description", "name",lp.readProperty("G11DeleteFF007_description"));
			cmd.selectByValue("owner", "name", lp.readProperty("G11DeleteFF007_owner"));
			  
			screenshotname=tcname+"_"+screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			System.out.println("add file flow main screen steps completedted -- ");
			screenshotnumber++;
			
			cmd.click("AddNewStepType", "name");
			logger.info("Select Catalog");
			cmd.selectByValue("stepTypeCd", "name", lp.readProperty("G11DeleteFF007_catalog"));
			logger.info("Click on Check Box");
			cmd.click("fileEncDecStatusChkBox", "name");
			logger.info("Click on Enable Radio Button");
			cmd.click("html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td[2]/label[1]/input", "xpath");
			
			cmd.selectByValue("encryptionPackageCd", "name", lp.readProperty("G11DeleteFF007_PGP"));
			cmd.selectByValue("authenticationTypeCd", "name", lp.readProperty("G11DeleteFF007_authenticationTypeCd"));
			
			if(lp.readProperty("G11DeleteFF007_signatureSelected").equals("Yes"))
				cmd.click("html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[7]/td/div/table/tbody/tr[6]/td/table/tbody/tr/td[2]/input[1]", "xpath");// click on Yes Radio button
			else
				cmd.click("html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[7]/td/div/table/tbody/tr[6]/td/table/tbody/tr[1]/td[2]/input[2]", "xpath");// click on No Radio button
			
			if(lp.readProperty("G11DeleteFF007_advOptionsSelected").equals("Yes"))
				cmd.click("html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[7]/td/div/table/tbody/tr[6]/td/table/tbody/tr[4]/td[2]/input[1]", "xpath");// click on Yes Radio button
			else
				cmd.click("html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[7]/td/div/table/tbody/tr[6]/td/table/tbody/tr[4]/td[2]/input[2]", "xpath");// click on No Radio button
			
			cmd.click("html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[7]/td/div/table/tbody/tr[6]/td/table/tbody/tr[10]/td[2]/input", "xpath");  // click on Generate key button
			cmd.type("password", "name",lp.readProperty("G11DeleteFF007_password"));
			cmd.type("confirmPassword", "name",lp.readProperty("G11DeleteFF007_password"));
			
			screenshotname = tcname + "_" + screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			System.out.println("add Add New StepType screen steps completed  --  ");
			
			logger.info("Click on OK  Button");
			cmd.click("html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[14]/td/input[1]", "xpath");
			
			screenshotname = tcname + "_" + screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			System.out.println("add file flow with AddNew StepType screen steps completed");
			
			logger.info("Click on Save Button");
			cmd.click("html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td/input[2]", "xpath");
			
			screenshotname = tcname + "_" + screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			System.out.println("File Flow added successfully screen step completed");
			
			String Succmsg = cmd.getContent("html/body/table[2]/tbody/tr/td[2]/form/div[2]/table[1]/tbody/tr/td[3]/font", "xpath");
			if(Succmsg.contains("***File Flow added successfully*** ***Replication verification is successful***")){
			  System.out.println("File Flow Added Successfully");
			  testCasesucessFlag=true;
			}else{
			  System.out.println("Add File Flow Test Failed");
			}
			
			System.out.println("Add a file flow with Catalog and encryption is completed");
			
			
			
			System.out.println("Delete a file flow with Catalog and encryption is started");
			cmd.click("/html/body/table[2]/tbody/tr/td[1]/form/div/dl[5]/dt/img", "xpath");
			cmd.click("/html/body/table[2]/tbody/tr/td[1]/form/div/dl[5]/dd/a[1]/img", "xpath");
			cmd.type("fileFlowName", "name", FileFlowName);

			screenshotname=tcname+"_"+screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td/input[1]", "xpath"); //search button


			screenshotname = tcname + "_" + screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);

			cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td/table/tbody/tr[3]/td[4]/a/img", "xpath");

     	   String parentWindowHandler = fdriver.getWindowHandle(); //This code represents the control is with current window.
		       String subWindowHandler = null; 
		       Set<String> handles = fdriver.getWindowHandles();
		       java.util.Iterator<String> iterator = handles.iterator();
		      while (iterator.hasNext()){
		    	  if(subWindowHandler=="Confirm"){
	     		       fdriver.switchTo().window(subWindowHandler); // Control is shifted to Pop up
	     		       }
	     		       else
	     		       {
	     		    	  subWindowHandler = iterator.next();
	     		    	  fdriver.switchTo().window(subWindowHandler);
	     		       }
		       }

		    fdriver.switchTo().window(subWindowHandler);
		    Thread.sleep(FrameworkConstants.SleepValue);
     	cmd.click("html/body/table/tbody/tr[2]/td/button[1]", "xpath"); // Do actions in the pop up window.
     	logger.info("Confirmed");
     	fdriver.switchTo().window(parentWindowHandler); // Instructing the driver to move the control to the Parent window
		       
			String Succmsg1 = cmd.getContent("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table[1]/tbody/tr/td[3]/font", "xpath");
			System.out.println(Succmsg);
			if(Succmsg1.contains("**FileFlow is deleted successfully*** ***Replication verification is successful***")){
				logger.info("G11DeleteFileFlowTC007 - delete a file flow with Catalog and encryption is succeeded");
				testCasesucessFlag=true;
			}else{ 
				logger.info("G11DeleteFileFlowTC007 - delete a file flow with Catalog and encryption is failed");
				testCasesucessFlag=false;
			}

			screenshotname = tcname + "_" + screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);

			//cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			logger.info("Logging out from the Application");
			cmd.click("//img[contains(@src, 'Logout.jpg')]", "xpath");
			fdriver.switchTo().alert().accept();
			Thread.sleep(3000);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Test Case Failed");
			//cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			logger.info("Logging out from the Application");
			cmd.click("//img[contains(@src, 'Logout.jpg')]", "xpath");
			fdriver.switchTo().alert().accept();
			cmd.wait(5000);
			Assert.fail(e.getMessage());

		}finally{

		TestcaseLookup tl = new TestcaseLookup(logger);
		testCaseList = tl.lookupTestcase(FrameworkConstants.TCLookup,
				"G11DeleteFileFlowTC007");
		LoadProperties lp1 = new LoadProperties(FrameworkConstants.RunIdFile);
		runIdFile = (lp1.readProperty("RUNID"));
		wtr = new WriteTestResult();

		if (testCasesucessFlag) {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating " + testCaseList.get(i)
						+ " status as Passed");

				wtr.writeToFile(runIdFile,
						"G11DeleteFileFlowTC007," + testCaseList.get(i) + ",Passed");
			}
		} else {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating" + testCaseList.get(i) + "status as Failed");

				wtr.writeToFile(runIdFile,"G11DeleteFileFlowTC007," + testCaseList.get(i) + ",Failed");
			}

		}

	}
	}
}