package com.amex.tp.common;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.zip.ZipOutputStream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class TP_Login_Viewer {
	Map<String, Object> connectionobj = new HashMap<String, Object>();
	boolean loginstatus=false;
	//WebDriver fdriver;
	static Map loginmap;
	DriverManager dManager;
	static commandManager cmd;
	static String browser;
	
	public TP_Login_Viewer(Logger logger, String browser,commandManager cmd) {
		
		this.browser = browser;
		this.cmd = cmd;
		// TODO Auto-generated constructor stub
	}

	private static org.slf4j.Logger logger=LoggerFactory.getLogger(TP_Login.class);
	

	public static void main(String args[]) throws Exception
	{
		
		FileOutputStream fos=new FileOutputStream(new File(FrameworkConstants.ScreenShots+"\\G1\\"+"G1.zip"));
		ZipOutputStream zos=new ZipOutputStream(fos);
		
		
		TP_Login_Viewer lg=new TP_Login_Viewer(logger,browser,cmd);
		loginmap=lg.HlogintoTP_viewer(browser,zos);
		
	}
	
	
	public Map<String, Object> HlogintoTP_viewer(String browser,ZipOutputStream zos) throws Exception
	{
		LoadProperties lp=new LoadProperties(FrameworkConstants.TP_Props);
        String servername=lp.readProperty("server");
		String username=lp.readProperty("tpuser_viewer");
        String password=lp.readProperty("tppwd_viewer");
        String login_button=lp.readProperty("login_button");
        //String tcid = ""; cmd=commandManager.getInstance(browser,tcid);
        try{
        	
						cmd.open("https://"+servername);
						System.out.println("https://"+servername);
						cmd.type("textboxuid_AD", "id", username);
						cmd.type("textboxpwd_AD", "id", password);
						cmd.click("Login", "id");
						/*fdriver.findElement(By.id("textboxuid_AD")).clear();
						fdriver.findElement(By.id("textboxuid_AD")).sendKeys(username);
						fdriver.findElement(By.id("textboxpwd_AD")).clear();
						fdriver.findElement(By.id("textboxpwd_AD")).sendKeys(password);*/
	           			//fdriver.findElement(By.id(login_button)).click();
						//connectionobj.put("sessionid", dManager.getSessionId());
						connectionobj.put("loginstatus", loginstatus);
						connectionobj.put("fdriver", cmd.fdriver);
						
						Thread.sleep(1000);
						System.out.println(username+":Logged into TP successfully");

        	
			}catch(NullPointerException e1)
			{   e1.printStackTrace();
				logger.info("unable to proceed:\t"+e1);
                loginstatus=false;
				//connectionobj.put("sessionid", dManager.getSessionId());
				connectionobj.put("loginstatus", loginstatus);
				connectionobj.put("fdriver",cmd.fdriver);
			}
		catch(NoSuchElementException e2)
		{   
			e2.printStackTrace();
			logger.info("unable to proceed:\t"+e2);
            loginstatus=false;
			//connectionobj.put("sessionid", dManager.getSessionId());
			connectionobj.put("loginstatus", loginstatus);
			connectionobj.put("fdriver",cmd.fdriver);
        } catch (Throwable e3) {
            e3.printStackTrace();
			logger.info("unable to proceed:\t"+e3);
            loginstatus=false;
			//connectionobj.put("sessionid", dManager.getSessionId());
			connectionobj.put("loginstatus", loginstatus);
			connectionobj.put("fdriver",cmd.fdriver);
        }
		return connectionobj;
		
	}
	

}
