package com.amex.tp.scripts;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Set;
import java.util.zip.ZipOutputStream;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import bsh.ParseException;

import com.amex.tp.common.CreateZip;
import com.amex.tp.common.FrameworkConstants;
import com.amex.tp.common.LoadProperties;
import com.amex.tp.common.ScreenShot;
import com.amex.tp.common.TP_Login;
import com.amex.tp.common.TestcaseLookup;
import com.amex.tp.common.WriteTestResult;
import com.amex.tp.common.commandManager;

@Test
public class G6EditFileFlowTC013 {

	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G6EditFileFlowTC013.class);

	Map<String, Object> connectionmap;
	ScreenShot screenPrint;
	String runIdFile;
	List<String> testCaseList;
	WriteTestResult wtr;
	WebDriver fdriver;
	String filePath = FrameworkConstants.ScreenShots
			+ "/G6EditFileFlowTC013/G6EditFileFlowTC013.zip";
	String screenshotname;
	int screenshotnumber = 1;
	String loginscreenshot;
	File folder;
	CreateZip zipfile = null;
	ZipOutputStream zos = null;
	FileOutputStream fos = null;
	boolean testCasesucessFlag=false;
	boolean testCasesucessFlag1=false;
	commandManager cmd;
	
	String s,s1;

	@Parameters({ "TestCaseName", "Browser" })
	public void addFileFlow(String tcname, String browser) throws InterruptedException,ParseException, Throwable {

		LoadProperties lp = new LoadProperties(FrameworkConstants.G6_Props);
		String tcid = ""; cmd=commandManager.getInstance(browser,tcid);

		try {
			folder = new File(FrameworkConstants.ScreenShots
					+ "/G6EditFileFlowTC013");

			if (folder.mkdir()) {
				// System.out.println("Directory is created!");
				logger.info("Group Folder Created");
			} else {
				logger.info("Directory Already Exists. Results will be added to the existing folder.");
				// System.out.println("Directory Already Exists!");
			}
		} catch (Exception e) {
			logger.info("Group Folder Creation Failed");
			// System.out.println("exception is:"+ e);
		}

		try {
			TP_Login tp = new TP_Login(logger,browser,cmd);
			connectionmap = tp.HlogintoTP(browser, zos);
			fdriver = (WebDriver) connectionmap.get("fdriver");
			screenPrint = new ScreenShot();
			screenshotname = tcname + "_" + screenshotnumber;
			System.out.println("Screenshot: " + screenshotname);
			System.out.println(folder.getAbsolutePath());
			Thread.sleep(FrameworkConstants.SleepValue);
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			System.out.println("The  screen shot " + screenshotnumber+ " got added");
			screenshotnumber++;
			
			
			
			logger.info("search maintain file flow");
			cmd.click("/html/body/table[2]/tbody/tr/td[1]/form/div/dl[5]/dt/img", "xpath");
			
			logger.info("search fileflow");
			cmd.click("/html/body/table[2]/tbody/tr/td[1]/form/div/dl[5]/dd/a[1]/img", "xpath");
			
			
			logger.info("enter the file flow");
			cmd.type("fileFlowName", "name",(lp.readProperty("G6EditFFTC013_fileflowname")));
			
			logger.info("Select owner from DropDown");
			cmd.selectByText("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[2]/select", "xpath", (lp.readProperty("G6EditFFTC013_Owner")));
			logger.info("Click on Search Button");
			cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td/input[1]", "xpath");
			logger.info("Click on the Searched File Flow Anchor text");
			cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td/table/tbody/tr[3]/td[1]/a", "xpath");
			logger.info("Click on Edit Button to edit the File Flow");
			cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td/input[1]", "xpath");
			
			screenshotname=tcname+"_"+screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			System.out.println("Edit file flow main screen steps completed -- "+G6EditFileFlowTC012.class);
			
		
			if(fdriver.findElement(By.name("AddNewStepType")).isEnabled())
			{System.out.println("Add STep Button is enabled");}else
			{
				testCasesucessFlag1=true;
				System.out.println("Add Step Button is disabled for a file flow which is already attached to an inbound file");}
			logger.info("click on X icon (Delete) icon next to Mailbox Anchor text");
			cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td/table/tbody/tr[4]/td[3]/a[2]/img", "xpath");
			Thread.sleep(FrameworkConstants.SleepValue);
			
			Alert alert = fdriver.switchTo().alert();
			String s=alert.getText();
		    alert.accept();
			
			logger.info("click on mail box");
			cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td/table/tbody/tr[4]/td[2]/a", "xpath");
			logger.info("click on edit");
			cmd.click("//*[@value='Edit']", "xpath");
			logger.info("Click on Destination Transmitter Name - Trying to edit some details");
			cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[2]/font/input", "xpath");
			Thread.sleep(FrameworkConstants.SleepValue);
			
			
			Alert alert1 = fdriver.switchTo().alert();
			String s1=alert.getText();
			alert1.accept(); // Click Ok
			logger.info("Click on Cancel Button");
			cmd.click("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[8]/td/input[2]", "xpath");
			
			 	
   if((testCasesucessFlag1==true) && (s.equals("cannot delete step")) && (s1.equals("cannot edit field")) )
		         
	         {
	        	 testCasesucessFlag=true;
	        	
	         }
			
			 else
			 {
				 System.out.println(" failed....");
			 }
				screenshotname=tcname+"_"+screenshotnumber;
				screenshotnumber++;
				screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
				System.out.println("Edit file flow main screen steps completed -- "+G6EditFileFlowTC012.class);
				
			cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			fdriver.switchTo().alert().accept();
			Thread.sleep(3000);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Test Case Failed");
			cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			fdriver.switchTo().alert().accept();
			cmd.wait(5000);
			Assert.fail(e.getMessage());
		
		}
		finally	{
		TestcaseLookup tl = new TestcaseLookup(logger);
		testCaseList = tl.lookupTestcase(FrameworkConstants.TCLookup, "G6EditFileFlowTC013");
		LoadProperties lp1 = new LoadProperties(FrameworkConstants.RunIdFile);
		runIdFile = (lp1.readProperty("RUNID"));
		wtr = new WriteTestResult();

		if (testCasesucessFlag) {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating " + testCaseList.get(i)
						+ " status as Passed");

				wtr.writeToFile(runIdFile, "G6EditFileFlowTC013," + testCaseList.get(i) + ",Passed");
			}
		} else {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating" + testCaseList.get(i) + "status as Failed");

				wtr.writeToFile(runIdFile,"G6EditFileFlowTC013," + testCaseList.get(i) + ",Failed");
			}

		}
		}
	}
	
}