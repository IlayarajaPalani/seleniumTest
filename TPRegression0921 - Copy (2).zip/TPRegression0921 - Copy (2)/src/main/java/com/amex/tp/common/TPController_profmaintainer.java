package com.amex.tp.common;

import java.io.IOException;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.testng.TestNG;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;
import org.testng.collections.Lists;



public class TPController_profmaintainer {
  @Test
  public void main() throws IOException, JAXBException {
	  
	 // TestListenerAdapter tla = new TestListenerAdapter();
	 // BasicConfigurator.configure();
	  System.out.println("Automated testng xml creation starts here");
	  TestNG tng = new TestNG();
	  List<String> suites = Lists.newArrayList();
	  RunId rd= new RunId();
	  rd.generateRunId_profmaintainer();
	  XMLGen dynamicxml=new XMLGen(true);
	  String packname = FrameworkConstants.Pack2;
	  dynamicxml.readExcel(FrameworkConstants.ExecutionSheet_Profmaintainer, "testngprofmaintainer.xml",packname);
	  
	  suites.add("testngprofmaintainer.xml");
	   
	 tng.setTestSuites(suites);
	 tng.run();
  }
 
}

