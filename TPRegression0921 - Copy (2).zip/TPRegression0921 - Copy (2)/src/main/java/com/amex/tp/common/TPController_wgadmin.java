package com.amex.tp.common;

import java.io.IOException;
import java.util.List;

import javax.xml.bind.JAXBException;

import org.testng.TestNG;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.Test;
import org.testng.collections.Lists;



public class TPController_wgadmin {
  @Test
  public void main() throws IOException, JAXBException {
	  
	 // TestListenerAdapter tla = new TestListenerAdapter();
	 // BasicConfigurator.configure();
	  System.out.println("Automated testng xml creation starts here");
	  TestNG tng = new TestNG();
	  List<String> suites = Lists.newArrayList();
	  RunId rd= new RunId();
	  rd.generateRunId_wgadmin();
	  XMLGen dynamicxml=new XMLGen(true);
	  String packname = FrameworkConstants.Pack3;
	  dynamicxml.readExcel(FrameworkConstants.ExecutionSheet_wgadmin, "testngwgadmin.xml",packname);
	  
	  suites.add("testngwgadmin.xml");
	   
	 tng.setTestSuites(suites);
	 tng.run();
  }
 
}

