/*Description: This module is having constant values used in the framework
*/
package com.amex.tp.common;

public class FrameworkConstants {
	

	
	public static String TP_Props = "./properties/TP.properties";
	public static String G1_Props = "./properties/G1.properties";
	public static String G2_Props = "./properties/G2.properties";
	public static String G3_Props = "./properties/G3.properties";
	public static String G4_Props = "./properties/G4.properties";
	public static String G5_Props = "./properties/G5.properties";
	public static String G6_Props = "./properties/G6.properties";
	public static String G7_Props = "./properties/G7.properties";
	public static String G8_Props = "./properties/G8.properties";
	public static String G9_Props = "./properties/G9.properties";
	public static String G10_Props = "./properties/G10.properties";
	public static String G11_Props = "./properties/G11.properties";
	public static String G12_Props = "./properties/G12.properties";
	public static String G13_Props = "./properties/G13.properties";
	public static String G14_Props = "./properties/G14.properties";
	public static String G15_Props = "./properties/G15.properties";
	public static String G16_Props = "./properties/G16.properties";
	public static String G17_Props = "./properties/G17.properties";
	public static String G18_Props = "./properties/G18.properties";
	public static String G19_Props = "./properties/G19.properties";
	public static String G20_Props = "./properties/G20.properties";
	public static String G22_Props = "./properties/G22.properties";
	public static String G23_Props = "./properties/G23.properties";
	public static String G24_Props = "./properties/G24.properties";
	public static String RunLog="RunLog.log";
	public static String ExecutionSheet="./test-data/ExecutionEngineTP.xls";
	public static String ExecutionSheet_maintainer="./test-data/ExecutionEngineTP_maintainer.xls";
	public static String ExecutionSheet_Profmaintainer="./test-data/ExecutionEngineTP_Profmaintainer.xls";
	public static String ExecutionSheet_wgadmin="./test-data/ExecutionEngineTP_wgadmin.xls";
	public static String TCLookup="./test-data/TCLookup.txt";
    public static int SleepValue=3000;
	public static String ScreenShots="./screenshots";
    public static String RunIdFile="RunId.txt";
    public static String DefaultSFTPWD="amex123";
    public static int Maxloopvalue=1000;
    public static int Minloopvalue=7; 
    public static String Pack = "com.amex.tp.scripts.";
    public static String Pack1 = "com.amex.tp.maintainer.";
    public static String Pack2 = "com.amex.tp.profilemaintainer.";
    public static String Pack3 = "com.amex.tp.wgadmin.";

    
}
