package com.amex.tp.scripts;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipOutputStream;

import org.openqa.selenium.WebDriver;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import bsh.ParseException;

import com.amex.tp.common.CreateZip;
import com.amex.tp.common.FrameworkConstants;
import com.amex.tp.common.LoadProperties;
import com.amex.tp.common.ScreenShot;
import com.amex.tp.common.TP_Login;
import com.amex.tp.common.TestcaseLookup;
import com.amex.tp.common.WriteTestResult;
import com.amex.tp.common.commandManager;

@Test
public class G6EditFileFlowTC011 {

	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G6EditFileFlowTC011.class);

	Map<String, Object> connectionmap;
	ScreenShot screenPrint;
	String runIdFile;
	List<String> testCaseList;
	WriteTestResult wtr;
	WebDriver fdriver;
	String filePath = FrameworkConstants.ScreenShots
			+ "/G6EditFileFlowTC011/G6EditFileFlowTC011.zip";
	String screenshotname;
	int screenshotnumber = 1;
	String loginscreenshot;
	File folder;
	CreateZip zipfile = null;
	ZipOutputStream zos = null;
	FileOutputStream fos = null;
	boolean testCasesucessFlag=false;
	commandManager cmd;

	@Parameters({ "TestCaseName", "Browser" })
	public void addFileFlow(String tcname, String browser) throws InterruptedException,ParseException, Throwable {

		LoadProperties lp = new LoadProperties(FrameworkConstants.G6_Props);
		String tcid = ""; cmd=commandManager.getInstance(browser,tcid);

		try {
			folder = new File(FrameworkConstants.ScreenShots + "/G6EditFileFlowTC011");

			if (folder.mkdir()) {
				// System.out.println("Directory is created!");
				logger.info("Group Folder Created");
			} else {
				logger.info("Directory Already Exists. Results will be added to the existing folder.");
				// System.out.println("Directory Already Exists!");
			}
		} catch (Exception e) {
			logger.info("Group Folder Creation Failed");
			// System.out.println("exception is:"+ e);
		}

		try {
			TP_Login tp = new TP_Login(logger,browser,cmd);
			connectionmap = tp.HlogintoTP(browser, zos);
			fdriver = (WebDriver) connectionmap.get("fdriver");
			screenPrint = new ScreenShot();
			screenshotname = tcname + "_" + screenshotnumber;
			System.out.println("Screenshot: " + screenshotname);
			System.out.println(folder.getAbsolutePath());
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			System.out.println("The  screen shot " + screenshotnumber+ " got added");
			logger.info("The  screen shot " + screenshotnumber + " got added");
			Thread.sleep(FrameworkConstants.SleepValue);
			
			
			logger.info("search maintain file flow");
			cmd.click("/html/body/table[2]/tbody/tr/td[1]/form/div/dl[5]/dt/img", "xpath");
			
			logger.info("search fileflow");
			cmd.click("/html/body/table[2]/tbody/tr/td[1]/form/div/dl[5]/dd/a[1]/img", "xpath");
			
			
			logger.info("enter the file flow");
			cmd.type("fileFlowName", "name",(lp.readProperty("G6EditFFTC012_fileflowname")));
			
			logger.info("enter test owner");
			cmd.selectByText("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[2]/select", "xpath", (lp.readProperty("G6EditFFTC012_Owner")));
			
		
			
			screenshotname=tcname+"_"+screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			System.out.println("edit file flow main screen steps completed -- "+G6EditFileFlowTC011.class);
			

			cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td/input[1]", "xpath"); //search button
			cmd.click(lp.readProperty("G6EditFFTC011_fileflowname"), "partialLinkText");
			
			screenshotname = tcname + "_" + screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			

			logger.info("click on edit");
			cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td/input[1]", "xpath");
			
			//delivery steps details
			logger.info("click delivery step");
			cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td/table/tbody/tr[4]/td[2]/a", "xpath");
			
			logger.info("press edit button");
			cmd.click("//*[@value='Edit']", "xpath");
			
			logger.info("select check box");
			//cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[1]/font[2]/input", "xpath");
			
			logger.info("enter delivery file name");
			cmd.type("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[1]/input","xpath", (lp.readProperty("G6EditFFTC011_deliveryFileName")));
			
			
			logger.info("Select check box for destination transmitter");
			//cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[2]/font[2]/input","xpath");
			
			
			logger.info("Enter destination transmitter");
			cmd.type("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[2]/input","xpath", (lp.readProperty("G6EditFFTC011_destXmitter")));
			
			logger.info("Click on search");
			cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[2]/img", "xpath");
			
			logger.info("click on transmitter name");
		cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td/table/tbody/tr[3]/td[1]/a","xpath");
		
		logger.info("select remote access");
		cmd.selectByText("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[2]/select", "xpath",(lp.readProperty("G6EditFFTC011_remoteAccessId")) );
		
		
		logger.info("Select check box for Deliver Directory");
		//cmd.click(" /html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[1]/font[2]/input","xpath");
		
		logger.info("enter delivery directory");
		cmd.type("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[1]/input", "xpath",(lp.readProperty("G6EditFFTC011_deliveryDirectory")) );
		
		logger.info("enter ok");
		cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td/input[1]","xpath");
		
		//deliver got completed
		
		//mailbox step details
		
		logger.info("click mail box step");
		cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td/table/tbody/tr[5]/td[2]/a","xpath");
		
		logger.info("click on edit");
		cmd.click("//*[@value='Edit']","xpath");
		
		
		logger.info("click on checkbox");
		//cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[2]/font/input","xpath");	
			
			
		logger.info("enter the dest transmitter name");	
		cmd.type("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[2]/input", "xpath",(lp.readProperty("G6EditFFTC011_destXmitter")));
			
			
			
		logger.info("click on search");
		cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[2]/img","xpath");
		
		logger.info("click on expected transmitter value");
		cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td/table/tbody/tr[3]/td[1]/a","xpath");	
		
		logger.info("select destuser name");
		cmd.selectByText("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[2]/select", "xpath",(lp.readProperty("G6EditFFTC011_destUserId")));
		
		
		logger.info("click on checkbox");
		//cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td[2]/font/input","xpath");	
		
		logger.info("enter mailfilename");
	    cmd.type("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td[2]/input", "xpath",(lp.readProperty("G6EditFFTC011_mailBoxFileName")) );
		
		logger.info("click on check box");
		//cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td[2]/font/input", "xpath");
		
	/*	logger.info("enable button");
		cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td[2]/label[1]/input", "xpath");
		
		logger.info("enter email address");
		cmd.type("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[7]/td/div/table/tbody/tr[2]/td[1]/input", "xpath",(lp.readProperty("G6EditFFTC011_mailBoxEmail")) );
		
		logger.info("click add email address");
		cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[7]/td/div/table/tbody/tr[2]/td[3]/input", "xpath");
		*/
		logger.info("click ok");
		cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[8]/td/input[1]", "xpath");
		
		

		//retrieval steps
		
		logger.info("click retrieval");
		cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td/table/tbody/tr[6]/td[2]/a", "xpath");
		
		logger.info("click edit");
		cmd.click("//*[@value='Edit']", "xpath");
		
		logger.info("click check box");
		//cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[2]/font/input", "xpath");
		
		logger.info("remoteSysPath");
		cmd.type("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[2]/input", "xpath",(lp.readProperty("G6EditFFTC011_remoteSysPath")) );
		
		
		logger.info("click check box");
		//cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[2]/font/input", "xpath");
		
		logger.info("Enter remote transmitter");
		cmd.type("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[2]/input","xpath", (lp.readProperty("G6EditFFTC011_destXmitter")));
		
		
		
		logger.info("click on search");
		cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[2]/img", "xpath");
		
		
		logger.info("click on remote transmitter");
		cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td/table/tbody/tr[3]/td[1]/a", "xpath");
		
		logger.info("click remote access");
		cmd.selectByText("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td[2]/select", "xpath",(lp.readProperty("G6EditFFTC011_remoteAccessId")) );
		
		
		logger.info("click check box");
		//cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td[2]/font/input", "xpath");
		
		
		logger.info("maxRetrievalAttempts");
		cmd.type("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td[2]/input","xpath", (lp.readProperty("G6EditFFTC011_maxRetrievalAttempts")));
		
		
		logger.info("click check box");
		//cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[7]/td[2]/font/input", "xpath");
		
		
		logger.info("retrievalAttemptInterval");
		cmd.type("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[7]/td[2]/input","xpath", (lp.readProperty("G6EditFFTC011_retrievalAttemptInterval")));
		
		
		logger.info("click check box");
		//cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[8]/td[2]/font/input", "xpath");
		
		
		logger.info("Retrieval File Name");
		cmd.type("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[8]/td[2]/input","xpath",(lp.readProperty("G6EditFFTC011_fileName")));
		
		
		logger.info("click check box");
		//cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[10]/td/font/input", "xpath");
		
		logger.info("script");
		cmd.type("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[10]/td/textarea","xpath",(lp.readProperty("G6EditFFTC011_script")));
		
		
		logger.info("click ok");
		cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[11]/td/input[1]", "xpath");
		
		
	
		//transform
	
		
		logger.info("select transform");
		cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td/table/tbody/tr[8]/td[2]/a", "xpath");
		
		logger.info("click edit");
		cmd.click(".//*[@value='Edit']", "xpath");
		
		
		logger.info("check box");
		//cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[2]/font/input", "xpath");
		
		
		logger.info("Transformation Queue Name ");
		cmd.selectByText("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[2]/select","xpath",(lp.readProperty("G6EditFFTC011_transQueueNameId")));
		
		logger.info("check box");
		//cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[2]/font/input", "xpath");
		
		
		logger.info("Application Queue Name ");
		cmd.selectByText("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[2]/select","xpath",(lp.readProperty("G6EditFFTC011_appQueueNameId")));
		
		
		logger.info("check box");
		//cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td[2]/font[2]/input", "xpath");
		
		
		logger.info("Parameter Name 1 ");
		cmd.selectByText("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td[1]/select","xpath",(lp.readProperty("G6EditFFTC011_parameterNameCd1")));
		
		
		logger.info("Parameter Value1");
		cmd.type("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td[2]/input[1]","xpath",(lp.readProperty("G6EditFFTC011_parameterValue1")));
		
		
		logger.info("click add");
		cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td[2]/input[2]", "xpath");
		
		
		
		logger.info("Parameter Name 2 ");
		cmd.selectByText("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td[1]/select","xpath",(lp.readProperty("G6EditFFTC011_parameterNameCd2")));
		
		
		logger.info("click add");
		cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td[2]/input[2]", "xpath");
		
		
		logger.info("Parameter Name 3");
		cmd.selectByText("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td[1]/select","xpath",(lp.readProperty("G6EditFFTC011_parameterNameCd3")));
		
		logger.info("Parameter Value2");
		cmd.type("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td[2]/input[1]","xpath",(lp.readProperty("G6EditFFTC011_parameterValue2")));
		
		logger.info("click add");
		cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td[2]/input[2]", "xpath");
		
		logger.info("click ok");
		cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[7]/td/input[1]", "xpath");
		
		
		
		
		
	logger.info("save the values");
		cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td/input[2]","xpath");
		
		
		
			String Succmsg = cmd.getContent("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table[1]/tbody/tr/td[3]/font", "xpath");
			if(Succmsg.contains("***File Flow updated successfully*** ***Replication verification is successful***")){
			  logger.info("G6EditFFTC011 succeeded");
			  testCasesucessFlag=true;
			}else{
				logger.info("G6EditFFTC011 failed");
				 testCasesucessFlag=false;
			}
			
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			fdriver.switchTo().alert().accept();
			Thread.sleep(3000);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Test Case Failed");
			cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			fdriver.switchTo().alert().accept();
			cmd.wait(5000);
			Assert.fail(e.getMessage());
		
		}
		finally	{
		TestcaseLookup tl = new TestcaseLookup(logger);
		testCaseList = tl.lookupTestcase(FrameworkConstants.TCLookup,
				"G6EditFileFlowTC011");
		LoadProperties lp1 = new LoadProperties(FrameworkConstants.RunIdFile);
		runIdFile = (lp1.readProperty("RUNID"));
		wtr = new WriteTestResult();

		if (testCasesucessFlag) {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating " + testCaseList.get(i)
						+ " status as Passed");

				wtr.writeToFile(runIdFile,
						"G6EditFileFlowTC011," + testCaseList.get(i) + ",Passed");
			}
		} else {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating" + testCaseList.get(i) + "status as Failed");

				wtr.writeToFile(runIdFile,"G6EditFileFlowTC011," + testCaseList.get(i) + ",Failed");
			}

		}
		}
	}
	
}

			
			
			

