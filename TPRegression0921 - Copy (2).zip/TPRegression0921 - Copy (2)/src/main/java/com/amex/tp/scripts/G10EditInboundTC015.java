package com.amex.tp.scripts;

//Description - Search an Outound in Maintain Transmitter screen 

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipOutputStream;

import org.openqa.selenium.WebDriver;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import bsh.ParseException;

import com.amex.tp.common.CreateZip;
import com.amex.tp.common.FrameworkConstants;
import com.amex.tp.common.LoadProperties;
import com.amex.tp.common.ScreenShot;
import com.amex.tp.common.TP_Login;
import com.amex.tp.common.TP_Login_Maintainer;
import com.amex.tp.common.TestcaseLookup;
import com.amex.tp.common.WriteTestResult;
import com.amex.tp.common.commandManager;

@Test
public class G10EditInboundTC015 {

	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G10EditInboundTC015.class);

	Map<String, Object> connectionmap;
	ScreenShot screenPrint;
	String runIdFile;
	List<String> testCaseList;
	WriteTestResult wtr;
	WebDriver fdriver;
	String filePath = FrameworkConstants.ScreenShots + "/G10EditInboundTC015/G10EditInboundTC015.zip";
	String screenshotname;
	int screenshotnumber = 1;
	String loginscreenshot;
	File folder;
	CreateZip zipfile = null;
	ZipOutputStream zos = null;
	FileOutputStream fos = null;
	boolean testCasesucessFlag=false;
	commandManager cmd;

	@Parameters({ "TestCaseName", "Browser" })
	public void addFileFlow(String tcname, String browser) throws InterruptedException,ParseException, Throwable {

		LoadProperties lp = new LoadProperties(FrameworkConstants.G10_Props);
		String tcid = ""; cmd=commandManager.getInstance(browser,tcid);

		try {
			folder = new File(FrameworkConstants.ScreenShots
					+ "/G10EditInboundTC015");

			if (folder.mkdir()) {
				// System.out.println("Directory is created!");
				logger.info("Group Folder Created");
			} else {
				logger.info("Directory Already Exists. Results will be added to the existing folder.");
				// System.out.println("Directory Already Exists!");
			}
		} catch (Exception e) {
			logger.info("Group Folder Creation Failed");
			// System.out.println("exception is:"+ e);
		}

		try {
			TP_Login tp = new TP_Login(logger, browser, cmd);
			connectionmap = tp.HlogintoTP(browser, zos);
			fdriver = (WebDriver) connectionmap.get("fdriver");
			screenPrint = new ScreenShot();
			screenshotname = tcname + "_" + screenshotnumber;
			System.out.println("Screenshot: " + screenshotname);
			System.out.println(folder.getAbsolutePath());
			// System.out.println(fdriver.getCurrentUrl());
			Thread.sleep(FrameworkConstants.SleepValue);
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			logger.info("The  screen shot " + screenshotnumber + " got added");
			screenshotnumber++;
			
			
			logger.info("click on Maintain Transmitter");
			cmd.click("html/body/table[2]/tbody/tr/td[1]/form/div/dl[4]/dt/img", "xpath");//click on Maintain Transmitter
			
			logger.info("Click on Search Transmitter");
			cmd.click("html/body/table[2]/tbody/tr/td[1]/form/div/dl[4]/dd/a[1]/img", "xpath");//Click on Search Transmitter
			
			logger.info("Enter the Transmitter Name");
			cmd.type("transmitterName", "name",lp.readProperty("G10EditInboundTC015_transmitterName"));
			logger.info("Click on Search Button");
			cmd.click("Search", "name");
			
					
			logger.info("Click on Searched Transmitter Name");
			cmd.click("html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/table/tbody/tr[3]/td[1]/a", "xpath");
			
			screenshotname=tcname+"_"+screenshotnumber;
			Thread.sleep(FrameworkConstants.SleepValue);
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			screenshotnumber++;
			
			logger.info("Click on inbound file tab");
			cmd.click("html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/div/div[1]/h2[3]", "xpath"); //click on inbound file tab
			logger.info("Enter User Name");
			cmd.type("userName", "name",lp.readProperty("G10EditInboundTC015_userName"));
			logger.info("Enter the File Name");
			cmd.type("fileName", "name",lp.readProperty("G10EditInboundTC015_fileName"));
			logger.info("Enter the File Type Code");
			cmd.selectByValue("fileTypeCD", "name", lp.readProperty("G10EditInboundTC015_fileTypeCD"));
			logger.info("Enter the File Flow Code");
			cmd.selectByValue("fileFlowID", "name", lp.readProperty("G10EditInboundTC015_fileFlowID"));
			
			screenshotname=tcname+"_"+screenshotnumber;
			Thread.sleep(FrameworkConstants.SleepValue);
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			screenshotnumber++;
			
			cmd.click("GO", "name");
			
			screenshotname=tcname+"_"+screenshotnumber;
			Thread.sleep(FrameworkConstants.SleepValue);
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			screenshotnumber++;
			
		if(cmd.ifDisplayed("html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/table/tbody/tr[2]/td/label")) {
				  System.out.println("No Records Found. Search all failed--  "+G10EditInboundTC015.class);
					
			}else{
			  System.out.println("Records Retrieved. Inbound Search Passed--  "+G10EditInboundTC015.class);
			  testCasesucessFlag=true;
			}

			System.out.println("**** Search an Inbound in Maintain Transmitter screen test case completed ******* "+G10EditInboundTC015.class);

			cmd.click(".//*[@id='menu']/dl[7]/a/img", "xpath");
			fdriver.switchTo().alert().accept();
			Thread.sleep(3000);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Test Case Failed");
			cmd.click(".//*[@id='menu']/dl[7]/a/img", "xpath");
			fdriver.switchTo().alert().accept();
			cmd.wait(5000);
			Assert.fail(e.getMessage());
		}
		
		finally{
		TestcaseLookup tl = new TestcaseLookup(logger);
		testCaseList = tl.lookupTestcase(FrameworkConstants.TCLookup,
				"G10EditInboundTC015");
		LoadProperties lp1 = new LoadProperties(FrameworkConstants.RunIdFile);
		runIdFile = (lp1.readProperty("RUNID"));
		wtr = new WriteTestResult();

		if (testCasesucessFlag) {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating " + testCaseList.get(i)
						+ " status as Passed");

				wtr.writeToFile(runIdFile,
						"G10EditInboundTC015," + testCaseList.get(i) + ",Passed");
			}
		} else {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating" + testCaseList.get(i) + "status as Failed");

				wtr.writeToFile(runIdFile,"G10EditInboundTC015" + testCaseList.get(i) + ",Failed");
			}

		}
		}

	}
	
}
