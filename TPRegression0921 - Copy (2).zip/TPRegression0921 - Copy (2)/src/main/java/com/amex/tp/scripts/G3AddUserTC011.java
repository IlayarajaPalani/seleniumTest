package com.amex.tp.scripts;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipOutputStream;

import javax.xml.xpath.XPath;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.server.handler.FindElement;
import org.openqa.selenium.support.FindBy;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import bsh.ParseException;

import com.amex.tp.common.CreateZip;
import com.amex.tp.common.FrameworkConstants;
import com.amex.tp.common.LoadProperties;
import com.amex.tp.common.ScreenShot;
import com.amex.tp.common.TP_Login;
import com.amex.tp.common.TestcaseLookup;
import com.amex.tp.common.WriteTestResult;
import com.amex.tp.common.commandManager;

public class G3AddUserTC011 {
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G3AddUserTC011.class);
	Map<String, Object> connectionmap;
	ScreenShot screenPrint;
	String runIdFile;
	List<String> testCaseList;
	WriteTestResult wtr;
	WebDriver fdriver;
	String filePath = FrameworkConstants.ScreenShots+"/G3AddUserTC011/G3AddUserTC011.zip";
	String screenshotname;
	int screenshotnumber = 1;
	String loginscreenshot;
	File folder;
	CreateZip zipfile = null;
	ZipOutputStream zos = null;
	FileOutputStream fos = null;
	boolean testCaseSuccessFlag=false;
	commandManager cmd;

	public static void main(String[] args) throws ParseException, InterruptedException, Throwable{
		G3AddUserTC011 g3 = new G3AddUserTC011();
		g3.addBasicUser("G3AddUserTC011", "IE");
	}

	@Parameters({ "TestCaseName", "Browser" })
	@Test
	public void addBasicUser(String tcname, String browser) throws InterruptedException,ParseException, Throwable {
		LoadProperties lp = new LoadProperties(FrameworkConstants.G3_Props);
		String tcid = ""; cmd=commandManager.getInstance(browser,tcid);

		try {
			folder = new File(FrameworkConstants.ScreenShots+"/G3AddUserTC011");

			if (folder.mkdir()) {
				// System.out.println("Directory is created!");
				logger.info("Group Folder Created");
			} else {
				logger.info("Directory Already Exists. Results will be added to the existing folder.");
				// System.out.println("Directory Already Exists!");
			}
		} catch (Exception e) {
			logger.info("Group Folder Creation Failed");
			// System.out.println("exception is:"+ e);
		}

		try{
			TP_Login tp = new TP_Login(logger,browser,cmd);;
			connectionmap = tp.HlogintoTP(browser, zos);
			fdriver = (WebDriver) connectionmap.get("fdriver");
			screenPrint = new ScreenShot();
			screenshotname = tcname + "_" + screenshotnumber;
			System.out.println("Screenshot: " + screenshotname);
			System.out.println(folder.getAbsolutePath());
			// System.out.println(fdriver.getCurrentUrl());
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);

			System.out.println("The  screen shot " + screenshotnumber+ " got added");
			logger.info("The  screen shot " + screenshotnumber + " got added");
			Thread.sleep(FrameworkConstants.SleepValue);

			//cmd.click(".//*[@id='Table1']/tbody/tr/td/table/tbody/tr/td/table/tbody/tr[4]/td/a/img", "xpath");
			/*WebElement maintainTrans = fdriver.findElement(By.xpath(".//*[@id='Table1']/tbody/tr/td/table/tbody/tr/td/table/tbody/tr[4]/td/a/img")); 
				Actions act = new Actions(fdriver);
				act.moveToElement(maintainTrans).build().perform();*/
			cmd.click(".//*[@id='menu']/dl[4]/dt/img", "xpath");//click on Maintain File Flow
			cmd.click(".//*[@id='smenu1']/a[1]/img", "xpath");

			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[1]/input", "xpath", lp.readProperty("G3AddUserTC011_searchTransmitter"));
			cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[8]/td/input[1]", "xpath");
			cmd.click(".//*[@id='userdetails1']/tbody/tr[3]/td[1]/a", "xpath");
			cmd.click(".//*[@id='SubButton']/input", "xpath");

			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[1]/input", "xpath",lp.readProperty("G3AddUserTC011_username")+System.currentTimeMillis());
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[1]/input", "xpath",lp.readProperty("G3AddUserTC011_fName"));
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[2]/input", "xpath",lp.readProperty("G3AddUserTC011_lName"));
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td[1]/input", "xpath",lp.readProperty("G3AddUserTC011_phone"));
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td[2]/input", "xpath",lp.readProperty("G3AddUserTC011_email"));
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[8]/td/div[1]/table/tbody/tr[3]/td/input", "xpath",lp.readProperty("G3AddUserTC011_pwd"));
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[8]/td/div[1]/table/tbody/tr[4]/td/input", "xpath",lp.readProperty("G3AddUserTC011_pwd"));
			cmd.selectByText(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[2]/select", "xpath", lp.readProperty("G3AddUserTC011_owner"));

			cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/input[1]", "xpath");

			WebElement d = cmd.getWebElement(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table[1]/tbody/tr/td[3]/font", "xpath", 1, 500);
			System.out.println(d.getText());

			if(d.getText().equals("***SFT User details added successfully*** ***Replication verification is successful***")){

				if(cmd.ifExists(lp.readProperty("G3AddUserTC011_username"), "partialLinkText", 1, 500)){
					
					cmd.click(lp.readProperty("G3AddUserTC011_username"), "partialLinkText");
					
				}
				else if(cmd.ifExists("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/div/div[2]/table/tbody/tr[1]/td/a[2]", "xpath", 1, 500)){
					do{
					cmd.click("//a[contains(text(),'Next')]", "xpath");
					
					if(cmd.ifExists(lp.readProperty("G3AddUserTC011_username"), "partialLinkText", 1, 500))
						cmd.click(lp.readProperty("G3AddUserTC011_username"), "partialLinkText");
					testCaseSuccessFlag = true;
						break;
					}
					while(cmd.ifExists("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/div/div[2]/table/tbody/tr[1]/td/a[2]", "xpath", 1, 500));
				}
				else{
					testCaseSuccessFlag = false;
				}
				/*List<WebElement> d1 = fdriver.findElements(By.partialLinkText(lp.readProperty("G3AddUserTC011_username")));
				d1.get(0).click();*/

				cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[10]/td/input[2]", "xpath");
				WebElement v1 = cmd.getWebElement(".//*[@id='userdetails']/tbody/tr[3]/td[2]", "xpath");
				WebElement v2 = cmd.getWebElement(".//*[@id='userdetails']/tbody/tr[5]/td[2]", "xpath");
				cmd.sleep(2000);
				if(v1.getText().equals("COMPLETED") && v2.getText().equals("COMPLETED")){
					logger.info("G3AddUserTC011 Succeeded");
					testCaseSuccessFlag = true;
				}
				else{
					logger.info("G3AddUserTC011 failed");
					testCaseSuccessFlag = false;
				}
			}
			else{
				logger.info("G3AddUserTC011 failed");
				testCaseSuccessFlag = false;
			}

			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);

			cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			fdriver.switchTo().alert().accept();
			Thread.sleep(3000);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Test Case Failed");
			cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			fdriver.switchTo().alert().accept();
			cmd.wait(5000);
			Assert.fail(e.getMessage());
		}

		
		finally{TestcaseLookup tl = new TestcaseLookup(logger);
		testCaseList = tl.lookupTestcase(FrameworkConstants.TCLookup,
				"G3AddUserTC011");
		LoadProperties lp1 = new LoadProperties(FrameworkConstants.RunIdFile);
		runIdFile = (lp1.readProperty("RUNID"));
		wtr = new WriteTestResult();

		if (testCaseSuccessFlag) {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating " + testCaseList.get(i)
						+ " status as Passed");

				wtr.writeToFile(runIdFile,
						"G3AddUserTC011," + testCaseList.get(i) + ",Passed");
			}
		} else {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating" + testCaseList.get(i) + "status as Failed");

				wtr.writeToFile(runIdFile,"G3AddUserTC011," + testCaseList.get(i) + ",Failed");
			}

		}
		}

	}

}
