package com.amex.tp.scripts;


import java.io.File;
import java.io.FileOutputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipOutputStream;

import org.openqa.selenium.WebDriver;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import bsh.ParseException;

import com.amex.tp.common.CreateZip;
import com.amex.tp.common.FrameworkConstants;
import com.amex.tp.common.LoadProperties;
import com.amex.tp.common.ScreenShot;
import com.amex.tp.common.TP_Login;
import com.amex.tp.common.TestcaseLookup;
import com.amex.tp.common.WriteTestResult;
import com.amex.tp.common.commandManager;

@Test
public class G11DeleteFileFlowTC012 {

	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G11DeleteFileFlowTC012.class);

	Map<String, Object> connectionmap;
	ScreenShot screenPrint;
	String runIdFile;
	List<String> testCaseList;
	WriteTestResult wtr;
	WebDriver fdriver;
	String filePath = FrameworkConstants.ScreenShots + "/G11DeleteFileFlowTC012/G11DeleteFileFlowTC012.zip";
	String screenshotname;
	int screenshotnumber = 1;
	String loginscreenshot;
	File folder;
	CreateZip zipfile = null;
	ZipOutputStream zos = null;
	FileOutputStream fos = null;
	boolean testCasesucessFlag=false;
	commandManager cmd;
	@Parameters({ "TestCaseName", "Browser" })
	public void addFileFlow(String tcname, String browser) throws InterruptedException,ParseException, Throwable {
		LoadProperties lp = new LoadProperties(FrameworkConstants.G11_Props);
		String tcid = ""; cmd=commandManager.getInstance(browser,tcid);
		try {
			folder = new File(FrameworkConstants.ScreenShots + "/G11DeleteFileFlowTC012");
			if (folder.mkdir()) {
				// System.out.println("Directory is created!");
				logger.info("Group Folder Created");
			} else {
				logger.info("Directory Already Exists. Results will be added to the existing folder.");
				// System.out.println("Directory Already Exists!");
			}
		} catch (Exception e) {
			logger.info("Group Folder Creation Failed");
			// System.out.println("exception is:"+ e);
		}
		try {
			TP_Login tp = new TP_Login(logger,browser,cmd);;
			connectionmap = tp.HlogintoTP(browser, zos);
			fdriver = (WebDriver) connectionmap.get("fdriver");
			screenPrint = new ScreenShot();
			screenshotname = tcname + "_" + screenshotnumber;
			System.out.println("Screenshot: " + screenshotname);
			System.out.println(folder.getAbsolutePath());
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			logger.info("The  screen shot " + screenshotnumber + " got added");
			Thread.sleep(FrameworkConstants.SleepValue);
			cmd.click(".//*[@id='menu']/dl[5]/dt/img", "xpath");
			cmd.click(".//*[@id='smenu2']/a[2]/img", "xpath");
			String tcf = null;
			tcf = lp.readProperty("G11DeleteFF012_fileflowname")+System.currentTimeMillis();
			cmd.type("fileFlowName", "name",tcf);
			cmd.type("description", "name",lp.readProperty("G11DeleteFF012_description"));
			cmd.selectByValue("owner", "name", lp.readProperty("G11DeleteFF012_owner"));

			screenshotname=tcname+"_"+screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			//zipfile.addToZipFile(folder.getAbsolutePath()+"\\"+screenshotname+".png", zos);
			cmd.click("AddNewStepType", "name");
			cmd.selectByValue("stepTypeCd", "name", lp.readProperty("G11DeleteFF012_mailbox"));
			cmd.click("Save", "name");
			screenshotname=tcname+"_"+screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			//zipfile.addToZipFile(folder.getAbsolutePath()+"\\"+screenshotname+".png", zos);
			cmd.click("AddNewStepType", "name");
			cmd.selectByValue("stepTypeCd", "name", lp.readProperty("G11DeleteFF012_catalog"));
			cmd.click("Save", "name");
			screenshotname=tcname+"_"+screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			cmd.click("AddNewStepType", "name");
			cmd.selectByValue("stepTypeCd", "name", lp.readProperty("G11DeleteFF012_delivery"));
			cmd.click("Save", "name");
			screenshotname=tcname+"_"+screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			cmd.click("AddNewStepType", "name");
			cmd.selectByValue("stepTypeCd", "name", lp.readProperty("G11DeleteFF012_retrieval"));
			cmd.click("Save", "name");
			screenshotname=tcname+"_"+screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			cmd.click("AddNewStepType", "name");
			cmd.selectByValue("stepTypeCd", "name", lp.readProperty("G11DeleteFF012_schret"));
			cmd.click("Save", "name");
			screenshotname=tcname+"_"+screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			cmd.click("AddNewStepType", "name");
			cmd.selectByValue("stepTypeCd", "name", lp.readProperty("G11DeleteFF012_transform"));
			cmd.click("Save", "name");
			screenshotname=tcname+"_"+screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			cmd.click("AddFFSave", "name");
			screenshotname=tcname+"_"+screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			String successmsg = cmd.getContent(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table[1]/tbody/tr/td[3]/font", "xpath");
			if(successmsg.contains("***File Flow added successfully*** ***Replication verification is successful***")){
				System.out.println("File Flow Added Successfully  --  "+G11DeleteFileFlowTC012.class);
				cmd.click("/html/body/table[2]/tbody/tr/td[1]/form/div/dl[5]/dt/img", "xpath");
				cmd.click("/html/body/table[2]/tbody/tr/td[1]/form/div/dl[5]/dd/a[1]/img", "xpath");
				cmd.type("fileFlowName", "name",(tcf));
				screenshotname=tcname+"_"+screenshotnumber;
				screenshotnumber++;
				screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
				System.out.println("edit file flow main screen steps completed -- "+G11DeleteFileFlowTC012.class);
				cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td/input[1]", "xpath"); //search button
				if(cmd.ifExists(tcf, "partialLinkText", 1 ,500)){
					cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td/table/tbody/tr[3]/td[4]/a/img", "xpath");
	            	   String parentWindowHandler = fdriver.getWindowHandle(); //This code represents the control is with current window.
	     		       String subWindowHandler = null; 
	     		       Set<String> handles = fdriver.getWindowHandles();
	     		       java.util.Iterator<String> iterator = handles.iterator();
	     		      while (iterator.hasNext()){
	     		    	  if(subWindowHandler=="Confirm"){
	     	     		       fdriver.switchTo().window(subWindowHandler); // Control is shifted to Pop up
	     	     		       }
	     	     		       else
	     	     		       {
	     	     		    	  subWindowHandler = iterator.next();
	     	     		    	  fdriver.switchTo().window(subWindowHandler);
	     	     		       }
	     		       }
	   
	     		    fdriver.switchTo().window(subWindowHandler);
	     		   Thread.sleep(FrameworkConstants.SleepValue);
	            	cmd.click("html/body/table/tbody/tr[2]/td/button[1]", "xpath"); // Do actions in the pop up window.
	            	logger.info("Confirmed");
	            	fdriver.switchTo().window(parentWindowHandler); // Instructing the driver to move the control to the Parent window
	     		       
					successmsg = cmd.getContent("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table[1]/tbody/tr/td[3]/font", "xpath");
					if(successmsg.contains("**FileFlow is deleted successfully*** ***Replication verification is successful***")){

						cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table[2]/tbody/tr[3]/td/input[1]", "xpath");
						if(cmd.getContent("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td/table/tbody/tr[2]/td/label", "xpath")
								.contains("No Records Found..!")){
							logger.info("G11DeleteFFTC012 succeeded");
							testCasesucessFlag=true;
						}
						else{
							logger.info("G11DeleteFFTC012 failed");
							testCasesucessFlag=false;
						}
					}else{ 
						logger.info("G11DeleteFFTC012 failed");
						testCasesucessFlag=false;
					}
				}
				else{
					testCasesucessFlag=false;
				}
			}else{
				testCasesucessFlag=false;
			}


			screenshotname = tcname + "_" + screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);

			//cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			logger.info("Logging out from the Application");
			cmd.click("//img[contains(@src, 'Logout.jpg')]", "xpath");
			fdriver.switchTo().alert().accept();
			Thread.sleep(3000);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Test Case Failed");
			//cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			logger.info("Logging out from the Application");
			cmd.click("//img[contains(@src, 'Logout.jpg')]", "xpath");
			fdriver.switchTo().alert().accept();
			cmd.wait(5000);
			Assert.fail(e.getMessage());
		}
		
		finally {

		TestcaseLookup tl = new TestcaseLookup(logger);
		testCaseList = tl.lookupTestcase(FrameworkConstants.TCLookup,
				"G11DeleteFFTC010");
		LoadProperties lp1 = new LoadProperties(FrameworkConstants.RunIdFile);
		runIdFile = (lp1.readProperty("RUNID"));
		wtr = new WriteTestResult();

		if (testCasesucessFlag) {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating " + testCaseList.get(i)
						+ " status as Passed");

				wtr.writeToFile(runIdFile,
						"G11DeleteFFTC010," + testCaseList.get(i) + ",Passed");
			}
		} else {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating" + testCaseList.get(i) + "status as Failed");

				wtr.writeToFile(runIdFile,"G11DeleteFFTC010," + testCaseList.get(i) + ",Failed");
			}

		}
		}
	}

}
