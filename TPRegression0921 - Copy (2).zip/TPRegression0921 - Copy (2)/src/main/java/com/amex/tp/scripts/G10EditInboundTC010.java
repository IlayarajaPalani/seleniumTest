
package com.amex.tp.scripts;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipOutputStream;

import org.apache.commons.lang.SystemUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.amex.tp.common.CreateZip;
import com.amex.tp.common.FrameworkConstants;
import com.amex.tp.common.LoadProperties;
import com.amex.tp.common.ScreenShot;
import com.amex.tp.common.TP_Login;
import com.amex.tp.common.TP_Login_Maintainer;
import com.amex.tp.common.TestcaseLookup;
import com.amex.tp.common.WriteTestResult;
import com.amex.tp.common.commandManager;

import bsh.ParseException;

public class G10EditInboundTC010 {
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G10EditInboundTC010.class);
	Map<String, Object> connectionmap;
	ScreenShot screenPrint;
	String runIdFile;
	List<String> testCaseList;
	WriteTestResult wtr;
	WebDriver fdriver;
	String filePath = FrameworkConstants.ScreenShots+"/G10EditInboundTC010/G10EditInboundTC010.zip";
	String screenshotname;
	int screenshotnumber = 0;
	String loginscreenshot;
	File folder;
	CreateZip zipfile = null;
	ZipOutputStream zos = null;
	FileOutputStream fos = null;
	boolean testCasesucessFlag=false;
	boolean testCasesucessFlag1=false;
	
	
	commandManager cmd;
	
	@Parameters({ "TestCaseName", "Browser" })
	@Test
	public void addBasicUser(String tcname, String browser) throws InterruptedException,ParseException, Throwable {
		LoadProperties lp = new LoadProperties(FrameworkConstants.G10_Props);
		String tcid = ""; cmd=commandManager.getInstance(browser,tcid);

		try {
			folder = new File(FrameworkConstants.ScreenShots+"/G10EditInboundTC010");

			if (folder.mkdir()) {
				// System.out.println("Directory is created!");
				logger.info("Group Folder Created");
				
			} else {
				logger.info("Directory Already Exists. Results will be added to the existing folder.");
				// System.out.println("Directory Already Exists!");
			}
		} catch (Exception e) {
			logger.info("Group Folder Creation Failed");
			// System.out.println("exception is:"+ e);
		}

		try{
			TP_Login tp = new TP_Login(logger, browser, cmd);
			connectionmap = tp.HlogintoTP(browser, zos);
			fdriver = (WebDriver) connectionmap.get("fdriver");
			screenPrint = new ScreenShot();
			
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			System.out.println("Screenshot: " + screenshotname);
			System.out.println(folder.getAbsolutePath());
			// System.out.println(fdriver.getCurrentUrl());
			
			System.out.println("The  screen shot " + screenshotnumber+ " got added");
			logger.info("The  screen shot " + screenshotnumber + " got added");
			Thread.sleep(FrameworkConstants.SleepValue);
			
		//have to write inbound file code................
			logger.info("maintain transmitter");
			cmd.click(".//*[@id='menu']/dl[4]/dt/img","xpath");
			
			logger.info("search transmitter");
			cmd.click(".//*[@id='smenu1']/a[1]/img", "xpath");
			
			logger.info("enter transmitter name");
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[1]/input", "xpath", lp.readProperty("G10EditInboundTC010_searchTransmitter"));
					
			logger.info("search transmitter");
			cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[8]/td/input[1]", "xpath");
			
			logger.info("Click on the Transmitter Name");
			cmd.click(".//*[@id='userdetails1']/tbody/tr[3]/td[1]/a","xpath");
			
			logger.info("Click on inboundfile");
			cmd.click(".//*[@id='tabPane1']/div[1]/h2[3]/a","xpath");
			
			//new code
			
			logger.info("enter file name for search");
			cmd.type("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/div/div[4]/div[1]/input[2]", "xpath", lp.readProperty("G10EditInboundTC010_fileName"));
			
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			
			logger.info("click");
			cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/div/div[4]/div[1]/input[5]", "xpath");
			
			logger.info("click file name");
			cmd.click(".//*[@id='tabPage3']/table/tbody/tr[4]/td[1]/a", "xpath");
			
	
			logger.info("click on edit");
			cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[12]/td/input[1]", "xpath");
			
			logger.info("give comments");
			cmd.type("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[8]/td[1]/textarea", "xpath", lp.readProperty("G10EditInboundTC010_comments"));
			
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			logger.info("click on save");
			cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[12]/td/input[1]", "xpath");
			
			WebElement d = cmd.getWebElement("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table[1]/tbody/tr/td[3]/font", "xpath");
				
				System.out.println(d.getText());
				
			if(d.getText().equals("***Inbound File details updated successfully*** ***Replication verification is successful***")){
					testCasesucessFlag1 = true;
					System.out.println("inbound file editing is successfull");
				}
				else{
					testCasesucessFlag1= false;
					
					System.out.println("inbound file editing is not successfull");
				}
				
				
			 logger.info("enter file name for search");
				cmd.type("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/div/div[4]/div[1]/input[2]", "xpath", lp.readProperty("G10EditInboundTC010_fileName"));
				
				logger.info("click");
				cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/div/div[4]/div[1]/input[5]", "xpath");
				
				logger.info("click file name");
				cmd.click(".//*[@id='tabPage3']/table/tbody/tr[4]/td[1]/a", "xpath");
				
							
				logger.info("click Viewlastinbound");
				cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/input[3]", "xpath");
				
				
				//getting  the transmitter name
				String s=cmd.getContent("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[1]", "xpath");
				System.out.println("value in that string is:"+s);
				String[] V = s.split(":");
				String TransmitterName = V[1].trim();
				System.out.println("Name is: -" + TransmitterName);
				
				
				//getting the username
				String s1=cmd.getContent("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[1]", "xpath");
				System.out.println("value in that string is:"+s1);
				String[] V1 = s1.split(":");
				String UserName = V1[1].trim();
				System.out.println("Name is: -" + UserName);
				
				//getting the filename
				String s2=cmd.getContent("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[1]", "xpath");
				System.out.println("value in that string is:"+s2);
				String[] V2 = s2.split(":");
				String Filename = V2[1].trim();
				System.out.println("Name is: -" + Filename);
				
				//getting the sitename and server name
				
				String s3=cmd.getContent("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[1]", "xpath");
				
				String s4=cmd.getContent("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[1]", "xpath");
				
				String[] V3 = s3.split(":");//splitting the text.getting the value after :
				String[] V4 = s4.split(":");//splitting the text.getting the value after :
				
				
				String k1 = V3[1].trim();//removing space
				String k2 = V4[1].trim();//removing space
				
				if(k1.equals("US-GLOBAL")&&(k2.equals("US-GLOBAL")))
				{
					logger.info("file transfer happend for this profiles atleast one time");
					
			}
				else
				{
					logger.info("file transfer not yet happend for this profiles");
				}
				
				
				
				System.out.println(lp.readProperty("G10EditInboundTC010_searchTransmitter"));
				
				System.out.println(lp.readProperty("G10EditInboundTC010_sftUserID"));
			
				System.out.println(lp.readProperty("G10EditInboundTC010_fileName"));
				
					
				
				
			if(TransmitterName.equals(lp.readProperty("G10EditInboundTC010_searchTransmitter")) && UserName.equals(lp.readProperty("G10EditInboundTC010_sftUserID")) && Filename.equals(lp.readProperty("G10EditInboundTC010_fileName"))&&(testCasesucessFlag1==true))
				
				
			{
				screenshotnumber++;
				screenshotname = tcname + "_" + screenshotnumber;
				screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
				
				testCasesucessFlag = true;
				
			}	
				
				
			else{
				testCasesucessFlag = false;
				screenshotnumber++;
				screenshotname = tcname + "_" + screenshotnumber;
				screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			}    
			    		
					
				
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);

			cmd.click(".//*[@id='menu']/dl[7]/a/img", "xpath");
			fdriver.switchTo().alert().accept();
			Thread.sleep(3000);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Test Case Failed");
			cmd.click(".//*[@id='menu']/dl[7]/a/img", "xpath");
			fdriver.switchTo().alert().accept();
			cmd.wait(5000);
			Assert.fail(e.getMessage());
		}
		
		finally {
		TestcaseLookup tl = new TestcaseLookup(logger);
		testCaseList = tl.lookupTestcase(FrameworkConstants.TCLookup,
				"G10EditInboundTC010");
		LoadProperties lp1 = new LoadProperties(FrameworkConstants.RunIdFile);
		runIdFile = (lp1.readProperty("RUNID"));
		wtr = new WriteTestResult();

		if (testCasesucessFlag) {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating " + testCaseList.get(i)
						+ " status as Passed");

				wtr.writeToFile(runIdFile,
						"G10EditInboundTC010," + testCaseList.get(i) + ",Passed");
			}
		} else {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating" + testCaseList.get(i) + "status as Failed");

				wtr.writeToFile(runIdFile,"G10EditInboundTC010," + testCaseList.get(i) + ",Failed");
			}

		}
		
		}

	}

	}


				
				
				
				
				
				
				
				
			