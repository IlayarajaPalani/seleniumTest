package com.amex.tp.scripts;


import java.io.File;
import java.io.FileOutputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipOutputStream;

import org.openqa.selenium.WebDriver;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import bsh.ParseException;

import com.amex.tp.common.CreateZip;
import com.amex.tp.common.FrameworkConstants;
import com.amex.tp.common.LoadProperties;
import com.amex.tp.common.ScreenShot;
import com.amex.tp.common.TP_Login;
import com.amex.tp.common.TestcaseLookup;
import com.amex.tp.common.WriteTestResult;
import com.amex.tp.common.commandManager;

@Test
public class G11DeleteFileFlowTC001 {

	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G11DeleteFileFlowTC001.class);

	Map<String, Object> connectionmap;
	ScreenShot screenPrint;
	String runIdFile;
	List<String> testCaseList;
	WriteTestResult wtr;
	WebDriver fdriver;
	String filePath = FrameworkConstants.ScreenShots + "/G11DeleteFileFlowTC001/G11DeleteFileFlowTC001.zip";
	String screenshotname;
	int screenshotnumber = 1;
	String loginscreenshot;
	File folder;
	CreateZip zipfile = null;
	ZipOutputStream zos = null;
	FileOutputStream fos = null;
	boolean testCasesucessFlag=false;
	commandManager cmd;
	@Parameters({ "TestCaseName", "Browser" })
	public void addFileFlow(String tcname, String browser) throws InterruptedException,ParseException, Throwable {
		LoadProperties lp = new LoadProperties(FrameworkConstants.G11_Props);
		String tcid = ""; cmd=commandManager.getInstance(browser,tcid);
		try {
			folder = new File(FrameworkConstants.ScreenShots + "/G11DeleteFileFlowTC001");
			if (folder.mkdir()) {
				// System.out.println("Directory is created!");
				logger.info("Group Folder Created");
			} else {
				logger.info("Directory Already Exists. Results will be added to the existing folder.");
				// System.out.println("Directory Already Exists!");
			}
		} catch (Exception e) {
			logger.info("Group Folder Creation Failed");
			// System.out.println("exception is:"+ e);
		}
		try {
			TP_Login tp = new TP_Login(logger,browser,cmd);;
			connectionmap = tp.HlogintoTP(browser, zos);
			fdriver = (WebDriver) connectionmap.get("fdriver");
			screenPrint = new ScreenShot();
			screenshotname = tcname + "_" + screenshotnumber;
			System.out.println("Screenshot: " + screenshotname);
			System.out.println(folder.getAbsolutePath());
			//screenshotnumber++;
			Thread.sleep(FrameworkConstants.SleepValue);
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			System.out.println("The  screen shot " + screenshotnumber+ " got added");
			
			
			cmd.click("html/body/table[2]/tbody/tr/td[1]/form/div/dl[5]/dt/img", "xpath");
			cmd.click("html/body/table[2]/tbody/tr/td[1]/form/div/dl[5]/dd/a[2]/img", "xpath");
			String tcf = null;
			tcf = lp.readProperty("G11DeleteFF001_fileflowname")+System.currentTimeMillis();
			cmd.type("fileFlowName", "name",(tcf));
			cmd.type("description", "name",lp.readProperty("G11DeleteFF001_description"));
			cmd.selectByValue("owner", "name", lp.readProperty("G11DeleteFF001_owner"));
			screenshotnumber++;
			screenshotname=tcname+"_"+screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			System.out.println("Add file flow main screen steps completed -- "+G11DeleteFileFlowTC001.class);
			logger.info("Add Catalog Step");
			cmd.click("AddNewStepType", "name");
			cmd.selectByValue("stepTypeCd", "name", lp.readProperty("G11DeleteFF001_catalog"));
			cmd.click("Save", "name");
			
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			System.out.println(" Add New StepType screen steps completed  --  "+G11DeleteFileFlowTC001.class);
			logger.info("Add Mailbox Step");
			cmd.click("AddNewStepType", "name");
			cmd.selectByValue("stepTypeCd", "name", lp.readProperty("G11DeleteFF001_mailbox"));
			cmd.click("destXmitterChkBox", "name");
			cmd.type("destXmitter","name",lp.readProperty("G11DeleteFF001_destTrans"));
			cmd.click("SearchImage", "name");
			cmd.click("html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td/table/tbody/tr[3]/td[1]/a", "xpath");
			cmd.selectByText("destUserId", "name", lp.readProperty("G11DeleteFF001_destUser"));
			cmd.click("mailBoxFileNameChkBox", "name");
			cmd.type("mailBoxFileName", "name", lp.readProperty("G11DeleteFF001_Filename"));
			cmd.click("mailBoxNotificationChkBox", "name");
			cmd.click("emailEncDecStatusCd", "name");
			cmd.type("mailBoxEmail", "name", lp.readProperty("G11DeleteFF001_mail"));
			cmd.click("Add", "name");
			
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			cmd.click("Save", "name");
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			logger.info("Click Save to Add File Flow");
			cmd.click("AddFFSave","name");
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			System.out.println("File Flow added successfully screen step completed  --  "+G11DeleteFileFlowTC001.class);
			String Succmsg = cmd.getContent("html/body/table[2]/tbody/tr/td[2]/form/div[2]/table[1]/tbody/tr/td[3]/font", "xpath");
			if(Succmsg.contains("***File Flow added successfully*** ***Replication verification is successful***")){
			  System.out.println("File Flow Added Successfully  --  "+G11DeleteFileFlowTC001.class);
			  	
			  	logger.info("Search for the Added File Flow");
			  	cmd.click("/html/body/table[2]/tbody/tr/td[1]/form/div/dl[5]/dt/img", "xpath");
				cmd.click("/html/body/table[2]/tbody/tr/td[1]/form/div/dl[5]/dd/a[1]/img", "xpath");
				cmd.type("fileFlowName", "name",(tcf));
				
				screenshotnumber++;
				screenshotname=tcname+"_"+screenshotnumber;
				screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
				
				System.out.println("Add file flow main screen steps completed -- "+G11DeleteFileFlowTC001.class);
				
				logger.info("Delete File Flow scenario started");
				
				cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td/input[1]", "xpath"); //search button
				if(cmd.ifExists(tcf, "partialLinkText", 1 ,500)){
					cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td/table/tbody/tr[3]/td[4]/a/img", "xpath");
	            	   String parentWindowHandler = fdriver.getWindowHandle(); //This code represents the control is with current window.
	     		       String subWindowHandler = null; 
	     		       Set<String> handles = fdriver.getWindowHandles();
	     		       java.util.Iterator<String> iterator = handles.iterator();
	     		      while (iterator.hasNext()){
	     		    	  if(subWindowHandler=="Confirm"){
	     	     		       fdriver.switchTo().window(subWindowHandler); // Control is shifted to Pop up
	     	     		       }
	     	     		       else
	     	     		       {
	     	     		    	  subWindowHandler = iterator.next();
	     	     		    	  fdriver.switchTo().window(subWindowHandler);
	     	     		       }
	     		       }
	   
	     		    fdriver.switchTo().window(subWindowHandler);
	     		    Thread.sleep(FrameworkConstants.SleepValue);
	            	cmd.click("html/body/table/tbody/tr[2]/td/button[1]", "xpath"); // Do actions in the pop up window.
	            	logger.info("Confirmed");
	            	fdriver.switchTo().window(parentWindowHandler); // Instructing the driver to move the control to the Parent window
					logger.info("Delete Confirmation Pop up Closed");
					Succmsg = cmd.getContent("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table[1]/tbody/tr/td[3]/font", "xpath");
					if(Succmsg.contains("**FileFlow is deleted successfully*** ***Replication verification is successful***")){
						logger.info("G11DeleteFileFlowTC001 succeeded");
						testCasesucessFlag=true;
					}else{ 
						logger.info("G11DeleteFileFlowTC001 failed");
						testCasesucessFlag=false;
					}
				}
				else{
					logger.info("Created File Flow not found to perform delete Action");
					testCasesucessFlag=false;
				}
			}else{
				logger.info("Add File Flow scenario failed");
				testCasesucessFlag=false;
			}
			
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			
			Thread.sleep(FrameworkConstants.SleepValue);
			cmd.click("//*[@id='menu']/dl[3]/dt/img", "xpath"); // Click on Transmitter Profile/ Config Link
			
			logger.info("Logging out from the Application");
			cmd.click("//img[contains(@src, 'Logout.jpg')]", "xpath");
			fdriver.switchTo().alert().accept();
			Thread.sleep(3000);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Test Case Failed");
			//cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			logger.info("Logging out from the Application");
			cmd.click("//img[contains(@src, 'Logout.jpg')]", "xpath");
			fdriver.switchTo().alert().accept();
			cmd.wait(5000);
			Assert.fail(e.getMessage());

		}
		
		finally{

		TestcaseLookup tl = new TestcaseLookup(logger);
		System.out.println("Test Case Look up done");
		testCaseList = tl.lookupTestcase(FrameworkConstants.TCLookup, "G11DeleteFileFlowTC001");
		System.out.println("Read the test case look up file done");
		LoadProperties lp1 = new LoadProperties(FrameworkConstants.RunIdFile);
		runIdFile = (lp1.readProperty("RUNID"));
		System.out.println("Writing the Test Result in the output file");
		wtr = new WriteTestResult();

		if (testCasesucessFlag) {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating " + testCaseList.get(i)
						+ " status as Passed");

				wtr.writeToFile(runIdFile, "G11DeleteFileFlowTC001," + testCaseList.get(i) + ",Passed");
			}
		} else {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating" + testCaseList.get(i) + "status as Failed");

				wtr.writeToFile(runIdFile,"G11DeleteFileFlowTC001," + testCaseList.get(i) + ",Failed");
			}

		}
		}

	}

}