
package com.amex.tp.scripts;

import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipOutputStream;

import org.openqa.selenium.WebDriver;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.amex.tp.common.CreateZip;
import com.amex.tp.common.ExcelReader;
import com.amex.tp.common.FrameworkConstants;
import com.amex.tp.common.LoadProperties;
import com.amex.tp.common.ScreenShot;
import com.amex.tp.common.TP_Login;
import com.amex.tp.common.TestcaseLookup;
import com.amex.tp.common.WriteTestResult;
import com.amex.tp.common.commandManager;

import bsh.ParseException;

public class G11DeleteFileFlowTC009 {
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G11DeleteFileFlowTC009.class);
	Map<String, Object> connectionmap;
	ScreenShot screenPrint;
	String runIdFile;
	List<String> testCaseList;
	WriteTestResult wtr;
	WebDriver fdriver;
	String filePath = FrameworkConstants.ScreenShots+"/G11DeleteFileFlowTC009/G11DeleteFileFlowTC009.zip";
	String screenshotname;
	int screenshotnumber = 0;
	String loginscreenshot;
	File folder;
	CreateZip zipfile = null;
	ZipOutputStream zos = null;
	FileOutputStream fos = null;
	boolean testCasesucessFlag=false;

	commandManager cmd;
	

	@Parameters({ "TestCaseName", "Browser" })
	@Test
	public void addBasicUser(String tcname, String browser) throws InterruptedException,ParseException, Throwable {
		LoadProperties lp = new LoadProperties(FrameworkConstants.G11_Props);
		
		
		String tcid = ""; cmd=commandManager.getInstance(browser,tcid);

		try {
			folder = new File(FrameworkConstants.ScreenShots+"/G11DeleteFileFlowTC009");

			if (folder.mkdir()) {
				logger.info("Group Folder Created");
				
			} else {
				logger.info("Directory Already Exists. Results will be added to the existing folder.");
				
			}
		} catch (Exception e) {
			logger.info("Group Folder Creation Failed");
			// System.out.println("exception is:"+ e);
		}

		try{
			TP_Login tp = new TP_Login(logger, browser, cmd);
			connectionmap = tp.HlogintoTP(browser, zos);
			fdriver = (WebDriver) connectionmap.get("fdriver");
			screenPrint = new ScreenShot();
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			
			System.out.println("Screenshot: " + screenshotname);
			System.out.println(folder.getAbsolutePath());
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			System.out.println("The  screenshot " + screenshotnumber+ " got added");
			Thread.sleep(FrameworkConstants.SleepValue);
		
			
			
			logger.info("Adding the file flow before deleting it");
			
			logger.info("click on Maintain File Flow");
			cmd.click(".//*[@id='menu']/dl[5]/dt/img", "xpath");
			
			logger.info("Click on Add File Flow");
			cmd.click(".//*[@id='smenu2']/a[2]/img", "xpath");
			
			logger.info("Enter the required details");
			String name = lp.readProperty("G11DeleteFileFlowC009_fileflowname")+System.currentTimeMillis();
			cmd.type("fileFlowName", "name",name);
			cmd.type("description", "name",lp.readProperty("G11DeleteFileFlowC009_description"));
			cmd.selectByValue("owner", "name", lp.readProperty("G11DeleteFileFlowC009_owner"));
			  
			cmd.click("AddNewStepType", "name");
			cmd.selectByValue("stepTypeCd", "name", lp.readProperty("G11DeleteFileFlowC009_catalog"));
			cmd.click("fileEncDecStatusChkBox", "name");
			cmd.click("html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td[2]/label[1]/input", "xpath");
			cmd.click("//*[@id='PGP']/table/tbody/tr[1]/td[2]/input[2]", "xpath"); //Click Decrypt
			cmd.selectByValue("encryptionPackageCd", "name", lp.readProperty("G11DeleteFileFlowC009_PGP"));
			cmd.selectByValue("authenticationTypeCd", "name", lp.readProperty("G11DeleteFileFlowC009_authenticationTypeCd"));
			Thread.sleep(FrameworkConstants.SleepValue);
			
			if(lp.readProperty("G11DeleteFileFlowC009_signatureSelected").equals("Yes"))
			{
				cmd.click("//*[@id='PGP']/table/tbody/tr[5]/td/table/tbody/tr/td[2]/input[1]", "xpath");// click on Yes Radio button
			}
			else
			{
				cmd.click("html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[7]/td/div/table/tbody/tr[6]/td/table/tbody/tr[1]/td[2]/input[2]", "xpath");// click on No Radio button
			}

			
			//Read the public key from Excel 
			//cmd.type("publicKeyName", "name",lp.readProperty("G3AddUserTC004_publicKeyName")+System.currentTimeMillis());
			HashMap<String, String> dataMap = ExcelReader.loadExcelLines(FrameworkConstants.ExecutionSheet, "PUBLICKEY");
			cmd.type("//*[@id='PGP']/table/tbody/tr[5]/td/table/tbody/tr[4]/td[2]/textarea", "xpath", dataMap.get("G11DeleteFileFlowTC009"));
		
			cmd.type("password", "name",lp.readProperty("G11DeleteFileFlowC009_password"));
			cmd.type("confirmPassword", "name",lp.readProperty("G11DeleteFileFlowC009_password"));
			
						
			cmd.click("html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[14]/td/input[1]", "xpath");
			
			cmd.click("html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td/input[2]", "xpath"); //Click on Save
			
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			System.out.println("File Flow added successfully screen step completed  --  "+G11DeleteFileFlowTC009.class);
			
			
			
			logger.info("******* Starting with Delete File Flow Test case ****");
				
			
			logger.info("Clik on Maintain File Flow");
			cmd.click("//*[@id='menu']/dl[5]/dt/img","xpath");
			
			logger.info("Click on Search  File Flows");
			cmd.click("//*[@id='smenu2']/a[1]/img", "xpath");
	
			logger.info("Enter File Flow Name");
			cmd.type("//input[@name='fileFlowName']", "xpath", name);
					
			logger.info("Click on Search Button after entering the Name");
			cmd.click("//input[@name='Search']", "xpath");
			
			logger.info("Click on the File Flow Name");
			cmd.click("html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td/table/tbody/tr[3]/td[1]/a","xpath");
			
			logger.info("Click on Edit Button");
			cmd.click("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td/input[1]", "xpath");
			
			logger.info("Click on Catalog Link to verify its properties");
			cmd.click("//*[@id='usertable']/tbody/tr[3]/td[2]/a", "xpath");
			
			logger.info("Capturing the catalog property screenshot");
			Thread.sleep(FrameworkConstants.SleepValue);
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			logger.info("Click on Cancel Button after taking screenshot");
			cmd.click("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[11]/td/input[2]", "xpath");
			
			logger.info("Click on Cancel from Maintain File Flow Page");
			cmd.click("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td/input[3]", "xpath");
			
			
			if(cmd.ifExists(name, "partialLinkText", 1 ,500)){
				cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td/table/tbody/tr[3]/td[4]/a/img", "xpath");
         	   String parentWindowHandler = fdriver.getWindowHandle(); //This code represents the control is with current window.
  		       String subWindowHandler = null; 
  		       Set<String> handles = fdriver.getWindowHandles();
  		       java.util.Iterator<String> iterator = handles.iterator();
  		      while (iterator.hasNext()){
  		    	  if(subWindowHandler=="Confirm"){
  	     		       fdriver.switchTo().window(subWindowHandler); // Control is shifted to Pop up
  	     		       }
  	     		       else
  	     		       {
  	     		    	  subWindowHandler = iterator.next();
  	     		    	  fdriver.switchTo().window(subWindowHandler);
  	     		       }
  		       }

  		    fdriver.switchTo().window(subWindowHandler);
  		  Thread.sleep(FrameworkConstants.SleepValue);
         	cmd.click("html/body/table/tbody/tr[2]/td/button[1]", "xpath"); // Do actions in the pop up window.
         	logger.info("Confirmed");
         	fdriver.switchTo().window(parentWindowHandler); // Instructing the driver to move the control to the Parent window
  		       
				//cmd.click("/html/body/table/tbody/tr[2]/td/button[1]", "xpath");
				//fdriver.switchTo().window(parentWindowHandler);
				String ScsMsg = cmd.getContent("html/body/table[2]/tbody/tr/td[2]/form/div[2]/table[1]/tbody/tr/td[3]/font", "xpath");
				if(ScsMsg.equals("**FileFlow is deleted successfully*** ***Replication verification is successful***")){
					testCasesucessFlag = true;
					System.out.println("FileFlow deletion is successful");
				}
				else{
					testCasesucessFlag= false;
					System.out.println("Delete FileFlow Action is failed");
				}
				}
			
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
				
			//cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			logger.info("Logging out from the Application");
			cmd.click("//img[contains(@src, 'Logout.jpg')]", "xpath");
			fdriver.switchTo().alert().accept();
			Thread.sleep(3000);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Test Case Failed");
			//cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			logger.info("Logging out from the Application");
			cmd.click("//img[contains(@src, 'Logout.jpg')]", "xpath");
			fdriver.switchTo().alert().accept();
			cmd.wait(5000);
			Assert.fail(e.getMessage());
		}finally{
		
			TestcaseLookup tl = new TestcaseLookup(logger);
			testCaseList = tl.lookupTestcase(FrameworkConstants.TCLookup, "G11DeleteFileFlowC009");
			LoadProperties lp1 = new LoadProperties(FrameworkConstants.RunIdFile);
			runIdFile = (lp1.readProperty("RUNID"));
			wtr = new WriteTestResult();
		
			if (testCasesucessFlag) {
				for (int i = 0; i < testCaseList.size(); i++) {
			System.out.println("Updating " + testCaseList.get(i)
					+ " status as Passed");

			wtr.writeToFile(runIdFile,
					"G11DeleteFileFlowC009," + testCaseList.get(i) + ",Passed");
		}
			} else {
				for (int i = 0; i < testCaseList.size(); i++) {
					System.out.println("Updating" + testCaseList.get(i) + "status as Failed");
		
					wtr.writeToFile(runIdFile,"G11DeleteFileFlowC009," + testCaseList.get(i) + ",Failed");
				}

	}

}
	}
	
}	