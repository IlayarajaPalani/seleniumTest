package com.amex.tp.scripts;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipOutputStream;

import javax.sound.midi.MidiDevice.Info;
import javax.xml.xpath.XPath;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.server.handler.FindElement;
import org.openqa.selenium.support.FindBy;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import bsh.ParseException;

import com.amex.tp.common.CreateZip;
import com.amex.tp.common.FrameworkConstants;
import com.amex.tp.common.LoadProperties;
import com.amex.tp.common.ScreenShot;
import com.amex.tp.common.TP_Login;
import com.amex.tp.common.TestcaseLookup;
import com.amex.tp.common.WriteTestResult;
import com.amex.tp.common.commandManager;

public class G17DeleteWorkGroupTC002 {
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G17DeleteWorkGroupTC002.class);
	Map<String, Object> connectionmap;
	ScreenShot screenPrint;
	String runIdFile;
	List<String> testCaseList;
	WriteTestResult wtr;
	WebDriver fdriver;
	String filePath = FrameworkConstants.ScreenShots+"/G17DeleteWorkGroupTC002/G17DeleteWorkGroupTC002.zip";
	String screenshotname;
	int screenshotnumber = 1;
	String loginscreenshot;
	File folder;
	CreateZip zipfile = null;
	ZipOutputStream zos = null;
	FileOutputStream fos = null;
	boolean testCasesucessFlag=false;
	commandManager cmd;
	List<String> ls;
	boolean succmsg;
	String respmsg;
	String succmsg1;

//	public static void main(String[] args) throws ParseException, InterruptedException, Throwable{
//		G17DeleteWorkGroupTC002 g3 = new G17DeleteWorkGroupTC002();
//		g3.addBasicUser("G17DeleteWorkGrpTC002", "IE");
//	}

	@Parameters({ "TestCaseName", "Browser" })
	@Test
	public void addBasicUser(String tcname, String browser) throws InterruptedException,ParseException, Throwable {
		LoadProperties lp = new LoadProperties(FrameworkConstants.G17_Props);
		String tcid = ""; cmd=commandManager.getInstance(browser,tcid);

		try {
			folder = new File(FrameworkConstants.ScreenShots+"/G17DeleteWorkGroupTC002");

			if (folder.mkdir()) {
				// System.out.println("Directory is created!");
				logger.info("Group Folder Created");
			} else {
				logger.info("Directory Already Exists. Results will be added to the existing folder.");
				// System.out.println("Directory Already Exists!");
			}
		} catch (Exception e) {
			logger.info("Group Folder Creation Failed");
			// System.out.println("exception is:"+ e);
		}

		try{
			TP_Login tp = new TP_Login(logger, browser, cmd);
			connectionmap = tp.HlogintoTP(browser, zos);
			fdriver = (WebDriver) connectionmap.get("fdriver");
			screenPrint = new ScreenShot();
			screenshotname = tcname + "_" + screenshotnumber;
			System.out.println("Screenshot: " + screenshotname);
			System.out.println(folder.getAbsolutePath());
			// System.out.println(fdriver.getCurrentUrl());
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);

			System.out.println("The  screen shot " + screenshotnumber+ " got added");
			logger.info("The  screen shot " + screenshotnumber + " got added");
			Thread.sleep(FrameworkConstants.SleepValue);
			
			logger.info("clicking on maintain security");
			cmd.click("//*[@id='menu']/dl[7]/dt/img", "xpath");// clicking on maintain security
			logger.info("clicking on maintain work groups");
			cmd.click("//*[@id='smenu4']/a[1]/img", "xpath");// clicking on maintain workgroups
			
			logger.info("clicking on the add work grp button");
			cmd.click("//*[@id='userdetails']/tbody/tr[24]/td/input", "xpath");// clicking on the add work grp button
			String workgrpname="AG17DeleteWorkGrpTC001"+System.currentTimeMillis();
			System.out.println(workgrpname);
			logger.info("entering the work grp name");
			cmd.type("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[1]/input", "xpath", workgrpname);// entering the work grp name
			logger.info("entering the work grp abbrevation");
			String abbrevation ="a-"+System.currentTimeMillis();
			//System.out.println(abbrevation);
			cmd.type("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[2]/input", "xpath",abbrevation);//entering the work grp abbrevation
			//cmd.type("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[2]/input", "xpath", "jkgfuid");
			Thread.sleep(FrameworkConstants.SleepValue);
			logger.info("entering the contact first name");
			cmd.type("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[1]/input", "xpath", "fname");//entering the contact first name
			logger.info("entering the contact last name");
			cmd.type("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[2]/input", "xpath", "lname");//entering the contact last name
			logger.info("entering phone");
			cmd.type("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[1]/input", "xpath", "123456789");//entering phone
			logger.info("entering email");
			cmd.type("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[2]/input", "xpath", "a@a.com");//entering email
			logger.info("selecting business unit");
			cmd.selectByValue("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td/select", "xpath", lp.readProperty("G17DeleteWorkGrpTC001_BusinessUnit"));// selecting business unit.
			logger.info("enetering privilage class");
			cmd.type("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td/input[1]", "xpath", lp.readProperty("G17DeleteWorkGrpTC002_PrivilageClass"));//enetering privilage class
			logger.info("enetering privilage class description");
			cmd.type("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td/input[2]", "xpath", lp.readProperty("G17DeleteWorkGrpTC002_PrivilageClass"));// enetering privilage class description
			logger.info("clicking on add button");
			cmd.click("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td/input[3]", "xpath");// clicking on add button
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);

			System.out.println("The  screen shot " + screenshotnumber+ " got added");
			logger.info("The  screen shot " + screenshotnumber + " got added");
			
			logger.info("clicking on the save button");
			cmd.click("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[8]/td/input[1]", "xpath");// clicking on the save button
			
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);

			System.out.println("The  screen shot " + screenshotnumber+ " got added");
			logger.info("The  screen shot " + screenshotnumber + " got added");

			logger.info("clicking on maintain transmitter.");
			cmd.click(".//*[@id='menu']/dl[4]/dt/img", "xpath");  // clicking on maintain transmitter.
			logger.info("clicking on search transmitter.");
			cmd.click(".//*[@id='smenu1']/a[1]/img", "xpath");// clicking on search transmitter.
			logger.info("opening a transmitter");
			logger.info("enetring the transmitter name.");
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[1]/input", "xpath", lp.readProperty("G17DeleteWorkGrpTC002_trasmittername")); // enetring the transmitter name.
			logger.info("clicking on search");
			cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[8]/td/input[1]", "xpath");// clicking on search
			logger.info("clicking on transmitter");
			cmd.click(".//*[@id='userdetails1']/tbody/tr[3]/td[1]/a", "xpath");// clicking on transmitter
			logger.info("clicking on users tab.");
			cmd.click(".//*[@id='tabPane1']/div[1]/h2[1]/a","xpath"); // clicking on users tab.
			logger.info("clicking on add user button ");
			cmd.click(".//*[@id='SubButton']/input", "xpath");//clicking on add user button 
			logger.info("entering all the user details.");
			
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[1]/input", "xpath",lp.readProperty("G17DeleteWorkGrpTC002_username")+System.currentTimeMillis());
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[1]/input", "xpath",lp.readProperty("G17DeleteWorkGrpTC002_fname"));
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[2]/input", "xpath",lp.readProperty("G17DeleteWorkGrpTC002_lname"));
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td[1]/input", "xpath",lp.readProperty("G17DeleteWorkGrpTC002_phone"));
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td[2]/input", "xpath",lp.readProperty("G17DeleteWorkGrpTC002_mail"));
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[8]/td/div[1]/table/tbody/tr[3]/td/input", "xpath",lp.readProperty("G17DeleteWorkGrpTC002_pwd"));
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[8]/td/div[1]/table/tbody/tr[4]/td/input", "xpath",lp.readProperty("G17DeleteWorkGrpTC002_pwd"));
			cmd.selectByText(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[2]/select", "xpath", abbrevation);

			cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/input[1]", "xpath"); // clicking on save.
                 
			
			logger.info("clicking on maintain security");
			cmd.click("//*[@id='menu']/dl[7]/dt/img", "xpath");// clicking on maintain security
			logger.info("clicking on maintain work groups");
			cmd.click("//*[@id='smenu4']/a[1]/img", "xpath");// clicking on maintain workgroups
			
			logger.info("Searching the Node");
			
			 for (int i = 3; i < 23; i++) 
	            {
					
	            	String Xpathofworkgrp = ".//*[@id='userdetails']/tbody/tr["+i+"]/td[1]/a";
	            	if(cmd.getContent(Xpathofworkgrp, "xpath").trim().contains(abbrevation))
	            	{
	            		String Xpathofdelete= ".//*[@id='userdetails']/tbody/tr["+i+"]/td[5]/a/img";
	            		cmd.click(Xpathofdelete, "xpath");
	            		Thread.sleep(FrameworkConstants.SleepValue);
	            		
	            		String parentWindowHandler = fdriver.getWindowHandle(); //This code represents the control is with current window.
	     		       String subWindowHandler = null; 
	     		       Set<String> handles = fdriver.getWindowHandles();
	     		       java.util.Iterator<String> iterator = handles.iterator();
	     		       while (iterator.hasNext()){
	     		       subWindowHandler = iterator.next();
	     		       }
	     		       fdriver.switchTo().window(subWindowHandler); // Control is shifted to Pop up
	     		      
	     		       cmd.click("html/body/table/tbody/tr[2]/td/button[1]", "xpath"); // Do actions in the pop up window.
	     		       
	     		       logger.info("Confirmation Pop up closed");
	     		                           
	     		       fdriver.switchTo().window(parentWindowHandler); // Instructing the driver to move the control to the Parent window
	     		       
	     		      Thread.sleep(FrameworkConstants.SleepValue);
	     			
	     		       succmsg1=cmd.getContent(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table[1]/tbody/tr/td[3]/ul/font/li", "xpath");
	     		       
	     		      screenshotnumber++;
	     				screenshotname = tcname + "_" + screenshotnumber;
	     				screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);

	     				System.out.println("The  screen shot " + screenshotnumber+ " got added");
	     				logger.info("The  screen shot " + screenshotnumber + " got added");
	            	}
					
				}
		

			if(succmsg1.trim().contains("Cannot Delete.Workgroup associated with User(s)")){
					testCasesucessFlag = true;
					logger.info("test case passed");
				}
				else{
					testCasesucessFlag = false;
					logger.info("test case failed");
				}

			
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);

			logger.info("Logging out from the Application");
			cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			Thread.sleep(FrameworkConstants.SleepValue);
			fdriver.switchTo().alert().accept();
			Thread.sleep(3000);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Test Case Failed");
			cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			fdriver.switchTo().alert().accept();
			cmd.wait(5000);
			Assert.fail(e.getMessage());

		}
		
		finally{


		TestcaseLookup tl = new TestcaseLookup(logger);
		testCaseList = tl.lookupTestcase(FrameworkConstants.TCLookup, "G17DeleteWorkGroupTC002");
		LoadProperties lp1 = new LoadProperties(FrameworkConstants.RunIdFile);
		runIdFile = (lp1.readProperty("RUNID"));
		wtr = new WriteTestResult();

		if (testCasesucessFlag) {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating " + testCaseList.get(i)
						+ " status as Passed");

				wtr.writeToFile(runIdFile,
						"G17DeleteWorkGroupTC002," + testCaseList.get(i) + ",Passed");
			}
		} else {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating" + testCaseList.get(i) + "status as Failed");

				wtr.writeToFile(runIdFile,"G17DeleteWorkGroupTC002," + testCaseList.get(i) + ",Failed");
			}

		}

		}
		}

}
