package com.amex.tp.scripts;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.zip.ZipOutputStream;

import javax.sound.midi.MidiDevice.Info;
import javax.xml.xpath.XPath;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.server.handler.FindElement;
import org.openqa.selenium.support.FindBy;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import bsh.ParseException;

import com.amex.tp.common.CreateZip;
import com.amex.tp.common.FrameworkConstants;
import com.amex.tp.common.LoadProperties;
import com.amex.tp.common.ScreenShot;
import com.amex.tp.common.TP_Login;
import com.amex.tp.common.TestcaseLookup;
import com.amex.tp.common.WriteTestResult;
import com.amex.tp.common.commandManager;

public class G11DeleteFileFlowTC004 {
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G11DeleteFileFlowTC004.class);
	Map<String, Object> connectionmap;
	ScreenShot screenPrint;
	String runIdFile;
	List<String> testCaseList;
	WriteTestResult wtr;
	WebDriver fdriver;
	String filePath = FrameworkConstants.ScreenShots+"/G11DeleteFileFlowTC004/G11DeleteFileFlowTC004.zip";
	String screenshotname;
	int screenshotnumber = 1;
	String loginscreenshot;
	File folder;
	CreateZip zipfile = null;
	ZipOutputStream zos = null;
	FileOutputStream fos = null;
	boolean testCasesucessFlag=false;
	commandManager cmd;
	//String fileflow;
	String respmsg;
	int mailboxcreationcount=1;


	@Parameters({ "TestCaseName", "Browser" })
	@Test
	public void addBasicUser(String tcname, String browser) throws InterruptedException,ParseException, Throwable {
		LoadProperties lp = new LoadProperties(FrameworkConstants.G11_Props);
		String tcid = ""; cmd=commandManager.getInstance(browser,tcid);

		try {
			folder = new File(FrameworkConstants.ScreenShots+"/G11DeleteFileFlowTC004");

			if (folder.mkdir()) {
				// System.out.println("Directory is created!");
				logger.info("Group Folder Created");
			} else {
				logger.info("Directory Already Exists. Results will be added to the existing folder.");
				// System.out.println("Directory Already Exists!");
			}
		} catch (Exception e) {
			logger.info("Group Folder Creation Failed");
			// System.out.println("exception is:"+ e);
		}

		try{
			TP_Login tp = new TP_Login(logger, browser, cmd);
			connectionmap = tp.HlogintoTP(browser, zos);
			fdriver = (WebDriver) connectionmap.get("fdriver");
			screenPrint = new ScreenShot();
			screenshotname = tcname + "_" + screenshotnumber;
			System.out.println("Screenshot: " + screenshotname);
			System.out.println(folder.getAbsolutePath());
			// System.out.println(fdriver.getCurrentUrl());
			Thread.sleep(FrameworkConstants.SleepValue);
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);

			System.out.println("The  screen shot " + screenshotnumber+ " got added");
			//screenshotnumber++;
			
			
			logger.info(" ** Adding a file flow with 101 mailbox steps and 1 delivery step");
			
			logger.info("click on Maintain File Flow");
            cmd.click("html/body/table[2]/tbody/tr/td[1]/form/div/dl[5]/dt/img", "xpath");//click on Maintain File Flow
			logger.info("Click on Add File Flow");
            cmd.click("html/body/table[2]/tbody/tr/td[1]/form/div/dl[5]/dd/a[2]/img", "xpath");//Click on Add File Flow
			logger.info("Enter File Flow Name");
            String fileflow=lp.readProperty("G11DeleteFileFlowTC004_fileflowname")+System.currentTimeMillis();
			System.out.println("The generated file flow name is : "+ fileflow);
			cmd.type("fileFlowName", "name",fileflow);
			logger.info("Enter the File Flow Description");
			cmd.type("description", "name",lp.readProperty("G11DeleteFileFlowTC004_description"));// enetering file flow description.
			logger.info("Select owner");
			cmd.selectByValue("owner", "name", lp.readProperty("G11DeleteFileFlowTC004_owner")); // enetering the owner.
			//cmd.click("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td/input[1]", "xpath");// clicking on the AddStep button.
			
			screenshotnumber++;
			screenshotname=tcname+"_"+screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			System.out.println("Add file flow main screen steps completed -- "+G11DeleteFileFlowTC004.class);
			
			logger.info("Creating 101 mail box steps");
			System.out.println(mailboxcreationcount);
			while(mailboxcreationcount<102)
			{
				//System.out.println(mailboxcreationcount +" - iteration");
				logger.info("Adding the Mailbox Step of " + mailboxcreationcount );
				cmd.click("AddNewStepType","name");// clicking on the AddStep button.
				cmd.click("Save","name");// clicking on the ok button.
				System.out.println(" mail box  "+mailboxcreationcount+" created");
				mailboxcreationcount++;
			}
			
			screenshotnumber++;
			screenshotname=tcname+"_"+screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			logger.info("Creating delivery step");
			
			screenshotnumber++;
			screenshotname=tcname+"_"+screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			cmd.click("AddNewStepType","name");// clicking on add step
			cmd.selectByValue("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[2]/select", "xpath", lp.readProperty("G11DeleteFileFlowTC004_steptype2"));// selecting the mail box step.
			cmd.click("Save", "name"); // clicking on the ok button.
			
			screenshotnumber++;
			screenshotname=tcname+"_"+screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			logger.info("Saving the File Flow");
			cmd.click("AddFFSave", "name");// clicking on the save button 
			
			logger.info("Searchng the created file flow.");
			cmd.click("html/body/table[2]/tbody/tr/td[1]/form/div/dl[5]/dt/img", "xpath");//click on Maintain File Flow
			cmd.click("//*[@id='smenu2']/a[1]/img", "xpath"); // clicking on the search file flow.
			cmd.type("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[1]/input[1]", "xpath", fileflow);// enetering the file flow.
			cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td/input[1]", "xpath");// clicking on the search button
			logger.info(" Deleting the file flow.");
			cmd.click("//*[@id='userdetails']/tbody/tr[3]/td[4]/a/img", "xpath");  // clicking on the cross button of the file flow
			
			System.out.println("clicking on the x button");
			
			String parentWindowHandler = fdriver.getWindowHandle(); //This code represents the control is with current window.
		       String subWindowHandler = null; 
		       Set<String> handles = fdriver.getWindowHandles();
		       Iterator<String> iterator = handles.iterator();
		       while (iterator.hasNext()){
		       subWindowHandler = iterator.next();
		}
		       fdriver.switchTo().window(subWindowHandler); // Control is shifted to Pop up
		       Thread.sleep(FrameworkConstants.SleepValue);
		       cmd.click("html/body/table/tbody/tr[2]/td/button[1]", "xpath");// clicking on the yes button
		       System.out.println("clicking yes button");
		       logger.info("Confirmation Pop up closed");
               fdriver.switchTo().window(parentWindowHandler); // Instructing the driver to move the control to the main window

               //respmsg=cmd.getContent(".//*[@id='tabPage3']/table/tbody/tr[3]/td[1]/a", "xpath");// getting the response message.
			                
			
			///html/body/table[2]/tbody/tr/td[2]/form/div[2]/table[1]/tbody/tr/td[3]/font
               
            logger.info("Searchng the created file flow.");
   			cmd.click("html/body/table[2]/tbody/tr/td[1]/form/div/dl[5]/dt/img", "xpath");//click on Maintain File Flow
   			cmd.click("//*[@id='smenu2']/a[1]/img", "xpath"); // clicking on the search file flow.
   			cmd.type("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[1]/input[1]", "xpath", fileflow);// enetering the file flow.
   			cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td/input[1]", "xpath");// clicking on the search button
   			respmsg=cmd.getContent("//*[@id='userdetails']/tbody/tr[2]/td/label", "xpath") ;
			


			if(respmsg.equals("No Records Found..!")){
					testCasesucessFlag = true;
					logger.info("The test case - Delete a file flow with  101 mailbox steps and 1 delivery step is passed");
				}
				else{
					testCasesucessFlag = false;
					logger.info("The test case - Delete a file flow with  101 mailbox steps and 1 delivery step is failed");
				}

			
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);

			//cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			logger.info("Logging out from the Application");
			cmd.click("//img[contains(@src, 'Logout.jpg')]", "xpath");
			fdriver.switchTo().alert().accept();
			Thread.sleep(3000);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Test Case Failed");
			//cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			logger.info("Logging out from the Application");
			cmd.click("//img[contains(@src, 'Logout.jpg')]", "xpath");
			fdriver.switchTo().alert().accept();
			cmd.wait(5000);
			Assert.fail(e.getMessage());
		}finally {

		TestcaseLookup tl = new TestcaseLookup(logger);
		testCaseList = tl.lookupTestcase(FrameworkConstants.TCLookup,
				"G11DeleteFileFlowTC004");
		LoadProperties lp1 = new LoadProperties(FrameworkConstants.RunIdFile);
		runIdFile = (lp1.readProperty("RUNID"));
		wtr = new WriteTestResult();

		if (testCasesucessFlag) {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating " + testCaseList.get(i)
						+ " status as Passed");

				wtr.writeToFile(runIdFile,
						"G11DeleteFileFlowTC004," + testCaseList.get(i) + ",Passed");
			}
		} else {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating" + testCaseList.get(i) + "status as Failed");

				wtr.writeToFile(runIdFile,"G11DeleteFileFlowTC004," + testCaseList.get(i) + ",Failed");
			}

		}
		}

	}

}