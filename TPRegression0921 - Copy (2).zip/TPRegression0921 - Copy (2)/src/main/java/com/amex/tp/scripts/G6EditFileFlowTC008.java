package com.amex.tp.scripts;

//Description - Created to Edit the FF with Catalog and Mailbox step

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipOutputStream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import bsh.ParseException;

import com.amex.tp.common.CreateZip;
import com.amex.tp.common.FrameworkConstants;
import com.amex.tp.common.LoadProperties;
import com.amex.tp.common.ScreenShot;
import com.amex.tp.common.TP_Login;
import com.amex.tp.common.TestcaseLookup;
import com.amex.tp.common.WriteTestResult;
import com.amex.tp.common.commandManager;

@Test
public class G6EditFileFlowTC008 {

	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G6EditFileFlowTC008.class);

	Map<String, Object> connectionmap;
	ScreenShot screenPrint;
	String runIdFile;
	List<String> testCaseList;
	WriteTestResult wtr;
	WebDriver fdriver;
	String filePath = FrameworkConstants.ScreenShots
			+ "/G6EditFileFlowTC008/G6EditFileFlowTC008.zip";
	String screenshotname;
	int screenshotnumber = 1;
	String loginscreenshot;
	File folder;
	CreateZip zipfile = null;
	ZipOutputStream zos = null;
	FileOutputStream fos = null;
	boolean testCasesucessFlag=false;
	commandManager cmd;

	@Parameters({ "TestCaseName", "Browser" })
	public void addFileFlow(String tcname, String browser) throws InterruptedException,ParseException, Throwable {

		LoadProperties lp = new LoadProperties(FrameworkConstants.G6_Props);
		String tcid = ""; cmd=commandManager.getInstance(browser,tcid);

		try {
			folder = new File(FrameworkConstants.ScreenShots
					+ "/G6EditFileFlowTC008");

			if (folder.mkdir()) {
				// System.out.println("Directory is created!");
				logger.info("Group Folder Created");
			} else {
				logger.info("Directory Already Exists. Results will be added to the existing folder.");
				// System.out.println("Directory Already Exists!");
			}
		} catch (Exception e) {
			logger.info("Group Folder Creation Failed");
			// System.out.println("exception is:"+ e);
		}

		try {
			TP_Login tp = new TP_Login(logger,browser,cmd);
			connectionmap = tp.HlogintoTP(browser, zos);
			fdriver = (WebDriver) connectionmap.get("fdriver");
			screenPrint = new ScreenShot();
			screenshotname = tcname + "_" + screenshotnumber;
			System.out.println("Screenshot: " + screenshotname);
			System.out.println(folder.getAbsolutePath());
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			System.out.println("The  screen shot " + screenshotnumber+ " got added");
			logger.info("The  screen shot " + screenshotnumber + " got added");
			Thread.sleep(FrameworkConstants.SleepValue);
			
			logger.info("entering maintain file flow,clicking on the search file flow,entering the file flow name and clicking on search");

			cmd.click("/html/body/table[2]/tbody/tr/td[1]/form/div/dl[5]/dt/img", "xpath");// clicking on maintain file flow.
			
			cmd.click("/html/body/table[2]/tbody/tr/td[1]/form/div/dl[5]/dd/a[1]/img", "xpath"); // clicking on the search file flow.
			
			cmd.type("fileFlowName", "name",(lp.readProperty("G6EditFFTC008_fileflowname")));// entering the file flow name.
			
			cmd.click("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td/input[1]", "xpath");// clicking on search
			
			screenshotname=tcname+"_"+screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			
			
			logger.info("entering the file flow,clicking on edit button,clicking on the catalog anchor");
			cmd.click("//*[@id='userdetails']/tbody/tr[3]/td[1]/a","xpath");// clicking on the file flow anchor
			
			cmd.click("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td/input[1]","xpath");//clicking on edit button.
			
			cmd.click("//*[@id='usertable']/tbody/tr[3]/td[2]/a", "xpath");// clicking on the catalog anchor.
			
			screenshotname=tcname+"_"+screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			logger.info("entering the catalog step, clicking the edit button in catalog,clicking on statos check box,"
					+ "enabling encryption/decryption, selecting Encryption/DecryptionPackage,selecting AuthenticationType,clicking on ok button,"
					+"enetering password and confirming");
			
			cmd.click("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/input[1]", "xpath");// clicking the edit button in catalog
			
			cmd.click("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[2]/input", "xpath");// clicking on stats check box.
			
			cmd.click("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[2]/label[1]/input", "xpath");// enabling encryption/decryption.
			
			cmd.click("//*[@id='PGP']/table/tbody/tr[1]/td[2]/input[1]", "xpath");// setting action type as encrypt.
			
			cmd.selectByText("//*[@id='PGP']/table/tbody/tr[2]/td[2]/select", "xpath", lp.readProperty("G6EditFFTC008_Encryption/DecryptionPackage"));// selecting Encryption/DecryptionPackage
			
			cmd.selectByText("//*[@id='PGP']/table/tbody/tr[3]/td[2]/select", "xpath", lp.readProperty("G6EditFFTC008_AuthenticationType"));// selecting AuthenticationType
			
			cmd.click("//*[@id='PGP']/table/tbody/tr[6]/td/table/tbody/tr/td[2]/input[2]", "xpath");// use signature is set to no.
			
			Thread.sleep(FrameworkConstants.SleepValue);
			
			//cmd.type("//*[@id='pubKeyPwdDiv']/table/tbody/tr[1]/td[2]/input", "xpath", lp.readProperty("G6EditFFTC008_Password"));// enetering password.
			fdriver.findElement(By.xpath("//*[@id='pubKeyPwdDiv']/table/tbody/tr[1]/td[2]/input")).sendKeys("password");
			
			//cmd.type("//*[@id='pubKeyPwdDiv']/table/tbody/tr[2]/td[2]/input", "xpath", lp.readProperty("G6EditFFTC008_Password"));// confirming passowrd
			fdriver.findElement(By.xpath("//*[@id='pubKeyPwdDiv']/table/tbody/tr[2]/td[2]/input")).sendKeys("password");
			
			
			
			
			cmd.click("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[12]/td/input[1]", "xpath");// clicking on ok button.
			
			
			logger.info("in maintain file flow now, clicking on the save button.");
			
			cmd.click("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td/input[2]", "xpath");// clicking save button.
			
			String Succmsg = cmd.getContent("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table[1]/tbody/tr/td[3]/font", "xpath");
			
			if(Succmsg.contains("***File Flow updated successfully*** ***Replication verification is successful***")){
			  logger.info("G6EditFFTC008 succeeded");
			  testCasesucessFlag=true;
			  screenshotname=tcname+"_"+screenshotnumber;
				screenshotnumber++;
				screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			}else{
				logger.info("G6EditFFTC008 failed");
				 testCasesucessFlag=false;
				 screenshotname=tcname+"_"+screenshotnumber;
					screenshotnumber++;
					screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			}
				
			System.out.println("Reverting the changes back to the Original for next successful Execution");
			
			cmd.type("fileFlowName", "name",(lp.readProperty("G6EditFFTC008_fileflowname")));// entering the file flow name.
			cmd.click("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td/input[1]", "xpath");// clicking on search
			logger.info("Entering the file flow,clicking on edit button,clicking on the catalog anchor");
			cmd.click("//*[@id='userdetails']/tbody/tr[3]/td[1]/a","xpath");// clicking on the file flow anchor
			cmd.click("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td/input[1]","xpath");//clicking on edit button.
			cmd.click("//*[@id='usertable']/tbody/tr[3]/td[2]/a", "xpath");// clicking on the catalog anchor.
			cmd.click("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[11]/td/input[1]", "xpath"); //Click on Edit Button
			cmd.click("fileEncDecStatusChkBox", "name"); // Check out the Status
			cmd.click("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[12]/td/input[1]", "xpath"); // Click OK
			cmd.click("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td/input[2]", "xpath"); // Click Save
			
			String msg = cmd.getContent("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table[1]/tbody/tr/td[3]/font", "xpath");
			if(msg.contains("File Flow updated successfully"))
			{
				System.out.println("Reverted the changes back");
			}
			
			
			
			System.out.println("Edit file flow main screen steps completed -- "+G6EditFileFlowTC008.class);
			
	
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			fdriver.switchTo().alert().accept();
			Thread.sleep(3000);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Test Case Failed");
			cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			fdriver.switchTo().alert().accept();
			cmd.wait(5000);
			Assert.fail(e.getMessage());
		
		}
		finally	{

		TestcaseLookup tl = new TestcaseLookup(logger);
		testCaseList = tl.lookupTestcase(FrameworkConstants.TCLookup,
				"G6EditFileFlowTC008");
		LoadProperties lp1 = new LoadProperties(FrameworkConstants.RunIdFile);
		runIdFile = (lp1.readProperty("RUNID"));
		wtr = new WriteTestResult();

		if (testCasesucessFlag) {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating " + testCaseList.get(i)
						+ " status as Passed");

				wtr.writeToFile(runIdFile,
						"G6EditFileFlowTC008," + testCaseList.get(i) + ",Passed");
			}
		} else {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating" + testCaseList.get(i) + "status as Failed");

				wtr.writeToFile(runIdFile,"G6EditFileFlowTC008," + testCaseList.get(i) + ",Failed");
			}
		}
		}

	}
	
}
