package com.amex.tp.scripts;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipOutputStream;

import org.openqa.selenium.WebDriver;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import bsh.ParseException;

import com.amex.tp.common.CreateZip;
import com.amex.tp.common.FrameworkConstants;
import com.amex.tp.common.LoadProperties;
import com.amex.tp.common.ScreenShot;
import com.amex.tp.common.TP_Login;
import com.amex.tp.common.TestcaseLookup;
import com.amex.tp.common.WriteTestResult;
import com.amex.tp.common.commandManager;

public class G6EditFileFlowTC007 {
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G6EditFileFlowTC007.class);
	Map<String, Object> connectionmap;
	ScreenShot screenPrint;
	String runIdFile;
	List<String> testCaseList;
	WriteTestResult wtr;
	WebDriver fdriver;
	String filePath = FrameworkConstants.ScreenShots+"/G6EditFileFlowTC007/G6EditFileFlowTC007.zip";
	String screenshotname;
	int screenshotnumber = 1;
	String loginscreenshot;
	File folder;
	CreateZip zipfile = null;
	ZipOutputStream zos = null;
	FileOutputStream fos = null;
	boolean testCasesucessFlag=false;
	commandManager cmd;
	Timestamp time;

	public static void main(String[] args) throws ParseException, InterruptedException, Throwable{
		G6EditFileFlowTC007 g6 = new G6EditFileFlowTC007();
		g6.addBasicUser("G6EditFileFlowTC007", "IE");
	}

	@Parameters({ "TestCaseName", "Browser" })
	@Test
	public void addBasicUser(String tcname, String browser) throws InterruptedException,ParseException, Throwable {
		LoadProperties lp = new LoadProperties(FrameworkConstants.G6_Props);
		String tcid = ""; cmd=commandManager.getInstance(browser,tcid);

		try {
			folder = new File(FrameworkConstants.ScreenShots+"/G6EditFileFlowTC007");

			if (folder.mkdir()) {
				// System.out.println("Directory is created!");
				logger.info("Group Folder Created");
			} else {
				logger.info("Directory Already Exists. Results will be added to the existing folder.");
				// System.out.println("Directory Already Exists!");
			}
		} catch (Exception e) {
			logger.info("Group Folder Creation Failed");
			// System.out.println("exception is:"+ e);
		}

		try{
			TP_Login tp = new TP_Login(logger, browser, cmd);
			connectionmap = tp.HlogintoTP(browser, zos);
			fdriver = (WebDriver) connectionmap.get("fdriver");
			screenPrint = new ScreenShot();
			screenshotname = tcname + "_" + screenshotnumber;
			System.out.println("Screenshot: " + screenshotname);
			System.out.println(folder.getAbsolutePath());
			// System.out.println(fdriver.getCurrentUrl());
			System.out.println("The  screen shot " + screenshotnumber+ " got added");
			logger.info("The  screen shot " + screenshotnumber + " got added");
			Thread.sleep(FrameworkConstants.SleepValue);
		    
			logger.info("Click Maintain File Flow");
			cmd.click(".//*[@id='menu']/dl[5]/dt/img", "xpath");
			logger.info("Click Search File Flow");
			cmd.click(".//*[@id='smenu2']/a[1]/img", "xpath");
			logger.info("Enter Existing File Flow name");
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[1]/input[1]", "xpath", lp.readProperty("G6EditFFTC007_searchfileflow"));
			logger.info("Select WorkGroup Owner");
			cmd.selectByText(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[2]/select","xpath",lp.readProperty("G6EditFFTC007_workgroupOwner"));
			logger.info("Click Search");
			cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td/input[1]","xpath");
			logger.info("Click the file flow");
			cmd.click(".//*[@id='userdetails']/tbody/tr[3]/td[1]/a", "xpath");
			logger.info("Click Edit");
			cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td/input[1]", "xpath");
			logger.info("Click on file flow");
			cmd.click(".//*[@id='usertable']/tbody/tr[3]/td[2]/a", "xpath");
			String Status = cmd.getContent(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[2]", "xpath");
			if(Status.contains("Enabled")){
				screenshotnumber++;
				screenshotname = tcname + "_" + screenshotnumber;
				screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
				logger.info("Click Edit");
				cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[11]/td/input[1]", "xpath");
			}
			else if(Status.contains("Disabled"))
			{
				screenshotnumber++;
				screenshotname = tcname + "_" + screenshotnumber;
				screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
				logger.info("Click Edit");
				cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/input[1]", "xpath");
				logger.info("Click Enable");
				cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[2]/label[1]","xpath");
				logger.info("Select Package");
				cmd.selectByText(".//*[@id='PGP']/table/tbody/tr[2]/td[2]/select", "xpath", lp.readProperty("G6EditFFTC007_encryptionPackage"));
				logger.info("Select Authentication type");
				cmd.selectByText(".//*[@id='PGP']/table/tbody/tr[3]/td[2]/select", "xpath", lp.readProperty("G6EditFFTC007_authenticationType"));
				logger.info("Click on Signature");
				cmd.click(".//*[@id='PGP']/table/tbody/tr[6]/td/table/tbody/tr/td[2]/input[1]", "xpath");
			}
			else if(Status.isEmpty())
			{
				screenshotnumber++;
				screenshotname = tcname + "_" + screenshotnumber;
				screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
				logger.info("Click Edit");
				cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/input[1]", "xpath");
				logger.info("Click on checkbox");
				cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[2]/input", "xpath");
				logger.info("Click Enable");
				cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[2]/label[1]","xpath");
				logger.info("Select Package");
				cmd.selectByText(".//*[@id='PGP']/table/tbody/tr[2]/td[2]/select", "xpath", lp.readProperty("G6EditFFTC007_encryptionPackage"));
				logger.info("Select Authentication type");
				cmd.selectByText(".//*[@id='PGP']/table/tbody/tr[3]/td[2]/select", "xpath", lp.readProperty("G6EditFFTC007_authenticationType"));
				logger.info("Click on Signature");
				cmd.click(".//*[@id='PGP']/table/tbody/tr[6]/td/table/tbody/tr/td[2]/input[1]", "xpath");
			}
			
			//cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[9]/td/input[1]", "xpath");
			//cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[2]/label[1]/input","xpath");
			
			
			
			logger.info("Click Advanced options");
			cmd.click(".//*[@id='PGP']/table/tbody/tr[6]/td/table/tbody/tr[4]/td[2]/input[1]", "xpath");
			logger.info("Click Generate key");
			cmd.click(".//*[@id='PGP']/table/tbody/tr[6]/td/table/tbody/tr[10]/td[2]/input", "xpath");
			logger.info("Enter Password");
			cmd.type(".//*[@id='pubKeyPwdDiv']/table/tbody/tr[1]/td[2]/input", "xpath", lp.readProperty("G6EditFFTC007_pwd"));
			logger.info("Enter Confirm Password");
			cmd.type(".//*[@id='pubKeyPwdDiv']/table/tbody/tr[2]/td[2]/input", "xpath", lp.readProperty("G6EditFFTC007_pwd"));
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			logger.info("Click Ok");
			cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[12]/td/input[1]", "xpath");
			logger.info("Click Save");
			cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td/input[2]", "xpath");
			
			
			
			

			
			
			String Succmsg = cmd.getContent("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table[1]/tbody/tr/td[3]/font", "xpath");
			if(Succmsg.equalsIgnoreCase("***File Flow updated successfully*** ***Replication verification is successful***")){
			  logger.info("G6EditFFTC007 succeeded");
			  testCasesucessFlag=true;
			  			  
			}else{
				logger.info("G6EditFFTC007 failed");
				System.out.println("The Actual message displayed in the application is" + Succmsg);
				 testCasesucessFlag=false;
				 			}
			
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);

			fdriver.quit();
			
		} catch (Exception e) {
			e.printStackTrace();
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			logger.info("G6EditFFTC007 failed"+e.getMessage());
			fdriver.quit();

		}

		TestcaseLookup tl = new TestcaseLookup(logger);
		testCaseList = tl.lookupTestcase(FrameworkConstants.TCLookup,
				"G6EditFileFlowTC007");
		LoadProperties lp1 = new LoadProperties(FrameworkConstants.RunIdFile);
		runIdFile = (lp1.readProperty("RUNID"));
		wtr = new WriteTestResult();

		if (testCasesucessFlag) {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating " + testCaseList.get(i)
						+ " status as Passed");

				wtr.writeToFile(runIdFile,
						"G6EditFileFlowTC007," + testCaseList.get(i) + ",Passed");
			}
		} else {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating" + testCaseList.get(i) + "status as Failed");

				wtr.writeToFile(runIdFile,"G6EditFileFlowTC007," + testCaseList.get(i) + ",Failed");
			}

		}

	}
	
}