package com.amex.tp.scripts;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TimeZone;
import java.util.zip.ZipOutputStream;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.amex.tp.common.CreateZip;
import com.amex.tp.common.ExcelReader;
import com.amex.tp.common.FrameworkConstants;
import com.amex.tp.common.LoadProperties;
import com.amex.tp.common.ScreenShot;
import com.amex.tp.common.TP_Login;
import com.amex.tp.common.TestcaseLookup;
import com.amex.tp.common.WriteTestResult;
import com.amex.tp.common.commandManager;

import bsh.ParseException;

public class G19EditCDNodeTC004 {
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G19EditCDNodeTC004.class);
	Map<String, Object> connectionmap;
	ScreenShot screenPrint;
	String runIdFile;
	List<String> testCaseList;
	WriteTestResult wtr;
	WebDriver fdriver;
	String filePath = FrameworkConstants.ScreenShots+"/G19EditCDNodeTC004/G19EditCDNodeTC004.zip";
	String screenshotname;
	int screenshotnumber;
	String loginscreenshot;
	File folder;
	CreateZip zipfile = null;
	ZipOutputStream zos = null;
	FileOutputStream fos = null;
	boolean testCasesucessFlag=false;
	boolean testCasesucessFlag1=false;
	boolean testCasesucessFlag2=false;
	boolean testCasesucessFlag3=false;
	boolean isnameeditable=true;
	commandManager cmd;
	Timestamp time;
	String responsemsg;

	public static void main(String[] args) throws ParseException, InterruptedException, Throwable{
		G19EditCDNodeTC004 g3 = new G19EditCDNodeTC004();
		g3.addBasicUser("G19EditCDNodeTC004", "IE");
	}

	@Parameters({ "TestCaseName", "Browser" })
	@Test
	public void addBasicUser(String tcname, String browser) throws InterruptedException,ParseException, Throwable {
		LoadProperties lp = new LoadProperties(FrameworkConstants.G19_Props);
		String tcid = ""; cmd=commandManager.getInstance(browser,tcid);

		try {
			folder = new File(FrameworkConstants.ScreenShots+"/G19EditCDNodeTC004");

			if (folder.mkdir()) {
				// System.out.println("Directory is created!");
				logger.info("Group Folder Created");
			} else {
				logger.info("Directory Already Exists. Results will be added to the existing folder.");
				// System.out.println("Directory Already Exists!");
			}
		} catch (Exception e) {
			logger.info("Group Folder Creation Failed");
			// System.out.println("exception is:"+ e);
		}

		try{
			TP_Login tp = new TP_Login(logger, browser, cmd);
			connectionmap = tp.HlogintoTP(browser, zos);
			fdriver = (WebDriver) connectionmap.get("fdriver");
			screenPrint = new ScreenShot();
			System.out.println("Screenshot: " + screenshotname);
			System.out.println(folder.getAbsolutePath());
			// System.out.println(fdriver.getCurrentUrl());
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);

			System.out.println("The  screen shot " + screenshotnumber+ " got added");
			Thread.sleep(FrameworkConstants.SleepValue);
			
			logger.info("Click on Maintain SFT config"); 
			cmd.click(".//*[@id='menu']/dl[6]/dt/img", "xpath");
			
			logger.info(" click on Maintain CD Nodes");
			cmd.click(".//*[@id='smenu3']/a[2]/img", "xpath");
			
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			logger.info(" clicking on the cd node");
			cmd.click(".//*[@id='userdetails']/tbody/tr[3]/td[1]/a", "xpath");
			
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			logger.info("clicking on Edit button");
			cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[12]/td/input[1]", "xpath");
			
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			logger.info("checking if node name is editable");
//			isnameeditable=cmd.ifDisplayed("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[1]/font[2]/input");
//			System.out.println("isnameeditable  :: "+ isnameeditable);
			
			try
			{
				cmd.type("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[1]/font[2]/input", "xpath", "name");
				screenshotnumber++;
				screenshotname = tcname + "_" + screenshotnumber;
				screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			}
			catch(Exception e)
			{
				System.out.println("inside the catch block");
				isnameeditable=false;
			}
			
            
            if(isnameeditable==false){
					testCasesucessFlag = true;
					logger.info("test case G19EditCDNodeTC004 got passed");
					System.out.println("test case G19EditCDNodeTC004 got passed");
				}
				else{
					testCasesucessFlag = false;
					logger.info("test case G19EditCDNodeTC004 got failed");
					System.out.println("test case G19EditCDNodeTC004 got failed");
				}

			
            cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			fdriver.switchTo().alert().accept();
			Thread.sleep(3000);
			
		}catch (Exception e) {
			e.printStackTrace();
			System.out.println("Test Case Failed");
			cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			fdriver.switchTo().alert().accept();
			cmd.wait(5000);
			Assert.fail(e.getMessage());
		
		}finally	{

		TestcaseLookup tl = new TestcaseLookup(logger);
		testCaseList = tl.lookupTestcase(FrameworkConstants.TCLookup,
				"G19EditCDNodeTC004");
		LoadProperties lp1 = new LoadProperties(FrameworkConstants.RunIdFile);
		runIdFile = (lp1.readProperty("RUNID"));
		wtr = new WriteTestResult();

		if (testCasesucessFlag) {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating " + testCaseList.get(i)
						+ " status as Passed");

				wtr.writeToFile(runIdFile,
						"G19EditCDNodeTC004," + testCaseList.get(i) + ",Passed");
			}
		} else {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating" + testCaseList.get(i) + "status as Failed");

				wtr.writeToFile(runIdFile,"G19EditCDNodeTC004," + testCaseList.get(i) + ",Failed");
			}
		}
		}

	}

}

			
			