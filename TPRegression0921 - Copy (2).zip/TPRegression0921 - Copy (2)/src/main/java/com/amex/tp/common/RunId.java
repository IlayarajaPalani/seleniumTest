package com.amex.tp.common;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

public class RunId {
	
	public static void main(String args[]) throws FileNotFoundException
	{
		RunId rd=new RunId();
		rd.generateRunId();
	}

	public boolean generateRunId()
	{
		try(FileWriter fw = new FileWriter("RunId.txt", false);
			    BufferedWriter bw = new BufferedWriter(fw);
			    PrintWriter out = new PrintWriter(bw))
			{
			 Date dNow = new Date();
		     SimpleDateFormat ft = new SimpleDateFormat("yyMMddhhmmss");
		     String RUNID = ft.format(dNow);
		     RUNID="RUNID=target/TPAutomation-"+RUNID+".csv";
		     out.println(RUNID);
		     return true;
		     
			} catch (IOException e) {
			    //exception handling left as an exercise for the reader
				return false;
			}
		
		
	}
	public boolean generateRunId_maintainer()
	{
		try(FileWriter fw = new FileWriter("RunId.txt", false);
			    BufferedWriter bw = new BufferedWriter(fw);
			    PrintWriter out = new PrintWriter(bw))
			{
			 Date dNow = new Date();
		     SimpleDateFormat ft = new SimpleDateFormat("yyMMddhhmmss");
		     String RUNID = ft.format(dNow);
		     RUNID="RUNID=target/TPAutomationmaintainer-"+RUNID+".csv";
		     out.println(RUNID);
		     return true;
		     
			} catch (IOException e) {
			    //exception handling left as an exercise for the reader
				return false;
			}
		
		
	}
	public boolean generateRunId_profmaintainer()
	{
		try(FileWriter fw = new FileWriter("RunId.txt", false);
			    BufferedWriter bw = new BufferedWriter(fw);
			    PrintWriter out = new PrintWriter(bw))
			{
			 Date dNow = new Date();
		     SimpleDateFormat ft = new SimpleDateFormat("yyMMddhhmmss");
		     String RUNID = ft.format(dNow);
		     RUNID="RUNID=target/TPAutomationmaintainer-"+RUNID+".csv";
		     out.println(RUNID);
		     return true;
		     
			} catch (IOException e) {
			    //exception handling left as an exercise for the reader
				return false;
			}
		
		
	}
	public boolean generateRunId_wgadmin()
	{
		try(FileWriter fw = new FileWriter("RunId.txt", false);
			    BufferedWriter bw = new BufferedWriter(fw);
			    PrintWriter out = new PrintWriter(bw))
			{
			 Date dNow = new Date();
		     SimpleDateFormat ft = new SimpleDateFormat("yyMMddhhmmss");
		     String RUNID = ft.format(dNow);
		     RUNID="RUNID=target/TPAutomationmaintainer-"+RUNID+".csv";
		     out.println(RUNID);
		     return true;
		     
			} catch (IOException e) {
			    //exception handling left as an exercise for the reader
				return false;
			}
		
		
	}
	
	
	
}
