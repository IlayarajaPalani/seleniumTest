package com.amex.tp.scripts;

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipOutputStream;

import org.openqa.selenium.WebDriver;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import bsh.ParseException;

import com.amex.tp.common.CreateZip;
import com.amex.tp.common.FrameworkConstants;
import com.amex.tp.common.LoadProperties;
import com.amex.tp.common.ScreenShot;
import com.amex.tp.common.TP_Login;
import com.amex.tp.common.TP_Login_Maintainer;
import com.amex.tp.common.TestcaseLookup;
import com.amex.tp.common.WriteTestResult;
import com.amex.tp.common.commandManager;

@Test
public class G10EditInboundTC017 {

	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G10EditInboundTC017.class);

	Map<String, Object> connectionmap;
	ScreenShot screenPrint;
	String runIdFile;
	List<String> testCaseList;
	WriteTestResult wtr;
	WebDriver fdriver;
	String filePath = FrameworkConstants.ScreenShots + "/G10EditInboundTC017/G10EditInboundTC017.zip";
	String screenshotname;
	int screenshotnumber = 1;
	String loginscreenshot;
	File folder;
	CreateZip zipfile = null;
	ZipOutputStream zos = null;
	FileOutputStream fos = null;
	boolean testCasesucessFlag=false;
	commandManager cmd;

	@Parameters({ "TestCaseName", "Browser" })
	public void addtransmitter(String tcname, String browser) throws InterruptedException,ParseException, Throwable {

		LoadProperties lp = new LoadProperties(FrameworkConstants.G10_Props);
		String tcid = ""; cmd=commandManager.getInstance(browser,tcid);

		try {
			folder = new File(FrameworkConstants.ScreenShots
					+ "/G10EditInboundTC017");

			if (folder.mkdir()) {
				// System.out.println("Directory is created!");
				logger.info("Group Folder Created");
			} else {
				logger.info("Directory Already Exists. Results will be added to the existing folder.");
				// System.out.println("Directory Already Exists!");
			}
		} catch (Exception e) {
			logger.info("Group Folder Creation Failed");
			// System.out.println("exception is:"+ e);
		}

		try {
			TP_Login tp = new TP_Login(logger, browser, cmd);
			connectionmap = tp.HlogintoTP(browser, zos);
			fdriver = (WebDriver) connectionmap.get("fdriver");
			screenPrint = new ScreenShot();
			screenshotname = tcname + "_" + screenshotnumber;
			System.out.println("Screenshot: " + screenshotname);
			System.out.println(folder.getAbsolutePath());
			// System.out.println(fdriver.getCurrentUrl());
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			System.out.println("The  screen shot " + screenshotnumber+ " got added");
			logger.info("The  screen shot " + screenshotnumber + " got added");
			Thread.sleep(FrameworkConstants.SleepValue);
			logger.info("Click on Maintain Transmitter");
			cmd.click("html/body/table[2]/tbody/tr/td[1]/form/div/dl[4]/dt/img", "xpath");//click on Maintain Transmitter
			logger.info("Click on Search Transmitter");
			cmd.click(".//*[@id='smenu1']/a[1]/img", "xpath");//Click on Search Transmitter
			logger.info("Enter the Base File Name");
			cmd.type("baseFileName", "name",lp.readProperty("G10EditInbondFileTC017_baseFileName"));
			logger.info("Click on Search button");
			cmd.click("Search", "name");
			Thread.sleep(2000);
			screenshotname=tcname+"_"+screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			logger.info("Click on the Searched Transmitter Name");
			cmd.click(".//*[@id='userdetails1']/tbody/tr[3]/td[1]/a", "xpath");
			
			logger.info("Click on Inbound File Tab");
			cmd.click(".//*[@id='tabPane1']/div[1]/h2[3]/a", "xpath");
			logger.info("Enter the File Name");
			cmd.type("fileName", "name", lp.readProperty("G10EditInbondFileTC017_fileName"));
			logger.info("Click on Go Button");
			cmd.click("GO", "name");
			logger.info("Click on the searched File Name");
			cmd.click(".//*[@id='tabPage3']/table/tbody/tr[4]/td[1]/a", "xpath");
			screenshotname=tcname+"_"+screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			
			
			String Succmsg = cmd.getContent(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[12]/td/input", "xpath");
			if(Succmsg.contains("***Cancel ***")){
				
			  System.out.println("Inbound file status cannot be changed --  "+G10EditInboundTC017.class);
			  testCasesucessFlag=true;
			}else{
			  System.out.println("Inbound file status change failed --  "+G10EditInboundTC017.class);
			}
			
			
			
			
			cmd.click(".//*[@id='menu']/dl[7]/a/img", "xpath");
			fdriver.switchTo().alert().accept();
			Thread.sleep(3000);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Test Case Failed");
			cmd.click(".//*[@id='menu']/dl[7]/a/img", "xpath");
			fdriver.switchTo().alert().accept();
			cmd.wait(5000);
			Assert.fail(e.getMessage());
		}finally {
		
		

		TestcaseLookup tl = new TestcaseLookup(logger);
		testCaseList = tl.lookupTestcase(FrameworkConstants.TCLookup,
				"G10EditInboundTC017");
		LoadProperties lp1 = new LoadProperties(FrameworkConstants.RunIdFile);
		runIdFile = (lp1.readProperty("RUNID"));
		wtr = new WriteTestResult();

		if (testCasesucessFlag) {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating " + testCaseList.get(i)
						+ " status as Passed");

				wtr.writeToFile(runIdFile,
						"G10EditInboundTC017," + testCaseList.get(i) + ",Passed");
			}
		} else {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating" + testCaseList.get(i) + "status as Failed");

				wtr.writeToFile(runIdFile,"G10EditInboundTC017," + testCaseList.get(i) + ",Failed");
			}

		}
		}

	}
	
}
