package com.amex.tp.scripts;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipOutputStream;

import org.openqa.selenium.WebDriver;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import com.amex.tp.common.CreateZip;
import com.amex.tp.common.FrameworkConstants;
import com.amex.tp.common.LoadProperties;
import com.amex.tp.common.ScreenShot;
import com.amex.tp.common.TP_Login;
import com.amex.tp.common.TP_Login_Viewer;
import com.amex.tp.common.TestcaseLookup;
import com.amex.tp.common.WriteTestResult;
import com.amex.tp.common.commandManager;

import bsh.ParseException;

public class G19EditCDNodeTC005_Viewer {
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G19EditCDNodeTC005_Viewer.class);
	Map<String, Object> connectionmap;
	ScreenShot screenPrint;
	String runIdFile;
	List<String> testCaseList;
	WriteTestResult wtr;
	WebDriver fdriver;
	String filePath = FrameworkConstants.ScreenShots+"/G19EditCDNodeTC005_Viewer/G19EditCDNodeTC005_Viewer.zip";
	String screenshotname;
	int screenshotnumber=0;
	String loginscreenshot;
	File folder;
	CreateZip zipfile = null;
	ZipOutputStream zos = null;
	FileOutputStream fos = null;
	boolean testCasesucessFlag=false;
	boolean testCasesucessFlag1=false;
	boolean testCasesucessFlag2=false;
	boolean testCasesucessFlag3=false;
	boolean maintaincdnodesavailability;
	boolean maintainsftconfigavailability;
	commandManager cmd;
	Timestamp time;
	String responsemsg;

	public static void main(String[] args) throws ParseException, InterruptedException, Throwable{
		G19EditCDNodeTC005_Viewer g3 = new G19EditCDNodeTC005_Viewer();
		g3.addBasicUser("G19EditCDNodeTC005_Viewer", "IE");
	}

	@Parameters({ "TestCaseName", "Browser" })
	@Test
	public void addBasicUser(String tcname, String browser) throws InterruptedException,ParseException, Throwable {
		LoadProperties lp = new LoadProperties(FrameworkConstants.G19_Props);
		String tcid = ""; cmd=commandManager.getInstance(browser,tcid);

		try {
			folder = new File(FrameworkConstants.ScreenShots+"/G19EditCDNodeTC005_Viewer");

			if (folder.mkdir()) {
				// System.out.println("Directory is created!");
				logger.info("Group Folder Created");
			} else {
				logger.info("Directory Already Exists. Results will be added to the existing folder.");
				// System.out.println("Directory Already Exists!");
			}
		} catch (Exception e) {
			logger.info("Group Folder Creation Failed");
			// System.out.println("exception is:"+ e);
		}

		try{
			TP_Login_Viewer tp = new TP_Login_Viewer(logger, browser, cmd);
			connectionmap = tp.HlogintoTP_viewer(browser, zos);
			fdriver = (WebDriver) connectionmap.get("fdriver");
			screenPrint = new ScreenShot();
			System.out.println("Screenshot: " + screenshotname);
			System.out.println(folder.getAbsolutePath());
			// System.out.println(fdriver.getCurrentUrl());
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);

			System.out.println("The  screen shot " + screenshotnumber+ " got added");
			Thread.sleep(FrameworkConstants.SleepValue);
			
			logger.info("Check for  Maintain SFT config"); 
			maintainsftconfigavailability=cmd.ifDisplayed("//*[@id='menu']/dl[6]/dt/img");
			
			//cmd.click("//*[@id='menu']/dl[6]/dt/img", "xpath");
				
            
            if( maintainsftconfigavailability==false){
					testCasesucessFlag = true;
					System.out.println("test case G19EditCDNodeTC005_Viewer got passed");
				}
				else{
					testCasesucessFlag = false;
					System.out.println("test case G19EditCDNodeTC005_Viewer got failed");
				}

			cmd.click(".//*[@id='menu']/dl[7]/a/img", "xpath");
			fdriver.switchTo().alert().accept();
			Thread.sleep(3000);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Test Case Failed");
			cmd.click(".//*[@id='menu']/dl[7]/a/img", "xpath");
			fdriver.switchTo().alert().accept();
			cmd.wait(5000);
			Assert.fail(e.getMessage());
		}finally {

		TestcaseLookup tl = new TestcaseLookup(logger);
		testCaseList = tl.lookupTestcase(FrameworkConstants.TCLookup,
				"G19EditCDNodeTC005_Viewer");
		LoadProperties lp1 = new LoadProperties(FrameworkConstants.RunIdFile);
		runIdFile = (lp1.readProperty("RUNID"));
		wtr = new WriteTestResult();

		if (testCasesucessFlag) {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating " + testCaseList.get(i)
						+ " status as Passed");

				wtr.writeToFile(runIdFile,
						"G19EditCDNodeTC005_Viewer," + testCaseList.get(i) + ",Passed");
			}
		} else {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating" + testCaseList.get(i) + "status as Failed");

				wtr.writeToFile(runIdFile,"G19EditCDNodeTC005_Viewer," + testCaseList.get(i) + ",Failed");
			}

		}
		}
	}

}