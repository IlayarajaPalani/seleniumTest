package com.amex.tp.scripts;

//Description - Update an Remote Access with SSH protocol

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipOutputStream;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import bsh.ParseException;

import com.amex.tp.common.CreateZip;
import com.amex.tp.common.FrameworkConstants;
import com.amex.tp.common.LoadProperties;
import com.amex.tp.common.ScreenShot;
import com.amex.tp.common.TP_Login;
import com.amex.tp.common.TP_Login_Viewer;
import com.amex.tp.common.TestcaseLookup;
import com.amex.tp.common.WriteTestResult;
import com.amex.tp.common.commandManager;

@Test
public class G4AddRemoteAccessTC013 {

	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G4AddRemoteAccessTC013.class);

	Map<String, Object> connectionmap;
	ScreenShot screenPrint;
	String runIdFile;
	List<String> testCaseList;
	WriteTestResult wtr;
	WebDriver fdriver;
	String filePath = FrameworkConstants.ScreenShots + "/G4AddRemoteAccessTC013/G4AddRemoteAccessTC013.zip";
	String screenshotname;
	int screenshotnumber = 1;
	String loginscreenshot;
	File folder;
	CreateZip zipfile = null;
	ZipOutputStream zos = null;
	FileOutputStream fos = null;
	boolean testCasesucessFlag=false;
	commandManager cmd;

	@Parameters({ "TestCaseName", "Browser" })
	public void updateRA(String tcname, String browser) throws InterruptedException,ParseException, Throwable {

		LoadProperties lp = new LoadProperties(FrameworkConstants.G4_Props);
		String tcid = ""; cmd=commandManager.getInstance(browser,tcid);

		try {
			folder = new File(FrameworkConstants.ScreenShots
					+ "/G4AddRemoteAccessTC013");

			if (folder.mkdir()) {
				// System.out.println("Directory is created!");
				logger.info("Group Folder Created");
			} else {
				logger.info("Directory Already Exists. Results will be added to the existing folder.");
				// System.out.println("Directory Already Exists!");
			}
		} catch (Exception e) {
			logger.info("Group Folder Creation Failed");
			// System.out.println("exception is:"+ e);
		}

		try {
			TP_Login_Viewer tp = new TP_Login_Viewer(logger,browser,cmd);
			connectionmap = tp.HlogintoTP_viewer(browser, zos);
			fdriver = (WebDriver) connectionmap.get("fdriver");
			screenPrint = new ScreenShot();
			screenshotname = tcname + "_" + screenshotnumber;
			System.out.println("Screenshot: " + screenshotname);
			System.out.println(folder.getAbsolutePath());
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			System.out.println("The  screen shot " + screenshotnumber+ " got added");
			logger.info("The  screen shot " + screenshotnumber + " got added");
			Thread.sleep(FrameworkConstants.SleepValue);

			cmd.click("/html/body/table[2]/tbody/tr/td[1]/form/div/dl[4]/dt/img", "xpath");
			
			cmd.click("/html/body/table[2]/tbody/tr/td[1]/form/div/dl[4]/dd/a[1]/img", "xpath");
			
			cmd.type("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[1]/input", "xpath",(lp.readProperty("G4AddRATC013_searchTransmitter")));
			  
			screenshotname=tcname+"_"+screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			
			cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[8]/td/input[1]", "xpath"); //search button
			cmd.click(lp.readProperty("G4AddRATC013_searchTransmitter"), "partialLinkText");
			
			screenshotname = tcname + "_" + screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			System.out.println("Add RA screen steps started -- "+G4AddRemoteAccessTC013.class);
			
			cmd.click(".//*[@id='tabPane1']/div[1]/h2[2]/a", "xpath");
			screenshotname = tcname + "_" + screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			int eltPresence = fdriver.findElements(By.name("AddRemoteAccess")).size() ;
			System.out.println("eltPresence-------->"+eltPresence);
			
			/*cmd.click("AddRemoteAccess", "name");
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[1]/input", "xpath", lp.readProperty("G4AddRATC013_raname"));
			cmd.selectByText(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td[2]/select", "xpath", lp.readProperty("G4AddRATC013_protocol"));
			cmd.selectByText(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[2]/select", "xpath", lp.readProperty("G4AddRATC013_owner"));
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td/div/table/tbody/tr[2]/td[1]/input", "xpath", lp.readProperty("G4AddRATC013_remoteadd"));
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td/div/table/tbody/tr[3]/td[1]/input", "xpath", lp.readProperty("G4AddRATC013_remoteUser"));
			cmd.selectByText(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td/div/table/tbody/tr[3]/td[2]/select", "xpath", lp.readProperty("G4AddRATC013_sftUser"));
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td/div/table/tbody/tr[4]/td[1]/input", "xpath", lp.readProperty("G4AddRATC013_pwd"));
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td/div/table/tbody/tr[4]/td[2]/input", "xpath", lp.readProperty("G4AddRATC013_pwd"));
			cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td/div/table/tbody/tr[5]/td[1]/input[1]", "xpath");			
			cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[7]/td/input[1]", "xpath");*/
			
			if(eltPresence==0){
				testCasesucessFlag=true;
			}else{
				testCasesucessFlag=false;
			}
			
			screenshotname = tcname + "_" + screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			fdriver.switchTo().alert().accept();
			Thread.sleep(3000);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Test Case Failed");
			cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			fdriver.switchTo().alert().accept();
			cmd.wait(5000);
			Assert.fail(e.getMessage());

		}finally {

		TestcaseLookup tl = new TestcaseLookup(logger);
		testCaseList = tl.lookupTestcase(FrameworkConstants.TCLookup,
				"G4AddRemoteAccessTC013");
		LoadProperties lp1 = new LoadProperties(FrameworkConstants.RunIdFile);
		runIdFile = (lp1.readProperty("RUNID"));
		wtr = new WriteTestResult();
		System.out.println("testCasesucessFlag---------------->"+testCasesucessFlag);
		if (testCasesucessFlag) {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating " + testCaseList.get(i)
						+ " status as Passed");

				wtr.writeToFile(runIdFile,
						"G4AddRemoteAccessTC013," + testCaseList.get(i) + ",Passed");
			}
		} else {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating" + testCaseList.get(i) + "status as Failed");

				wtr.writeToFile(runIdFile,"G4AddRemoteAccessTC013," + testCaseList.get(i) + ",Failed");
			}

		}

	}
	}
	
}
