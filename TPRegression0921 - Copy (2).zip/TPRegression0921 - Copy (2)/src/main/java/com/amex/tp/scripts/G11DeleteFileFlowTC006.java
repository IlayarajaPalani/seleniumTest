package com.amex.tp.scripts;

//Description - delete a step from an existing file flow

import java.io.File;
import java.io.FileOutputStream;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipOutputStream;

import org.openqa.selenium.WebDriver;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import bsh.ParseException;

import com.amex.tp.common.CreateZip;
import com.amex.tp.common.FrameworkConstants;
import com.amex.tp.common.LoadProperties;
import com.amex.tp.common.ScreenShot;
import com.amex.tp.common.TP_Login;
import com.amex.tp.common.TestcaseLookup;
import com.amex.tp.common.WriteTestResult;
import com.amex.tp.common.commandManager;

@Test
public class G11DeleteFileFlowTC006 {

	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G11DeleteFileFlowTC006.class);

	Map<String, Object> connectionmap;
	ScreenShot screenPrint;
	String runIdFile;
	List<String> testCaseList;
	WriteTestResult wtr;
	WebDriver fdriver;
	String filePath = FrameworkConstants.ScreenShots + "/G11DeleteFileFlowTC006/G11DeleteFileFlowTC006.zip";
	String screenshotname;
	int screenshotnumber = 1;
	String loginscreenshot;
	File folder;
	CreateZip zipfile = null;
	ZipOutputStream zos = null;
	FileOutputStream fos = null;
	boolean testCasesucessFlag=false;
	commandManager cmd;

	@Parameters({ "TestCaseName", "Browser" })
	public void addFileFlow(String tcname, String browser) throws InterruptedException,ParseException, Throwable {

		LoadProperties lp = new LoadProperties(FrameworkConstants.G11_Props);
		String tcid = ""; cmd=commandManager.getInstance(browser,tcid);

		try {
			folder = new File(FrameworkConstants.ScreenShots + "/G11DeleteFileFlowTC006");

			if (folder.mkdir()) {
				// System.out.println("Directory is created!");
				logger.info("Group Folder Created");
			} else {
				logger.info("Directory Already Exists. Results will be added to the existing folder.");
				// System.out.println("Directory Already Exists!");
			}
		} catch (Exception e) {
			logger.info("Group Folder Creation Failed");
			// System.out.println("exception is:"+ e);
		}

		try {
			TP_Login tp = new TP_Login(logger,browser,cmd);;
			connectionmap = tp.HlogintoTP(browser, zos);
			fdriver = (WebDriver) connectionmap.get("fdriver");
			screenPrint = new ScreenShot();
			screenshotname = tcname + "_" + screenshotnumber;
			System.out.println("Screenshot: " + screenshotname);
			System.out.println(folder.getAbsolutePath());
			Thread.sleep(FrameworkConstants.SleepValue);
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);

			System.out.println("The  screen shot " + screenshotnumber+ " got added");
			screenshotnumber++;
			
			logger.info("Click on Maintain File Flow");
			cmd.click("/html/body/table[2]/tbody/tr/td[1]/form/div/dl[5]/dt/img", "xpath");
			logger.info("Click on Search File Flow");
			cmd.click("/html/body/table[2]/tbody/tr/td[1]/form/div/dl[5]/dd/a[1]/img", "xpath");
			logger.info("Enter File Flow Name");
			cmd.type("fileFlowName", "name",(lp.readProperty("G11DeleteFF006_fileflow")));

			screenshotname=tcname+"_"+screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			logger.info("Click on Search Button");
			cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td/input[1]", "xpath"); //search button
			logger.info("Click on Searched File Flow Linked Text");
			cmd.click(lp.readProperty("G11DeleteFF006_fileflow"), "partialLinkText");

			screenshotname = tcname + "_" + screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			logger.info("Click on Edit Button");
			cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td/input[1]", "xpath"); //edit
			
			logger.info("Click on Add New Step Button");
			cmd.click("AddNewStepType", "name");
			cmd.click("//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[10]/td/input[1]", "xpath");
			
			screenshotname = tcname + "_" + screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			
			logger.info("Delete a Step");
			cmd.click("//*[@id='usertable']/tbody/tr[3]/td[3]/a[2]/img", "xpath");
			//cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td/table/tbody/tr[5]/td[3]/a[2]/img", "xpath");
			logger.info("Click on Save Button");
			//cmd.click("Save", "name");
			cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td/input[2]", "xpath"); //save
			
			String Succmsg = cmd.getContent("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table[1]/tbody/tr/td[3]/font", "xpath");
			System.out.println("The Success Message is - " + Succmsg);
			
			if(Succmsg.contains("***File Flow updated successfully*** ***Replication verification is successful***")){
			  logger.info("G11DeleteFileFlowTC006 - delete a step from an existing file flow is succeeded");
			  testCasesucessFlag=true;
			}else{
				logger.info("G11DeleteFileFlowTC006 - delete a step from an existing file flow is failed");
				 testCasesucessFlag=false;
			}
			
			
			logger.info("Searching for the same File Flow to see the Updates");
			logger.info("Enter File Flow Name");
			cmd.type("fileFlowName", "name",(lp.readProperty("G11DeleteFF006_fileflow")));
			logger.info("Click on Search Button");
			cmd.click("/html/body/table[2]/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td/input[1]", "xpath"); //search button
			logger.info("Click on Searched File Flow Linked Text");
			cmd.click(lp.readProperty("G11DeleteFF006_fileflow"), "partialLinkText");
			Thread.sleep(FrameworkConstants.SleepValue);
			
			screenshotname = tcname + "_" + screenshotnumber;
			screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);

			//cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			logger.info("Logging out from the Application");
			cmd.click("//img[contains(@src, 'Logout.jpg')]", "xpath");
			fdriver.switchTo().alert().accept();
			Thread.sleep(3000);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Test Case Failed");
			//cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
			logger.info("Logging out from the Application");
			cmd.click("//img[contains(@src, 'Logout.jpg')]", "xpath");
			fdriver.switchTo().alert().accept();
			cmd.wait(5000);
			Assert.fail(e.getMessage());

		}finally{

		TestcaseLookup tl = new TestcaseLookup(logger);
		testCaseList = tl.lookupTestcase(FrameworkConstants.TCLookup,
				"G11DeleteFileFlowTC006");
		LoadProperties lp1 = new LoadProperties(FrameworkConstants.RunIdFile);
		runIdFile = (lp1.readProperty("RUNID"));
		wtr = new WriteTestResult();

		if (testCasesucessFlag) {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating " + testCaseList.get(i) + " status as Passed");

				wtr.writeToFile(runIdFile, "G11DeleteFileFlowTC006," + testCaseList.get(i) + ",Passed");
			}
		} else {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating" + testCaseList.get(i) + "status as Failed");

				wtr.writeToFile(runIdFile,"G11DeleteFileFlowTC006," + testCaseList.get(i) + ",Failed");
			}

		}

	}

}
}
