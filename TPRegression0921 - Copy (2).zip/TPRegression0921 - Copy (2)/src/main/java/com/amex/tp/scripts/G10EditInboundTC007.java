package com.amex.tp.scripts;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipOutputStream;

import org.openqa.selenium.WebDriver;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import bsh.ParseException;

import com.amex.tp.common.CreateZip;
import com.amex.tp.common.FrameworkConstants;
import com.amex.tp.common.LoadProperties;
import com.amex.tp.common.ScreenShot;
import com.amex.tp.common.TP_Login;
import com.amex.tp.common.TP_Login_Maintainer;
import com.amex.tp.common.TestcaseLookup;
import com.amex.tp.common.WriteTestResult;
import com.amex.tp.common.commandManager;

public class G10EditInboundTC007 {
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G10EditInboundTC007.class);
	Map<String, Object> connectionmap;
	ScreenShot screenPrint;
	String runIdFile;
	List<String> testCaseList;
	WriteTestResult wtr;
	WebDriver fdriver;
	String filePath = FrameworkConstants.ScreenShots+"/G10EditInboundTC007/G10EditInboundTC007.zip";
	String screenshotname;
	int screenshotnumber = 1;
	String loginscreenshot;
	File folder;
	CreateZip zipfile = null;
	ZipOutputStream zos = null;
	FileOutputStream fos = null;
	boolean testCasesucessFlag=false;
	commandManager cmd;
	Timestamp time;



	@Parameters({ "TestCaseName", "Browser" })
	@Test
	public void addBasicUser(String tcname, String browser) throws InterruptedException,ParseException, Throwable {
		LoadProperties lp = new LoadProperties(FrameworkConstants.G10_Props);
		String tcid = ""; cmd=commandManager.getInstance(browser,tcid);

		try {
			folder = new File(FrameworkConstants.ScreenShots+"/G10EditInboundTC007");

			if (folder.mkdir()) {
				// System.out.println("Directory is created!");
				logger.info("Group Folder Created");
			} else {
				logger.info("Directory Already Exists. Results will be added to the existing folder.");
				// System.out.println("Directory Already Exists!");
			}
		} catch (Exception e) {
			logger.info("Group Folder Creation Failed");
			// System.out.println("exception is:"+ e);
		}

		try{
			TP_Login tp = new TP_Login(logger, browser, cmd);
			connectionmap = tp.HlogintoTP(browser, zos);
			fdriver = (WebDriver) connectionmap.get("fdriver");
			screenPrint = new ScreenShot();
			screenshotname = tcname + "_" + screenshotnumber;
			System.out.println("Screenshot: " + screenshotname);
			System.out.println(folder.getAbsolutePath());
			// System.out.println(fdriver.getCurrentUrl());
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			logger.info("The  screen shot " + screenshotnumber + " got added");
			Thread.sleep(FrameworkConstants.SleepValue);
			logger.info("Click Maintain Transmitter");
			cmd.click(".//*[@id='menu']/dl[4]/dt/img", "xpath");
			logger.info("Click search Transmitter");
			cmd.click(".//*[@id='smenu1']/a[1]/img", "xpath");
			logger.info("Search Transmitter");
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[1]/input", "xpath", lp.readProperty("G10EditInboundTC007_searchTransmitter"));
			logger.info("Click Search");
			cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[8]/td/input[1]","xpath");
			logger.info("Click on Transmitter");
			cmd.click(".//*[@id='userdetails1']/tbody/tr[3]/td[1]/a", "xpath");
			logger.info("Click Inbound files tab");
			cmd.click(".//*[@id='tabPane1']/div[1]/h2[3]/a", "xpath");
			logger.info("Enter FileName");
			cmd.type(".//*[@id='tabPage3']/div[1]/input[2]", "xpath", lp.readProperty("G10EditInboundTC007_seachFileName"));
			logger.info("Click GO");
			cmd.click(".//*[@id='tabPage3']/div[1]/input[5]", "xpath");
			logger.info("Click on FileName");
			cmd.click(".//*[@id='tabPage3']/table/tbody/tr[3]/td[1]/a", "xpath");
			logger.info("click Edit");
			cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[12]/td/input[1]", "xpath");
			logger.info("Edit FileName");
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[4]/td[1]/input", "xpath", lp.readProperty("G10EditInboundTC007_FileName"));
			logger.info("Click File Type ");
			cmd.selectByIndex(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td[1]/select", "xpath", 1);
			//cmd.selectByText(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[5]/td[1]/select", "xpath", lp.readProperty("G10EditInboundTC007_FileType"));
			logger.info("Enter Roll Over Value");
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[6]/td[1]/input", "xpath", lp.readProperty("G10EditInboundTC007_rollOver"));
			logger.info("Select FileFlow");
			cmd.selectByText(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[10]/td/select", "xpath", lp.readProperty("G10EditInboundTC007_FileFlow"));
			logger.info("Click Mailbox");
			cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[11]/td/table/tbody/tr[3]/td[2]/a", "xpath");
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			logger.info("The  screen shot " + screenshotnumber + " got added");
			logger.info("Click Cancel");
			cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[7]/td/input[2]", "xpath");
			logger.info("Click Catalog");
			cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[11]/td/table/tbody/tr[2]/td[2]/a", "xpath");
			logger.info("Click Edit");
			cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[11]/td/input[1]","xpath");
			logger.info("Click Encryprtion package");
			cmd.selectByText(".//*[@id='PGP']/table/tbody/tr[2]/td[2]/select", "xpath", lp.readProperty("G10EditInboundTC007_ENCpackage"));
			logger.info("Select Authentication Type");
			cmd.selectByText(".//*[@id='PGP']/table/tbody/tr[3]/td[2]/select", "xpath", lp.readProperty("G10EditInboundTC007_AutheneticationType"));
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			logger.info("Click OK");
			cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[12]/td/input[1]", "xpath");
			logger.info("click Save");
			cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[12]/td/input[1]", "xpath");
			String Succmsg=cmd.getContent(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table[1]/tbody/tr/td[3]/font", "xpath");
			if(Succmsg.equalsIgnoreCase("***Inbound File details updated successfully*** ***Replication verification is successful***")){
			  logger.info("G10EditInboundTC007 succeeded");
			  testCasesucessFlag=true;
			  			  
			}else{
				logger.info("G10EditInboundTC007 failed");
				System.out.println("The Actual message displayed in the application is" + Succmsg);
				 testCasesucessFlag=false;
				 			}
			
			screenshotnumber++;
			screenshotname = tcname + "_" + screenshotnumber;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
			cmd.click(".//*[@id='menu']/dl[7]/a/img", "xpath");
			fdriver.switchTo().alert().accept();
			Thread.sleep(3000);

		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("Test Case Failed");
			cmd.click(".//*[@id='menu']/dl[7]/a/img", "xpath");
			fdriver.switchTo().alert().accept();
			cmd.wait(5000);
			Assert.fail(e.getMessage());
			
		}
		
		finally{
		TestcaseLookup tl = new TestcaseLookup(logger);
		testCaseList = tl.lookupTestcase(FrameworkConstants.TCLookup,
				"G10EditInboundTC007");
		LoadProperties lp1 = new LoadProperties(FrameworkConstants.RunIdFile);
		runIdFile = (lp1.readProperty("RUNID"));
		wtr = new WriteTestResult();

		if (testCasesucessFlag) {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating " + testCaseList.get(i)
						+ " status as Passed");

				wtr.writeToFile(runIdFile,
						"G10EditInboundTC007," + testCaseList.get(i) + ",Passed");
			}
		} else {
			for (int i = 0; i < testCaseList.size(); i++) {
				System.out.println("Updating" + testCaseList.get(i) + "status as Failed");

				wtr.writeToFile(runIdFile,"G10EditInboundTC007," + testCaseList.get(i) + ",Failed");
				}

			}
				}
		}
}