package com.amex.tp.scripts;

import java.io.File;
import java.io.FileOutputStream;
import java.sql.Timestamp;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipOutputStream;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import bsh.ParseException;

import com.amex.tp.common.CreateZip;
import com.amex.tp.common.FrameworkConstants;
import com.amex.tp.common.LoadProperties;
import com.amex.tp.common.ScreenShot;
import com.amex.tp.common.TP_Login;
import com.amex.tp.common.TP_Login_Support;
import com.amex.tp.common.TestcaseLookup;
import com.amex.tp.common.WriteTestResult;
import com.amex.tp.common.commandManager;

public class G6EditFileFlowTC014_Support {
	public static org.slf4j.Logger logger = LoggerFactory.getLogger(G6EditFileFlowTC014_Support.class);
	Map<String, Object> connectionmap;
	ScreenShot screenPrint;
	String runIdFile;
	List<String> testCaseList;
	WriteTestResult wtr;
	WebDriver fdriver;
	String filePath = FrameworkConstants.ScreenShots+"/G6EditFileFlowTC017/G6EditFileFlowTC017.zip";
	String screenshotname;
	int screenshotnumber = 1;
	String loginscreenshot;
	File folder;
	CreateZip zipfile = null;
	ZipOutputStream zos = null;
	FileOutputStream fos = null;
	boolean testCasesucessFlag=false;
	commandManager cmd;
	Timestamp time;
/*
	public static void main(String[] args) throws ParseException, InterruptedException, Throwable{
		G6EditFileFlowTC014_Support g6 = new G6EditFileFlowTC014_Support();
		g6.addBasicUser("G6EditFileFlowTC017", "IE");
	}
*/
	@Parameters({ "TestCaseName", "Browser" })
	@Test
	public void addBasicUser(String tcname, String browser) throws InterruptedException,ParseException, Throwable {
		LoadProperties lp = new LoadProperties(FrameworkConstants.G6_Props);
		String tcid = ""; cmd=commandManager.getInstance(browser,tcid);

		try {
			folder = new File(FrameworkConstants.ScreenShots+"/G6EditFileFlowTC014_Support");

			if (folder.mkdir()) {
				// System.out.println("Directory is created!");
				logger.info("Group Folder Created");
			} else {
				logger.info("Directory Already Exists. Results will be added to the existing folder.");
				// System.out.println("Directory Already Exists!");
			}
		} catch (Exception e) {
			logger.info("Group Folder Creation Failed");
			// System.out.println("exception is:"+ e);
		}

		try{
			TP_Login_Support tp = new TP_Login_Support(logger,browser,cmd);
			connectionmap = tp.HlogintoTP_Support(browser, zos);
			fdriver = (WebDriver) connectionmap.get("fdriver");
			screenPrint = new ScreenShot();
			screenshotname = tcname + "_" + screenshotnumber;
			System.out.println("Screenshot: " + screenshotname);
			System.out.println(folder.getAbsolutePath());
			// System.out.println(fdriver.getCurrentUrl());
			//screenshotnumber++;
			screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);

			//System.out.println("The  screen shot " + screenshotnumber+ " got added");
			logger.info("The  screen shot " + screenshotnumber + " got added");
			Thread.sleep(FrameworkConstants.SleepValue);
            
			logger.info("Click Maintain File Flow");
			cmd.click(".//*[@id='menu']/dl[5]/dt/img", "xpath");
			logger.info("Click Search File Flow");
			cmd.click(".//*[@id='smenu2']/a[1]/img", "xpath");
			
			logger.info("Enter Existing File Flow name");
			cmd.type(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[1]/input[1]", "xpath", lp.readProperty("G6EditFFTC017_searchfileflow"));
			logger.info("Select WorkGroup Owner");
			cmd.selectByText(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[2]/td[2]/select","xpath",lp.readProperty("G6EditFFTC017_workgroupOwner"));
			logger.info("Click Search");
			cmd.click(".//*[@id='leftmenu']/tbody/tr/td[2]/form/div[2]/table/tbody/tr[3]/td/input[1]","xpath");
			logger.info("Click File Flow");
			cmd.click(".//*[@id='userdetails']/tbody/tr[3]/td[1]/a", "xpath");
			
			try{
				testCasesucessFlag=cmd.ifDisplayed("Edit");
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
			finally
			{
				System.out.println(testCasesucessFlag);
			}
			
			
	 screenshotnumber++;
	 screenshotname = tcname + "_" + screenshotnumber;
		screenPrint.takeScreenShot(folder.getAbsolutePath(), screenshotname, fdriver);
		cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
		fdriver.switchTo().alert().accept();
		Thread.sleep(3000);

	} catch (Exception e) {
		e.printStackTrace();
		System.out.println("Test Case Failed");
		cmd.click(".//*[@id='menu']/dl[9]/a/img", "xpath");
		fdriver.switchTo().alert().accept();
		cmd.wait(5000);
		Assert.fail(e.getMessage());
	
	}
	finally	{
	TestcaseLookup tl = new TestcaseLookup(logger);
	testCaseList = tl.lookupTestcase(FrameworkConstants.TCLookup,
			"G6EditFileFlowTC017");
	LoadProperties lp1 = new LoadProperties(FrameworkConstants.RunIdFile);
	runIdFile = (lp1.readProperty("RUNID"));
	wtr = new WriteTestResult();

	if (testCasesucessFlag) {
		for (int i = 0; i < testCaseList.size(); i++) {
			System.out.println("Updating " + testCaseList.get(i)
					+ " status as Passed");

			wtr.writeToFile(runIdFile,
					"G6EditFileFlowTC017," + testCaseList.get(i) + ",Passed");
		}
	} else {
		for (int i = 0; i < testCaseList.size(); i++) {
			System.out.println("Updating" + testCaseList.get(i) + "status as Failed");

			wtr.writeToFile(runIdFile,"G6EditFileFlowTC017," + testCaseList.get(i) + ",Failed");
		}

	}
	}

}


}